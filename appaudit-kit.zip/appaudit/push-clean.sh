#!/usr/bin/env bash
# Replace the branch on GitHub with a clean copy of this folder.
#
#   bash push-clean.sh https://github.com/<you>/<repo>.git
#
# Why this exists: if the repository holds appaudit-kit.zip instead of the
# kit's own files, `git clone` hands people an archive they must unzip before any
# command works - and that archive carries android/keystore/appaudit.jks, the key
# that signs the phone app.
#
# What it does: builds a single commit from the files in THIS folder (respecting
# .gitignore, so the key and the live server state stay out), and force-pushes it
# over the remote branch. The old commits stay on GitHub's servers until they are
# garbage-collected, so read the notes at the end of the README.

set -euo pipefail

REMOTE_URL="${1:-}"
BRANCH="${2:-main}"
HERE="$(cd "$(dirname "$0")" && pwd)"
cd "$HERE"

say() { printf '  %s\n' "$*"; }
die() { printf '\n  STOP: %s\n\n' "$*" >&2; exit 1; }

printf '\nAppAudit - push a clean tree\n'
say "folder : $HERE"
say "branch : $BRANCH"

# ---- 1. is this actually the kit? -----------------------------------------
# Guards against running this inside an old clone that holds README.md and the
# zip but not the kit itself: pushing that would publish the same problem again.
for f in install.sh run.sh server/appaudit_server.py server/index.html; do
  [ -f "$f" ] || die "this folder is not the kit - $f is missing. Unzip appaudit-kit.zip and run this from inside appaudit/."
done
say "kit    : looks right (install.sh, run.sh and server/ are here)"

# ---- 2. git identity ------------------------------------------------------
if ! git config user.email >/dev/null 2>&1 || ! git config user.name >/dev/null 2>&1; then
  die "git does not know who you are yet. Run these two lines, then try again:
       git config --global user.name  \"Your Name\"
       git config --global user.email \"you@example.com\""
fi

# ---- 3. start a repository here, and point it at the remote --------------
if ! git rev-parse --git-dir >/dev/null 2>&1; then
  git init -q
  say "git    : new repository"
fi

if [ -n "$REMOTE_URL" ]; then
  git remote remove origin >/dev/null 2>&1 || true
  git remote add origin "$REMOTE_URL"
fi
git remote get-url origin >/dev/null 2>&1 || die "no remote. Pass the URL: bash push-clean.sh https://github.com/<you>/<repo>.git"
say "remote : $(git remote get-url origin)"

# ---- 4. one commit, built from the files as they are ---------------------
# --orphan keeps the working tree but empties the index, so the new commit has
# no parent and carries none of the old history.
if git rev-parse --verify -q HEAD >/dev/null; then
  git checkout --orphan ps-clean >/dev/null 2>&1 || git checkout -B ps-clean >/dev/null 2>&1
  say "branch : starting a fresh root commit"
fi

git add -A

# ---- 5. refuse to publish anything private ------------------------------
PRIVATE="$(git diff --cached --name-only | grep -Ei 'ps-app\.jks|\.keystore$|state\.json$|accounts\.json$|kit\.zip$|^helpers/|\.aa_setup_ok$' || true)"
if [ -n "$PRIVATE" ]; then
  printf '\n  These files are staged and must not be published:\n\n'
  printf '    %s\n' $PRIVATE
  die "nothing was pushed. Run: git reset  and check .gitignore."
fi

STAGED="$(git diff --cached --name-only | wc -l)"
[ "$STAGED" -gt 0 ] || die "nothing to commit - is this an empty folder?"
say "files  : $STAGED, none private"

git commit -q -m "AppAudit 2.1.1" || die "commit failed"
git branch -M "$BRANCH"

# ---- 6. replace the remote branch ---------------------------------------
printf '\n  Pushing over the remote branch. Anything already there is replaced.\n\n'
git push --force -u origin "$BRANCH"

printf '\n  Done. Open the repository page and confirm:\n\n'
say "- the file list shows install.sh, run.sh, server/, android/, docs/"
say "- there is no appaudit-kit.zip"
say "- there is no android/keystore/ folder"
printf '\n  Then anyone can run:\n\n'
CLONE_URL="$(git remote get-url origin)"
REPO_NAME="$(basename "$CLONE_URL" .git)"
say "git clone $CLONE_URL"
say "cd $REPO_NAME"
say "bash run.sh"
printf '\n  The commit that held the zip is still reachable on GitHub by its old\n'
printf '  link until GitHub cleans it up. The README explains what that means\n'
printf '  and when it matters.\n\n'
