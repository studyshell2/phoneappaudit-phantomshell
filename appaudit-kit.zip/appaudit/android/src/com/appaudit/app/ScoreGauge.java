package com.appaudit.app;

import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.view.View;
import android.view.animation.DecelerateInterpolator;

/**
 * The score: a 276-degree arc that fills to the value, with the number inside.
 *
 * One animated float drives both the arc and the number, so the arc can never
 * come to rest somewhere the number does not point at, and the caption is read
 * from that same float - it changes band exactly as the number crosses 85 or 60.
 */
final class ScoreGauge extends View {

    private final Paint track = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint arcP  = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint big   = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint tiny  = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint cap   = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint bloom = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF box   = new RectF();

    private boolean hasScore;
    private float shown;          // animated 0..100
    private ValueAnimator anim;

    ScoreGauge(Context c) {
        super(c);

        track.setStyle(Paint.Style.STROKE);
        track.setStrokeCap(Paint.Cap.ROUND);
        track.setStrokeWidth(Ui.fdp(c, 8f));
        track.setColor(0xFF11283F);

        arcP.setStyle(Paint.Style.STROKE);
        arcP.setStrokeCap(Paint.Cap.ROUND);
        arcP.setStrokeWidth(Ui.fdp(c, 8f));

        big.setTextAlign(Paint.Align.CENTER);
        big.setTypeface(Ui.MONO);

        tiny.setTextAlign(Paint.Align.CENTER);
        tiny.setTypeface(Ui.MONO_R);
        tiny.setLetterSpacing(0.18f);

        cap.setTextAlign(Paint.Align.CENTER);
        cap.setTypeface(Ui.MONO);
        cap.setLetterSpacing(0.16f);
    }

    /** @param score 0..100, or -1 for "nothing scanned yet". */
    void setScore(int score, boolean animated) {
        if (anim != null) {
            anim.cancel();
            anim = null;
        }
        if (score < 0) {
            hasScore = false;
            shown = 0f;
            invalidate();
            return;
        }
        hasScore = true;
        if (!animated) {
            shown = score;
            invalidate();
            return;
        }
        final float from = shown;
        ValueAnimator a = ValueAnimator.ofFloat(0f, 1f);
        anim = a;
        a.setDuration(950);
        a.setInterpolator(new DecelerateInterpolator(1.7f));
        a.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
            @Override public void onAnimationUpdate(ValueAnimator v) {
                float f = (Float) v.getAnimatedValue();
                shown = from + (score - from) * f;
                invalidate();
            }
        });
        a.start();
    }

    private static String bandFor(int value) {
        if (value < 0) return "NO SCAN";
        if (value >= 85) return "SAFE";
        if (value >= 60) return "WATCH";
        return "AT RISK";
    }

    @Override
    protected void onDraw(Canvas canvas) {
        float w = getWidth(), h = getHeight();
        if (w <= 0 || h <= 0) return;

        float cx = w / 2f;
        float cy = h * 0.50f;
        float r = Math.min(w, h * 1.15f) * 0.42f;
        float inset = Ui.fdp(getContext(), 5f);

        box.set(cx - r + inset, cy - r + inset, cx + r - inset, cy + r - inset);
        canvas.drawArc(box, 132f, 276f, false, track);

        int value = hasScore ? Math.round(shown) : -1;
        int colour = Ui.scoreColor(value);

        arcP.setColor(colour);
        if (value > 0) {
            canvas.drawArc(box, 132f, 276f * (Math.min(100, value) / 100f), false, arcP);
        }

        // A soft bloom behind the number, in the score's colour, so the value
        // reads at a glance even before the eye gets to the digits.
        if (hasScore) {
            bloom.setStyle(Paint.Style.FILL);
            bloom.setColor(colour);
            bloom.setAlpha(18);
            canvas.drawCircle(cx, cy, r * 0.66f, bloom);
        }

        big.setTextSize(Ui.fdp(getContext(), 44f));
        big.setColor(hasScore ? colour : Ui.FAINT);
        canvas.drawText(hasScore ? String.valueOf(value) : "--",
                cx, cy + Ui.fdp(getContext(), 15f), big);

        tiny.setTextSize(Ui.fdp(getContext(), 8f));
        tiny.setColor(Ui.FAINT);
        canvas.drawText("SCORE / 100", cx, cy + Ui.fdp(getContext(), 34f), tiny);

        cap.setTextSize(Ui.fdp(getContext(), 9f));
        cap.setColor(hasScore ? colour : Ui.FAINT);
        canvas.drawText(bandFor(value), cx, cy + Ui.fdp(getContext(), 58f), cap);
    }
}
