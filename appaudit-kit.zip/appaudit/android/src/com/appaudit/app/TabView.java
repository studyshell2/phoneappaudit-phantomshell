package com.appaudit.app;

import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.view.View;
import android.view.animation.DecelerateInterpolator;

/**
 * One tab: the word, and the bar under it.
 *
 * Both are drawn from the same centre, and the bar is measured from the very
 * letters it sits under, so the two cannot drift apart.
 *
 * This replaces a LinearLayout holding a TextView and a View, which did not line
 * up. The reason is worth recording because it is not obvious: a child added
 * without explicit LayoutParams gets MATCH_PARENT width inside a vertical
 * LinearLayout, so the label filled the whole cell and its text sat at the left
 * edge, while the bar - which did have an explicit width and height - was
 * centred by the parent's gravity. Measured on a 360dp screen, the word centre
 * landed 84px left of its own underline. Drawing both here removes the layout
 * pass from the question entirely.
 */
final class TabView extends View {

    /** Letter tracking in em, matching the labels this replaces. */
    private static final float TRACK = 0.2f;

    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint.FontMetrics fm;
    private final RectF barBox = new RectF();
    private final String label;

    private float shown;          // 0 = inactive, 1 = active
    private ValueAnimator anim;

    TabView(Context c, String label) {
        super(c);
        this.label = label;
        p.setTypeface(Ui.MONO);
        p.setTextSize(Ui.fdp(c, 10.5f));
        fm = p.getFontMetrics();
        setClickable(true);
        setFocusable(true);
    }

    /**
     * @param animated false for the first paint, so the app does not fade its
     *                 own tab bar in as it opens.
     */
    void setActive(boolean active, boolean animated) {
        final float to = active ? 1f : 0f;
        if (anim != null) {
            anim.cancel();
            anim = null;
        }
        if (!animated || shown == to) {
            shown = to;
            invalidate();
            return;
        }
        final float from = shown;
        ValueAnimator a = ValueAnimator.ofFloat(0f, 1f);
        anim = a;
        a.setDuration(180);
        a.setInterpolator(new DecelerateInterpolator());
        a.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
            @Override public void onAnimationUpdate(ValueAnimator v) {
                shown = from + (to - from) * (Float) v.getAnimatedValue();
                invalidate();
            }
        });
        a.start();
    }

    private float tracking() {
        return TRACK * p.getTextSize();
    }

    /** Width of the word as drawn, tracking included. */
    private float textWidth() {
        float w = 0f;
        for (int i = 0; i < label.length(); i++) {
            w += p.measureText(label, i, i + 1);
        }
        return w + tracking() * Math.max(0, label.length() - 1);
    }

    /** Draws the word centred on cx, one glyph at a time so tracking is ours. */
    private void drawWord(Canvas c, float cx, float baseline, int colour, int alpha) {
        float x = cx - textWidth() / 2f;
        float step = tracking();
        p.setColor(colour);
        p.setAlpha(alpha);
        for (int i = 0; i < label.length(); i++) {
            c.drawText(label, i, i + 1, x, baseline, p);
            x += p.measureText(label, i, i + 1) + step;
        }
        p.setAlpha(255);
    }

    @Override
    protected void onDraw(Canvas canvas) {
        float w = getWidth(), h = getHeight();
        if (w <= 0 || h <= 0) return;

        float cx = w / 2f;
        float barH = Math.max(2f, Ui.fdp(getContext(), 2f));
        float barTop = h - Ui.fdp(getContext(), 8f) - barH;
        // Positioned from the bar upwards, so the gap between the word's
        // descenders and its underline is the same at any tab height.
        float baseline = barTop - Ui.fdp(getContext(), 7f) - fm.descent;

        drawWord(canvas, cx, baseline, Ui.FAINT, 255);

        if (shown > 0f) {
            drawWord(canvas, cx, baseline, Ui.STRONG, (int) (255 * shown));

            float tw = textWidth();
            p.setColor(Ui.ACCENT);
            p.setAlpha((int) (255 * shown));
            barBox.set(cx - tw / 2f, barTop, cx + tw / 2f, barTop + barH);
            float r = barH / 2f;
            canvas.drawRoundRect(barBox, r, r, p);
            p.setAlpha(255);
        }
    }
}
