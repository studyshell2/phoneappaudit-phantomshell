package com.appaudit.app;

import android.app.job.JobParameters;
import android.app.job.JobService;
import android.os.Build;
import android.util.Log;

/**
 * The scheduled rescan.
 *
 * A full scan is repeated in the background so an app that was already installed
 * before the guard arrived still gets checked, and so a permission granted later
 * is noticed. JobScheduler is used because it is part of the framework: no extra
 * library, and the system decides the best moment to run it.
 *
 * Requires API 21+. Older phones are covered by the install-time receiver plus
 * the button in the app.
 */
public class ScanJobService extends JobService {

    private static final String TAG = "PSScanJob";
    private volatile boolean stopped = false;

    @Override
    public boolean onStartJob(final JobParameters params) {
        // The job may have been queued before the owner switched protection off.
        // Returning false ends it here instead of scanning anyway.
        if (!App.protectionOn(this)) {
            return false;
        }
        stopped = false;
        new Thread(new Runnable() {
            @Override public void run() {
                boolean again = false;
                try {
                    ScanRunner.scanAll(ScanJobService.this, false);
                } catch (Throwable t) {
                    Log.w(TAG, "job scan: " + t);
                    again = true;
                } finally {
                    jobFinished(params, again && !stopped);
                }
            }
        }, "ps-scan-job").start();
        return true;                       // keep the wakelock: work is async
    }

    @Override
    public boolean onStopJob(JobParameters params) {
        stopped = true;
        return true;                       // reschedule if the system cut us off
    }
}
