package com.appaudit.app;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * One place that runs a scan, stores the result, tells the dashboard and alerts
 * the user.
 *
 * Everything that can trigger a scan goes through here - the install-time
 * receiver, the periodic background job, and the button in the app - so the
 * behaviour cannot drift between them.
 *
 * Calling this does blocking work. Always call it off the main thread.
 */
final class ScanRunner {

    private static final String TAG = "PSScan";

    static final String CH_ALERT = "appaudit_apps";

    private ScanRunner() {}

    /** Full scan of every installed app. */
    static Result scanAll(Context c, boolean announce) {
        List<AppRisk.App> apps = AppScanner.scanAll(c);
        return finish(c, apps, announce, true, true);
    }

    /** Scan one package only, the cheap path used on install. */
    static Result scanPackage(Context c, String pkg, boolean announce) {
        AppRisk.App a = AppScanner.scanOne(c, pkg);
        List<AppRisk.App> one = new ArrayList<AppRisk.App>();
        if (a != null) one.add(a);
        return finish(c, one, announce, false, true);
    }

    /**
     * The GO button: one full scan, run for the person holding the phone.
     *
     * `report` is passed in rather than read here so the decision is visible at
     * the call site. The scan is identical either way; the only difference is
     * whether the batch is posted to the dashboard at the end. With no address
     * configured send() returns immediately anyway, so a phone that was never set
     * up cannot report anywhere whatever the caller passes.
     *
     * announce=false suppresses the "all clear" popup only, because the person is
     * already looking at the result. A High finding still raises its alert: the
     * dialog can be dismissed and forgotten, and losing the one warning that
     * matters would be the wrong trade.
     */
    static Result scanForUi(Context c, boolean report) {
        List<AppRisk.App> apps = AppScanner.scanAll(c);
        return finish(c, apps, false, true, report);
    }

    /** Runs scanForUi off the main thread, then calls back on it. */
    static void scanForUiAsync(final Context c, final boolean report,
                               final UiDone done) {
        new Thread(new Runnable() {
            @Override public void run() {
                Result res = null;
                try {
                    res = scanForUi(c, report);
                } catch (Throwable t) {
                    Log.w(TAG, "scanForUiAsync: " + t);
                }
                final Result out = res;
                new Handler(Looper.getMainLooper()).post(new Runnable() {
                    @Override public void run() {
                        if (done != null) done.finished(out);
                    }
                });
            }
        }, "ps-scan-ui").start();
    }

    /** Called on the main thread with the result, or null if the scan failed. */
    interface UiDone {
        void finished(Result res);
    }

    // ------------------------------------------------------------------ score

    /**
     * One number for the whole phone, derived from the table - not a new
     * measurement.
     *
     * 100 means nothing from outside a store was found. A High app costs 25,
     * because High means a live permission that can read the screen, send
     * messages or install software. An outside-store app graded Safe costs 3:
     * no store vetted it, but nothing dangerous was measured either. The same
     * arithmetic is printed under the gauge, so the number can be checked
     * instead of believed.
     */
    static int score(Result res) {
        if (res == null) return -1;
        int safe = Math.max(0, res.sideload - res.high);
        int s = 100 - res.high * 25 - safe * 3;
        if (s < 0) s = 0;
        if (s > 100) s = 100;
        return s;
    }

    /** The same arithmetic in words, for the line under the gauge. */
    static String scoreBasis(Result res) {
        if (res == null) return "";
        int safe = Math.max(0, res.sideload - res.high);
        if (res.high == 0 && safe == 0) {
            return "100 - nothing from outside a store";
        }
        StringBuilder sb = new StringBuilder("100");
        if (res.high > 0) sb.append(" - ").append(res.high).append(" high x 25");
        if (safe > 0) sb.append(" - ").append(safe).append(" safe x 3");
        return sb.append(" = ").append(score(res)).toString();
    }

    // ----------------------------------------------------------------- core

    private static Result finish(Context c, List<AppRisk.App> apps, boolean announce,
                                 boolean replaceStore, boolean report) {
        Result res = new Result();
        res.scanned = apps.size();

        JSONArray events = new JSONArray();
        List<Row> risky = new ArrayList<Row>();

        for (AppRisk.App a : apps) {
            AppRisk.Result r = AppRisk.score(a);
            if (a.dexRead) res.deep++;

            // Only apps that did NOT come from an app store are reported.
            //
            // A program delivered by Play, the Samsung store, GetApps,
            // AppGallery or a vendor preload updater has already been signed and
            // vetted by that store, and the phone owner cannot act on it
            // anyway. Listing those made the dashboard look alarming about an
            // ordinary phone: every stock app was "not from a store", which was
            // both wrong and useless. What is left is exactly the thing worth
            // looking at - software that arrived some other way.
            boolean outside = a.sideloaded && !a.system;
            if (!outside) {
                // Counted so the phone card can say how many apps a store
                // delivered and was deliberately left out of the table.
                if (!a.system) res.store++;
                continue;
            }

            res.sideload++;
            if (AppRisk.HIGH.equals(r.risk)) res.high++;
            else res.secure++;

            risky.add(new Row(a, r));
            try {
                events.put(apkEvent(a, r));
            } catch (Exception ignored) { }
        }

        // Worst first, so the top of the list is the thing to deal with.
        Collections.sort(risky, new java.util.Comparator<Row>() {
            @Override public int compare(Row x, Row y) {
                if (x.result.score != y.result.score) return y.result.score - x.result.score;
                return x.app.label.compareToIgnoreCase(y.app.label);
            }
        });

        res.rows = risky;
        res.at = System.currentTimeMillis();
        store(c, res, risky, replaceStore);
        notifyIfNeeded(c, res, risky, announce);

        try {
            JSONObject scan = new JSONObject();
            scan.put("type", "scan");
            scan.put("risk", res.high > 0 ? "High" : "Safe");
            // Only the two numbers that matter: how many outside-store apps
            // were found, and how many of those are High. There is no third
            // level, so there is nothing else to send.
            scan.put("safe", res.secure);
            scan.put("high", res.high);
            scan.put("outside", res.sideload);
            scan.put("store", res.store);
            scan.put("checked", res.scanned);
            scan.put("details", res.scanned + " apps checked, "
                    + res.sideload + " from outside a store: "
                    + res.high + " high, " + res.secure + " safe, "
                    + res.store + " from a store");
            events.put(scan);
        } catch (Exception ignored) { }

        // The rows are stored on the handset either way. Whether the batch is
        // posted is the caller's decision, and whether the post actually landed
        // is recorded rather than assumed: post() returns "" when the address
        // does not answer, so the phone can say "not sent" instead of claiming
        // a delivery that never happened.
        res.reportTried = report;
        if (report) {
            res.reported = send(c, events);
            Log.i(TAG, "scan: report " + (res.reported ? "delivered" : "not delivered"));
        } else {
            Log.i(TAG, "scan: nothing sent");
        }
        Log.i(TAG, "scan: " + res.scanned + " apps, " + res.sideload
                + " outside a store, " + res.high + " high, "
                + res.secure + " safe");
        return res;
    }

    /** One app, as the dashboard expects it. */
    private static JSONObject apkEvent(AppRisk.App a, AppRisk.Result r) throws Exception {
        JSONObject o = new JSONObject();
        o.put("type", "apk");
        o.put("risk", r.risk);
        o.put("package", a.pkg);
        o.put("label", a.label);
        o.put("version_name", a.versionName);
        o.put("version_code", a.versionCode);
        o.put("sha256", a.sha256);
        o.put("signer", a.signerSha256);
        o.put("size", a.sizeBytes);
        o.put("installer", a.installer);
        // The whole install chain, so the dashboard can show the evidence for
        // "outside a store" instead of asking the operator to trust a label.
        o.put("initiating", a.initiating);
        o.put("originating", a.originating);
        o.put("package_source", a.packageSource);
        o.put("from_store", a.fromStore);
        o.put("origin", a.origin);
        o.put("source", r.source);
        o.put("first_install", a.firstInstall);
        o.put("last_update", a.lastUpdate);
        o.put("target_sdk", a.targetSdk);
        o.put("debuggable", a.debuggable);
        o.put("system", a.system);
        o.put("sideloaded", a.sideloaded);
        o.put("accessibility", a.accessibilityOn);
        o.put("device_admin", a.deviceAdminOn);
        o.put("notif_access", a.notifAccessOn);
        o.put("score", r.score);
        // No verdict, no confidence. They were a second opinion computed by
        // different rules, and they could disagree with the risk shown right
        // next to them ("HIGH ... SECURE"), which reads as a broken tool.
        o.put("summary", r.summary);
        o.put("reason", r.reason);
        o.put("advice", r.advice);
        o.put("hidden", a.hidden);
        o.put("inspected", a.inspected);
        o.put("dex_read", a.dexRead);
        o.put("packed", a.packed);
        // The file-level evidence in the app's own words. This is what the
        // dashboard shows when someone asks "why?" about a rating.
        if (a.fileEvidence != null && a.fileEvidence.size() > 0) {
            JSONArray ev = new JSONArray();
            for (String s : a.fileEvidence) ev.put(s);
            o.put("evidence", ev);
        }
        o.put("at", System.currentTimeMillis());
        JSONArray perms = new JSONArray();
        String[] p = a.permissions;
        if (p != null) {
            // Only the ones that matter; the full list is enormous and useless.
            for (String s : p) {
                if (s == null) continue;
                if (s.indexOf("SMS") >= 0 || s.indexOf("CONTACTS") >= 0
                        || s.indexOf("ACCESSIBILITY") >= 0 || s.indexOf("DEVICE_ADMIN") >= 0
                        || s.indexOf("INSTALL_PACKAGES") >= 0 || s.indexOf("ALERT_WINDOW") >= 0
                        || s.indexOf("NOTIFICATION") >= 0 || s.indexOf("CALL") >= 0
                        || s.indexOf("RECORD_AUDIO") >= 0 || s.indexOf("CAMERA") >= 0) {
                    perms.put(s.substring(s.lastIndexOf('.') + 1));
                }
            }
        }
        o.put("permissions", perms);
        return o;
    }

    /** Post to the dashboard in one batch. Silent when no dashboard is set. */
    /** @return true when the dashboard answered; false when it was unreachable. */
    private static boolean send(Context c, JSONArray events) {
        String base = App.server(c);
        if (base.length() == 0 || events.length() == 0) return false;
        try {
            JSONObject body = new JSONObject();
            body.put("tag", App.tag(c));
            body.put("device_id", App.deviceId(c));
            // The fingerprint goes on every report, including one sent by a
            // background scan while the app is closed.
            body.put("fingerprint", App.fingerprint(c));
            body.put("packages", App.packages(c));
            body.put("events", events);
            String reply = App.post(base, "/api/app/report", body, 8000);
            // post() answers "" for any failure - refused connection, timeout,
            // DNS - so an empty reply is the signal that nothing was delivered.
            return reply != null && reply.length() > 0;
        } catch (Exception e) {
            Log.w(TAG, "send: " + e);
            return false;
        }
    }

    // -------------------------------------------------------------- alerting

    /**
     * Notify only when something is actually wrong, and only for a real
     * finding. A notification for every scan would be noise and the user would
     * turn it off, which is worse than no notification at all.
     */
    private static void notifyIfNeeded(Context c, Result res, List<Row> risky,
                                       boolean announce) {
        Row worst = risky.isEmpty() ? null : risky.get(0);
        try {
            NotificationManager nm =
                    (NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE);
            if (nm == null) return;
            if (Build.VERSION.SDK_INT >= 26) {
                NotificationChannel ch = new NotificationChannel(CH_ALERT,
                        "AppAudit app alerts", NotificationManager.IMPORTANCE_HIGH);
                ch.setDescription("A risky app was found on this phone");
                nm.createNotificationChannel(ch);
            }

            String title;
            String text;
            if (worst != null && AppRisk.HIGH.equals(worst.result.risk)) {
                title = "Check this app: " + worst.app.label;
                text = worst.result.reason;
            } else if (announce) {
                // User asked for a scan and everything is clean: say so once.
                title = "No risky apps found";
                text = res.scanned + " apps checked. Nothing stood out.";
            } else {
                return;
            }

            PendingIntent pi = PendingIntent.getActivity(
                    c, 0, new Intent(c, MainActivity.class),
                    Build.VERSION.SDK_INT >= 23
                            ? PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
                            : PendingIntent.FLAG_UPDATE_CURRENT);

            Notification.Builder b = Build.VERSION.SDK_INT >= 26
                    ? new Notification.Builder(c, CH_ALERT)
                    : new Notification.Builder(c);
            b.setContentTitle(title)
                    .setContentText(text)
                    .setSmallIcon(android.R.drawable.stat_sys_warning)
                    .setAutoCancel(true)
                    .setContentIntent(pi);
            if (worst != null) {
                b.setStyle(new Notification.BigTextStyle()
                        .bigText(text + "\n\n" + worst.result.advice));
            }
            nm.notify(0x73, b.build());
        } catch (Throwable t) {
            Log.w(TAG, "notify: " + t);
        }
    }

    // --------------------------------------------------------------- storage

    /** Keep the last result on the phone so the app can show it offline. */
    private static void store(Context c, Result res, List<Row> risky, boolean replaceStore) {
        try {
            JSONObject o = new JSONObject();
            o.put("at", res.at);
            o.put("scanned", res.scanned);
            o.put("high", res.high);
            o.put("safe", res.secure);
            o.put("sideload", res.sideload);
            JSONArray arr = new JSONArray();
            for (int i = 0; i < risky.size() && i < 30; i++) {
                Row row = risky.get(i);
                JSONObject x = new JSONObject();
                x.put("label", row.app.label);
                x.put("pkg", row.app.pkg);
                x.put("risk", row.result.risk);
                x.put("reason", row.result.reason);
                x.put("advice", row.result.advice);
                x.put("source", row.result.source);
                arr.put(x);
            }
            o.put("rows", arr);
            App.setLastScan(c, o.toString());
        } catch (Throwable t) {
            Log.w(TAG, "store: " + t);
        }
    }

    /** Run a full scan on a background thread, for the UI button. */
    static void scanAsync(final Context c) {
        new Thread(new Runnable() {
            @Override public void run() {
                try {
                    scanAll(c, true);
                    App.setScanRequested(c, false);
                } catch (Throwable t) {
                    Log.w(TAG, "scanAsync: " + t);
                }
            }
        }, "ps-scan-ui").start();
    }

    /** The summary line the app shows. */
    static String summary(Context c) {
        try {
            String raw = App.getLastScan(c);
            if (raw == null || raw.length() == 0) {
                return "No scan yet. Tap Scan installed apps now, or just install "
                        + "an app - it is checked automatically.";
            }
            JSONObject o = new JSONObject(raw);
            StringBuilder sb = new StringBuilder();
            sb.append("Last scan ").append(App.clock(o.optLong("at", 0)))
              .append("  -  ").append(o.optInt("scanned")).append(" apps checked\n")
              .append(o.optInt("sideload")).append(" from outside a store: ")
              .append(o.optInt("high")).append(" high, ")
              .append(o.optInt("safe")).append(" safe");
            JSONArray rows = o.optJSONArray("rows");
            if (rows != null) {
                for (int i = 0; i < rows.length() && i < 8; i++) {
                    JSONObject r = rows.optJSONObject(i);
                    if (r == null) continue;
                    sb.append("\n\n").append(r.optString("risk", "?").toUpperCase())
                      .append("  ").append(r.optString("label", "?"))
                      .append("  [").append(r.optString("pkg", "")).append("]\n")
                      .append("  source: ").append(r.optString("source", "?")).append('\n')
                      .append("  why: ").append(r.optString("reason", "")).append('\n')
                      .append("  do:  ").append(r.optString("advice", ""));
                }
            }
            return sb.toString();
        } catch (Throwable t) {
            return "Scan result could not be read.";
        }
    }


    /**
     * The result, written out for the person holding the phone.
     *
     * The dashboard is a table on a big screen; this is the same finding in a
     * shape that reads on a handset: a count first, then one block per app with
     * where it came from, why it was flagged and what to do about it. Rows are
     * already sorted worst first, so the top of the list is the thing to deal
     * with rather than whatever happens to be alphabetically first.
     */
    static String localReport(Result res) {
        if (res == null) {
            return "The scan did not finish, so there is nothing to show.";
        }
        StringBuilder sb = new StringBuilder();
        sb.append("Scanned ").append(res.scanned).append(" installed apps at ")
          .append(App.clock(res.at)).append('\n');

        if (res.sideload == 0) {
            sb.append("Every app on this phone came from an app store.\n")
              .append("Nothing outside a store was found, so there is nothing ")
              .append("to remove.\n");
        } else {
            sb.append(res.sideload).append(" from outside a store: ")
              .append(res.high).append(" high, ").append(res.secure).append(" safe")
              .append('\n');
        }
        // Say what actually happened to the batch, not what was intended.
        if (res.reported) {
            sb.append("Sent to your dashboard.\n");
        } else if (res.reportTried) {
            sb.append("The dashboard did not answer - this result is only on ")
              .append("the phone.\n");
        } else {
            sb.append("Nothing was sent anywhere - this scan ran on the phone.\n");
        }

        if (res.rows.isEmpty()) {
            return sb.toString();
        }

        int shown = 0;
        for (Row row : res.rows) {
            if (shown >= 25) {
                sb.append("\n... and ").append(res.rows.size() - shown)
                  .append(" more. Open the dashboard for the full list.\n");
                break;
            }
            shown++;
            AppRisk.App a = row.app;
            AppRisk.Result r = row.result;
            sb.append('\n').append(shown).append(". ")
              .append(r.risk.toUpperCase()).append("  ")
              .append(a.label.length() == 0 ? a.pkg : a.label);
            if (a.versionName != null && a.versionName.length() > 0) {
                sb.append(' ').append(a.versionName);
            }
            sb.append('\n').append("   ").append(a.pkg).append('\n');
            if (a.origin != null && a.origin.length() > 0) {
                sb.append("   from : ").append(a.origin).append('\n');
            }
            if (r.reason != null && r.reason.length() > 0) {
                sb.append("   why  : ").append(r.reason).append('\n');
            }
            if (r.advice != null && r.advice.length() > 0) {
                sb.append("   do   : ").append(r.advice).append('\n');
            }
        }
        return sb.toString();
    }


    /** A risky app, kept together with its verdict. */
    static final class Row {
        final AppRisk.App app;
        final AppRisk.Result result;
        Row(AppRisk.App a, AppRisk.Result r) { this.app = a; this.result = r; }
    }

    /** What a scan produced. */
    static final class Result {
        int scanned = 0;
        int critical = 0;
        int high = 0;
        int sideload = 0;
        int store = 0;
        int secure = 0;
        int review = 0;
        int unsafe = 0;
        int unverified = 0;
        int deep = 0;
        long at = 0L;
        /** Whether this scan was asked to report, and whether it got through. */
        boolean reportTried = false;
        boolean reported = false;
        List<Row> rows = new ArrayList<Row>();
    }
}