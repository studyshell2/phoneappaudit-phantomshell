package com.appaudit.app;

import android.app.job.JobInfo;
import android.app.job.JobScheduler;
import android.content.ComponentName;
import android.content.Context;
import android.os.Build;
import android.util.Log;

/**
 * Keeps a periodic full scan booked with the system.
 *
 * 6 hours is deliberate. The install-time receiver already covers the moment
 * something arrives, so this is the safety net for apps that were there before,
 * or that quietly gained a permission. Anything more frequent would waste
 * battery for no extra safety.
 */
final class ScanScheduler {

    private static final String TAG = "PSSched";
    private static final int JOB_ID = 0x5053;                 // "PS"
    private static final long INTERVAL_MS = 6L * 60L * 60L * 1000L;

    private ScanScheduler() {}

    static void ensureScheduled(Context c) {
        if (Build.VERSION.SDK_INT < 21) return;
        try {
            JobScheduler js = (JobScheduler) c.getSystemService(Context.JOB_SCHEDULER_SERVICE);
            if (js == null) return;
            for (JobInfo ji : js.getAllPendingJobs()) {
                if (ji.getId() == JOB_ID) return;              // already booked
            }
            JobInfo job = new JobInfo.Builder(JOB_ID,
                    new ComponentName(c, ScanJobService.class))
                    .setRequiredNetworkType(JobInfo.NETWORK_TYPE_ANY)
                    .setPeriodic(INTERVAL_MS)
                    .setPersisted(true)
                    .build();
            int r = js.schedule(job);
            Log.i(TAG, "periodic scan scheduled: " + (r == JobScheduler.RESULT_SUCCESS));
        } catch (Throwable t) {
            Log.w(TAG, "ensureScheduled: " + t);
        }
    }

    /**
     * Cancel the booked scans.
     *
     * "Stop protection" has to actually stop the work. Without this the periodic
     * job keeps firing after the user turned protection off, which looks like the
     * off switch does not work.
     */
    static void cancel(Context c) {
        if (Build.VERSION.SDK_INT < 21) return;
        try {
            JobScheduler js = (JobScheduler) c.getSystemService(Context.JOB_SCHEDULER_SERVICE);
            if (js == null) return;
            js.cancel(JOB_ID);
            js.cancel(JOB_ID + 1);
            Log.i(TAG, "scheduled scans cancelled");
        } catch (Throwable t) {
            Log.w(TAG, "cancel: " + t);
        }
    }

    /** True when the periodic job is actually queued with the system. */
    static boolean isScheduled(Context c) {
        if (Build.VERSION.SDK_INT < 16) return false;
        try {
            JobScheduler js = (JobScheduler) c.getSystemService(Context.JOB_SCHEDULER_SERVICE);
            if (js == null) return false;
            for (JobInfo ji : js.getAllPendingJobs()) {
                if (ji.getId() == JOB_ID) return true;
            }
        } catch (Throwable t) {
            Log.w(TAG, "isScheduled: " + t);
        }
        return false;
    }

    /** Run a scan as soon as the system allows, e.g. straight after boot. */
    static void runSoon(Context c) {
        if (Build.VERSION.SDK_INT < 21) return;
        try {
            JobScheduler js = (JobScheduler) c.getSystemService(Context.JOB_SCHEDULER_SERVICE);
            if (js == null) return;
            JobInfo job = new JobInfo.Builder(JOB_ID + 1,
                    new ComponentName(c, ScanJobService.class))
                    .setRequiredNetworkType(JobInfo.NETWORK_TYPE_ANY)
                    .setOverrideDeadline(15000)                // within 15 seconds
                    .build();
            js.schedule(job);
        } catch (Throwable t) {
            Log.w(TAG, "runSoon: " + t);
        }
    }
}
