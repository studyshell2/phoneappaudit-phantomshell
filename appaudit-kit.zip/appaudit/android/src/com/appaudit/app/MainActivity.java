package com.appaudit.app;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.SurfaceTexture;
import android.graphics.drawable.GradientDrawable;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.util.Log;
import android.view.Gravity;
import android.view.Surface;
import android.view.TextureView;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONObject;

/**
 * Two screens, one thumb.
 *
 * The opener is the dashboard's own material - the same crest, the same navy,
 * the same background film - because the phone and the browser are one product.
 * Under it sit two pages that slide: SCAN, which is a score and one round button,
 * and SETTINGS, which is everything that used to be a wall of fields on a single
 * scrolling page.
 *
 * Nothing here decides what is risky. The only numbers this file shows come from
 * ScanRunner, which is the same code the background job and the dashboard use.
 */
public class MainActivity extends Activity {

    private static final String TAG = "PSMain";
    private static final int REQ_NOTIF_PROT = 0x1003;

    /** The intro is a first-run welcome, not a splash on every rotation. */
    private static boolean introShown;

    private FrameLayout root;
    private TextureView video;
    private MediaPlayer player;
    private int videoW = 1280, videoH = 720;

    private TextView chipText;
    private View chipDot;

    private SlidePager pager;
    private TabView tabScan, tabSettings;

    private ScoreGauge gauge;
    private GoButton go;
    private TextView hint, sentChip, findingsHead, localBtn;
    private LinearLayout findings;
    private TextView copyBtn;

    private EditText serverField, tagField;
    private TextView counters, deviceInfo, protectState, protectBtn, saveBtn,
            clearBtn, batteryBtn;

    private boolean scanning;
    private ScanRunner.Result lastResult;

    // ------------------------------------------------------------------ lifecycle

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        App.migrate(this);

        // The film runs under the status bar, so the bar is transparent and the
        // header below adds the inset itself. Done this way rather than with a
        // theme because the content is drawn, not inflated from a layout.
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
        getWindow().setStatusBarColor(Color.TRANSPARENT);
        getWindow().setNavigationBarColor(Ui.BG);
        getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                        | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN);

        buildUi();
        handleIntent(getIntent());
        refresh();

        if (!introShown) {
            introShown = true;
            playIntro();
        }
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        handleIntent(intent);
    }

    @Override
    protected void onResume() {
        super.onResume();
        refresh();
        resumeVideo();
        if (App.protectionOn(this)) {
            ScanScheduler.ensureScheduled(this);
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (player != null) {
            try {
                if (player.isPlaying()) player.pause();
            } catch (Throwable ignored) { }
        }
    }

    @Override
    protected void onDestroy() {
        releaseVideo();
        super.onDestroy();
    }

    // --------------------------------------------------------------------- intro

    private void playIntro() {
        IntroView intro = new IntroView(this, Ui.crest(this));
        root.addView(intro, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT));
        intro.play(new IntroView.Done() {
            @Override public void onDone() {
                root.removeView(intro);
            }
        });
    }

    // ------------------------------------------------------------------ assembly

    private void buildUi() {
        root = new FrameLayout(this);
        root.setBackgroundColor(Ui.BG);

        root.addView(new Backdrop(this), match());

        // The film, exactly as the sign-in card shows it. It sits above the
        // backdrop so a phone that cannot decode it still has a designed page
        // underneath rather than a black hole.
        video = new TextureView(this);
        // A transform can only be computed once the view has a size, and the
        // video's own dimensions arrive separately, so recompute whenever either
        // changes instead of trusting one callback order.
        video.addOnLayoutChangeListener(new View.OnLayoutChangeListener() {
            @Override public void onLayoutChange(View v, int l, int t, int r, int b,
                                                 int ol, int ot, int or, int ob) {
                cropVideo();
            }
        });
        video.setSurfaceTextureListener(new TextureView.SurfaceTextureListener() {
            @Override public void onSurfaceTextureAvailable(SurfaceTexture st, int w, int h) {
                startVideo(st);
            }
            @Override public void onSurfaceTextureSizeChanged(SurfaceTexture st, int w, int h) {
                cropVideo();
            }
            @Override public boolean onSurfaceTextureDestroyed(SurfaceTexture st) {
                releaseVideo();
                return true;
            }
            @Override public void onSurfaceTextureUpdated(SurfaceTexture st) { }
        });
        root.addView(video, match());

        // One scrim instead of dimming the video: it darkens the top for the
        // header, leaves the middle readable as an image, and goes almost solid
        // at the bottom where the controls live.
        View scrim = new View(this);
        scrim.setBackground(new GradientDrawable(
                GradientDrawable.Orientation.TOP_BOTTOM,
                new int[] {0xF2040D18, 0xB3040D18, 0xFA040D18}));
        root.addView(scrim, match());

        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);

        col.addView(header(), wrap());
        col.addView(tabBar(), lpMargin(ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT, 18, 4, 18));

        pager = new SlidePager(this);
        pager.addView(scanPage());
        pager.addView(settingsPage());
        pager.setOnPage(new SlidePager.OnPage() {
            @Override public void onPage(int index) {
                paintTabs(index, true);
            }
        });
        col.addView(pager, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));

        root.addView(col, match());
        setContentView(root);

        // No fade on the first paint: the tab bar should already look settled
        // when the intro finishes, not animate in behind it.
        paintTabs(0, false);
    }

    private FrameLayout.LayoutParams match() {
        return new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT);
    }

    private LinearLayout.LayoutParams wrap() {
        return new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT);
    }

    private LinearLayout.LayoutParams lpTop(int w, int h, float topDp) {
        return lpMargin(w, h, 0, topDp, 0);
    }

    private LinearLayout.LayoutParams lpMargin(int w, int h, float leftDp,
                                               float topDp, float rightDp) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(w, h);
        p.leftMargin = Ui.dp(this, leftDp);
        p.topMargin = Ui.dp(this, topDp);
        p.rightMargin = Ui.dp(this, rightDp);
        return p;
    }

    // -------------------------------------------------------------------- header

    private int statusBarPx() {
        int id = getResources().getIdentifier("status_bar_height", "dimen", "android");
        return id > 0 ? getResources().getDimensionPixelSize(id) : Ui.dp(this, 24);
    }

    private View header() {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(Ui.dp(this, 18), statusBarPx() + Ui.dp(this, 10),
                Ui.dp(this, 16), Ui.dp(this, 10));

        ImageView crest = new ImageView(this);
        if (Ui.crest(this) != null) crest.setImageBitmap(Ui.crest(this));
        float r = Ui.fdp(this, 9f);
        GradientDrawable plate = Ui.round(0xFF061420, r, Ui.LINE, Ui.fdp(this, 0.9f));
        crest.setBackground(plate);
        crest.setClipToOutline(true);
        row.addView(crest, new LinearLayout.LayoutParams(Ui.dp(this, 34), Ui.dp(this, 34)));

        LinearLayout names = new LinearLayout(this);
        names.setOrientation(LinearLayout.VERTICAL);
        LinearLayout.LayoutParams namesLp = new LinearLayout.LayoutParams(
                0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        namesLp.leftMargin = Ui.dp(this, 11);
        row.addView(names, namesLp);

        TextView title = Ui.heading(this, "AppAudit", 13f, Ui.STRONG);
        title.setLetterSpacing(0.14f);
        names.addView(title);
        TextView sub = Ui.text(this, "ON-DEVICE APP SCANNER", 7.6f, Ui.FAINT, true, false);
        sub.setLetterSpacing(0.2f);
        names.addView(sub);

        LinearLayout chip = new LinearLayout(this);
        chip.setOrientation(LinearLayout.HORIZONTAL);
        chip.setGravity(Gravity.CENTER_VERTICAL);
        chip.setBackground(Ui.round(0x1A4C9AFF, Ui.fdp(this, 20),
                Ui.alpha(Ui.ACCENT, 0x66), Math.max(1f, Ui.fdp(this, 0.8f))));
        Ui.pad(chip, this, 9, 5, 11, 5);

        chipDot = new View(this);
        chipDot.setBackground(Ui.round(Ui.ACCENT, Ui.fdp(this, 3), 0, 0f));
        chip.addView(chipDot, new LinearLayout.LayoutParams(Ui.dp(this, 6), Ui.dp(this, 6)));

        chipText = Ui.text(this, "READY", 8f, Ui.ACCENT, true, true);
        chipText.setLetterSpacing(0.16f);
        LinearLayout.LayoutParams ctl = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        ctl.leftMargin = Ui.dp(this, 6);
        chip.addView(chipText, ctl);

        row.addView(chip);
        return row;
    }

    // ---------------------------------------------------------------------- tabs

    /**
     * The two tabs. Each cell is one TabView, so the word and the bar under it
     * are drawn from the same centre and cannot fall out of step.
     */
    private View tabBar() {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.HORIZONTAL);
        box.setBackground(Ui.round(0x990A1A2D, Ui.fdp(this, 14), Ui.CARD_EDGE,
                Math.max(1f, Ui.fdp(this, 0.9f))));
        box.setPadding(Ui.dp(this, 4), Ui.dp(this, 4), Ui.dp(this, 4), Ui.dp(this, 4));

        tabScan = new TabView(this, "SCAN");
        tabScan.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { selectTab(0); }
        });
        tabSettings = new TabView(this, "SETTINGS");
        tabSettings.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { selectTab(1); }
        });

        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0,
                Ui.dp(this, 40), 1f);
        box.addView(tabScan, lp);
        box.addView(tabSettings, new LinearLayout.LayoutParams(0,
                Ui.dp(this, 40), 1f));
        return box;
    }

    private void selectTab(int index) {
        pager.setPage(index, true);
        paintTabs(index, true);
    }

    private void paintTabs(int index, boolean animated) {
        if (tabScan == null) return;
        tabScan.setActive(index == 0, animated);
        tabSettings.setActive(index == 1, animated);
    }

    // ----------------------------------------------------------------- scan page

    private View scanPage() {
        ScrollView sv = new ScrollView(this);
        sv.setFillViewport(true);
        sv.setVerticalScrollBarEnabled(false);
        sv.setClipToPadding(false);

        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        Ui.pad(col, this, 18, 4, 18, 30);
        sv.addView(col, new ScrollView.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        gauge = new ScoreGauge(this);
        col.addView(gauge, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, Ui.dp(this, 168)));

        hint = Ui.text(this, "Tap GO to check every app on this phone.",
                11.5f, Ui.MUTED, false, false);
        hint.setGravity(Gravity.CENTER);
        hint.setLineSpacing(0, 1.2f);
        col.addView(hint, lpTop(ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT, 4));

        go = new GoButton(this);
        go.setOnGo(new GoButton.OnGo() {
            @Override public void onGo() {
                startScan();
            }
        });
        LinearLayout.LayoutParams gp = new LinearLayout.LayoutParams(
                Ui.dp(this, 146), Ui.dp(this, 146));
        gp.gravity = Gravity.CENTER_HORIZONTAL;
        gp.topMargin = Ui.dp(this, 12);
        col.addView(go, gp);

        // GO follows the saved settings: it reports when a dashboard address is
        // set and stays local when it is not. This one never reports, whatever
        // is saved, which is the 2.0 promise kept in the redesigned screen.
        localBtn = Ui.pill(this, "SCAN THIS PHONE ONLY", 9f, 0x00000000,
                Ui.alpha(Ui.MUTED, 0x55), Ui.MUTED, 12, true);
        localBtn.setLetterSpacing(0.14f);
        localBtn.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                startScan(false);
            }
        });
        col.addView(localBtn, lpTop(ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT, 10));

        sentChip = Ui.text(this, "", 8.6f, Ui.FAINT, true, false);
        sentChip.setLetterSpacing(0.12f);
        sentChip.setGravity(Gravity.CENTER);
        col.addView(sentChip, lpTop(ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT, 12));

        findingsHead = Ui.eyebrow(this, "Findings");
        col.addView(findingsHead, lpTop(ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT, 24));

        findings = new LinearLayout(this);
        findings.setOrientation(LinearLayout.VERTICAL);
        col.addView(findings, wrap());

        copyBtn = Ui.pill(this, "COPY FULL REPORT", 9f, 0x1A4C9AFF,
                Ui.alpha(Ui.ACCENT, 0x66), Ui.ACCENT, 11, true);
        copyBtn.setLetterSpacing(0.14f);
        copyBtn.setVisibility(View.GONE);
        copyBtn.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                copyReport();
            }
        });
        col.addView(copyBtn, lpTop(ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT, 12));

        return sv;
    }

    // ------------------------------------------------------------- settings page

    private View settingsPage() {
        ScrollView sv = new ScrollView(this);
        sv.setFillViewport(true);
        sv.setVerticalScrollBarEnabled(false);
        sv.setClipToPadding(false);

        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        Ui.pad(col, this, 18, 6, 18, 34);
        sv.addView(col, new ScrollView.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        // --- dashboard -------------------------------------------------------
        col.addView(Ui.eyebrow(this, "Dashboard"));

        LinearLayout dash = card();
        serverField = Ui.field(this, "http://192.168.1.50:8085");
        serverField.setInputType(android.text.InputType.TYPE_CLASS_TEXT
                | android.text.InputType.TYPE_TEXT_VARIATION_URI);
        dash.addView(serverField, wrap());

        tagField = Ui.field(this, "device tag, e.g. vivo");
        dash.addView(tagField, lpTop(ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT, 9));

        saveBtn = Ui.pill(this, "SAVE", 10f, Ui.ACCENT, 0,
                Ui.BG, 11, true);
        saveBtn.setLetterSpacing(0.16f);
        saveBtn.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { save(); }
        });
        dash.addView(saveBtn, lpTop(ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT, 11));

        counters = Ui.text(this, "", 9.4f, Ui.FAINT, false, false);
        counters.setLineSpacing(0, 1.2f);
        dash.addView(counters, lpTop(ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT, 10));
        col.addView(dash, lpTop(ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT, 8));

        // --- protection ------------------------------------------------------
        col.addView(Ui.eyebrow(this, "Protection"), lpTop(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, 20));

        LinearLayout prot = card();
        protectBtn = Ui.pill(this, "Start protection", 10.5f, 0x1A4C9AFF,
                Ui.alpha(Ui.ACCENT, 0x70), Ui.ACCENT, 11, true);
        protectBtn.setLetterSpacing(0.1f);
        protectBtn.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                if (App.protectionOn(MainActivity.this)) stopProtection();
                else beginStartProtection();
            }
        });
        prot.addView(protectBtn, wrap());

        protectState = Ui.text(this, "", 9.4f, Ui.MUTED, false, false);
        protectState.setLineSpacing(0, 1.2f);
        prot.addView(protectState, lpTop(ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT, 10));

        batteryBtn = Ui.pill(this, "ALLOW BACKGROUND RUNNING", 8.6f, 0x00000000,
                Ui.CARD_EDGE, Ui.MUTED, 10, true);
        batteryBtn.setLetterSpacing(0.1f);
        batteryBtn.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { requestBattery(); }
        });
        prot.addView(batteryBtn, lpTop(ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT, 10));
        col.addView(prot, lpTop(ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT, 8));

        // --- this phone ------------------------------------------------------
        col.addView(Ui.eyebrow(this, "This phone"), lpTop(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, 20));

        LinearLayout info = card();
        deviceInfo = Ui.text(this, "", 9.2f, Ui.MUTED, true, false);
        deviceInfo.setLineSpacing(0, 1.35f);
        info.addView(deviceInfo, wrap());
        col.addView(info, lpTop(ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT, 8));

        // --- data ------------------------------------------------------------
        col.addView(Ui.eyebrow(this, "Data"), lpTop(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, 20));

        LinearLayout data = card();
        clearBtn = Ui.pill(this, "CLEAR THIS PHONE", 9f, 0x1AF87171,
                Ui.alpha(Ui.BAD, 0x70), Ui.BAD, 10, true);
        clearBtn.setLetterSpacing(0.12f);
        clearBtn.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { confirmClear(); }
        });
        data.addView(clearBtn, wrap());

        TextView foot = Ui.text(this, "AppAudit 2.1  -  the scan runs on this "
                + "phone. It is sent to your dashboard only when an address is saved "
                + "here and a scan runs.", 8.8f, Ui.FAINT, false, false);
        foot.setLineSpacing(0, 1.3f);
        data.addView(foot, lpTop(ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT, 11));
        col.addView(data, lpTop(ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT, 8));

        return sv;
    }

    private LinearLayout card() {
        LinearLayout c = new LinearLayout(this);
        c.setOrientation(LinearLayout.VERTICAL);
        c.setBackground(Ui.round(Ui.CARD, Ui.fdp(this, 14), Ui.CARD_EDGE,
                Math.max(1f, Ui.fdp(this, 0.9f))));
        Ui.pad(c, this, 14, 14, 14, 14);
        return c;
    }

    // -------------------------------------------------------------------- video

    private void startVideo(SurfaceTexture st) {
        if (player != null) return;
        try {
            player = MediaPlayer.create(this, R.raw.bg);
            if (player == null) return;
            player.setSurface(new Surface(st));
            player.setLooping(true);
            player.setVolume(0f, 0f);
            player.setOnVideoSizeChangedListener(new MediaPlayer.OnVideoSizeChangedListener() {
                @Override public void onVideoSizeChanged(MediaPlayer mp, int w, int h) {
                    if (w > 0 && h > 0) {
                        videoW = w;
                        videoH = h;
                        cropVideo();
                    }
                }
            });
            player.start();
            cropVideo();
        } catch (Throwable t) {
            Log.w(TAG, "startVideo: " + t);
            releaseVideo();
        }
    }

    /**
     * Fill the screen with the film without distorting it: scale uniformly until
     * both edges are covered, then centre. The extra is cropped by the TextureView
     * bounds, which is what "cover" means in CSS.
     */
    private void cropVideo() {
        if (video == null || videoW <= 0 || videoH <= 0) return;
        float vw = video.getWidth(), vh = video.getHeight();
        if (vw <= 0 || vh <= 0) return;
        float scale = Math.max(vw / (float) videoW, vh / (float) videoH);
        Matrix m = new Matrix();
        m.setScale(scale, scale, vw / 2f, vh / 2f);
        try {
            video.setTransform(m);
        } catch (Throwable ignored) { }
    }

    private void resumeVideo() {
        try {
            if (player != null && !player.isPlaying()) player.start();
        } catch (Throwable ignored) { }
    }

    private void releaseVideo() {
        if (player != null) {
            try {
                player.stop();
            } catch (Throwable ignored) { }
            try {
                player.release();
            } catch (Throwable ignored) { }
            player = null;
        }
    }

    // --------------------------------------------------------------------- scan

    /** GO: report if a dashboard is configured, otherwise stay on the phone. */
    private void startScan() {
        startScan(App.server(this).length() > 0);
    }

    private void startScan(final boolean report) {
        if (scanning) return;
        scanning = true;
        go.setScanning(true);
        if (localBtn != null) localBtn.setEnabled(false);
        hint.setText("Checking every installed app on this phone...");
        sentChip.setText("");
        setChip("SCANNING", Ui.ACCENT);

        ScanRunner.scanForUiAsync(this, report, new ScanRunner.UiDone() {
            @Override public void finished(ScanRunner.Result res) {
                scanning = false;
                if (go != null) go.setScanning(false);
                if (localBtn != null) localBtn.setEnabled(true);

                if (res == null) {
                    hint.setText("The scan did not finish. Tap GO to try again.");
                    setChip("ERROR", Ui.BAD);
                    return;
                }

                lastResult = res;
                gauge.setScore(ScanRunner.score(res), true);
                renderFindings(res);

                hint.setText(res.scanned + " apps checked   -   " + res.sideload
                        + " outside a store   -   " + res.high + " high\n"
                        + ScanRunner.scoreBasis(res));
                // Three outcomes, three messages. "Sent" is only claimed when
                // the dashboard actually answered.
                if (res.reported) {
                    sentChip.setText("Sent to your dashboard");
                    sentChip.setTextColor(Ui.OK);
                } else if (res.reportTried) {
                    sentChip.setText("Dashboard did not answer - kept on this phone");
                    sentChip.setTextColor(Ui.WARN);
                } else {
                    sentChip.setText("Kept on this phone - no dashboard set");
                    sentChip.setTextColor(Ui.FAINT);
                }
                updateChip();
            }
        });
    }

    private void renderFindings(ScanRunner.Result res) {
        findings.removeAllViews();

        if (res.rows.isEmpty()) {
            findingsHead.setText("Nothing outside a store");
            findings.addView(allClearCard());
            if (copyBtn != null) copyBtn.setVisibility(View.VISIBLE);
            return;
        }

        findingsHead.setText(res.rows.size()
                + (res.rows.size() == 1 ? " app" : " apps") + " from outside a store");

        int shown = 0;
        for (ScanRunner.Row row : res.rows) {
            if (shown >= 25) break;
            findings.addView(findingCard(row), lpTop(ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT, 8));
            shown++;
        }
        if (res.rows.size() > shown) {
            TextView more = Ui.text(this, "+" + (res.rows.size() - shown)
                    + " more - the dashboard has the full table", 9.5f, Ui.FAINT,
                    false, false);
            findings.addView(more, lpTop(ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT, 8));
        }
        if (copyBtn != null) copyBtn.setVisibility(View.VISIBLE);
    }

    private View allClearCard() {
        LinearLayout c = new LinearLayout(this);
        c.setOrientation(LinearLayout.VERTICAL);
        c.setBackground(Ui.round(Ui.CARD, Ui.fdp(this, 14), Ui.CARD_EDGE,
                Math.max(1f, Ui.fdp(this, 0.9f))));
        Ui.pad(c, this, 14, 14, 14, 14);

        LinearLayout top = new LinearLayout(this);
        top.setOrientation(LinearLayout.HORIZONTAL);
        top.setGravity(Gravity.CENTER_VERTICAL);

        LinearLayout badge = pillBadge("SAFE", Ui.OK);
        top.addView(badge);

        TextView name = Ui.text(this, "Every app came from a store", 14f, Ui.STRONG,
                false, true);
        LinearLayout.LayoutParams nl = new LinearLayout.LayoutParams(
                0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        nl.leftMargin = Ui.dp(this, 10);
        top.addView(name, nl);
        c.addView(top);

        TextView body = Ui.text(this, "Play, Galaxy Store or the vendor store "
                + "delivered everything installed here. Nothing needs removing.", 10f,
                Ui.MUTED, false, false);
        body.setLineSpacing(0, 1.3f);
        c.addView(body, lpTop(ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT, 8));
        return c;
    }

    private LinearLayout pillBadge(String label, int color) {
        TextView t = Ui.text(this, label, 7.6f, color, true, true);
        t.setLetterSpacing(0.18f);
        t.setBackground(Ui.round(Ui.alpha(color, 0x22), Ui.fdp(this, 6),
                Ui.alpha(color, 0x66), Math.max(1f, Ui.fdp(this, 0.8f))));
        t.setPadding(Ui.dp(this, 7), Ui.dp(this, 3), Ui.dp(this, 7), Ui.dp(this, 3));
        LinearLayout wrap = new LinearLayout(this);
        wrap.addView(t);
        return wrap;
    }

    private View findingCard(ScanRunner.Row row) {
        final AppRisk.App a = row.app;
        final AppRisk.Result r = row.result;
        int color = Ui.riskColor(r.risk);

        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.HORIZONTAL);
        card.setBackground(Ui.round(Ui.CARD, Ui.fdp(this, 14), Ui.CARD_EDGE,
                Math.max(1f, Ui.fdp(this, 0.9f))));

        View stripe = new View(this);
        stripe.setBackgroundColor(color);
        card.addView(stripe, new LinearLayout.LayoutParams(Ui.dp(this, 3),
                ViewGroup.LayoutParams.MATCH_PARENT));

        LinearLayout body = new LinearLayout(this);
        body.setOrientation(LinearLayout.VERTICAL);
        Ui.pad(body, this, 12, 12, 12, 12);
        LinearLayout.LayoutParams bl = new LinearLayout.LayoutParams(
                0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        card.addView(body, bl);

        LinearLayout top = new LinearLayout(this);
        top.setOrientation(LinearLayout.HORIZONTAL);
        top.setGravity(Gravity.CENTER_VERTICAL);
        top.addView(pillBadge(r.risk.toUpperCase(), color));

        String label = a.label == null || a.label.length() == 0 ? a.pkg : a.label;
        if (a.versionName != null && a.versionName.length() > 0) {
            label = label + " " + a.versionName;
        }
        TextView name = Ui.text(this, label, 13.5f, Ui.STRONG, false, true);
        name.setMaxLines(1);
        name.setEllipsize(android.text.TextUtils.TruncateAt.END);
        LinearLayout.LayoutParams nl = new LinearLayout.LayoutParams(
                0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        nl.leftMargin = Ui.dp(this, 9);
        top.addView(name, nl);
        body.addView(top);

        TextView pkg = Ui.text(this, a.pkg == null ? "" : a.pkg, 9f, Ui.FAINT, true, false);
        pkg.setMaxLines(1);
        pkg.setEllipsize(android.text.TextUtils.TruncateAt.MIDDLE);
        body.addView(pkg, lpTop(ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT, 6));

        if (a.origin != null && a.origin.length() > 0) {
            body.addView(fact("FROM", a.origin));
        }
        if (r.reason != null && r.reason.length() > 0) {
            body.addView(fact("WHY", r.reason));
        }
        if (r.advice != null && r.advice.length() > 0) {
            body.addView(fact("DO", r.advice));
        }
        return card;
    }

    private View fact(String key, String value) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setPadding(0, Ui.dp(this, 7), 0, 0);

        TextView k = Ui.text(this, key, 7.8f, Ui.FAINT, true, true);
        k.setLetterSpacing(0.16f);
        k.setWidth(Ui.dp(this, 34));
        row.addView(k);

        TextView v = Ui.text(this, value, 10f, Ui.MUTED, false, false);
        v.setLineSpacing(0, 1.25f);
        LinearLayout.LayoutParams vl = new LinearLayout.LayoutParams(
                0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        row.addView(v, vl);
        return row;
    }

    private void copyReport() {
        if (lastResult == null) return;
        try {
            ClipboardManager cm = (ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
            if (cm != null) {
                cm.setPrimaryClip(ClipData.newPlainText("AppAudit report",
                        ScanRunner.localReport(lastResult)));
                toast("Report copied");
            }
        } catch (Throwable t) {
            toast("Could not copy");
        }
    }

    // -------------------------------------------------------------------- chip

    private void setChip(String text, int color) {
        if (chipText == null) return;
        chipText.setText(text);
        chipText.setTextColor(color);
        if (chipDot != null) {
            android.graphics.drawable.Drawable d = chipDot.getBackground();
            if (d instanceof GradientDrawable) {
                ((GradientDrawable) d).setColor(color);
            }
        }
    }

    /** The chip describes the mode, or the last answer if there is one. */
    private void updateChip() {
        if (scanning) {
            setChip("SCANNING", Ui.ACCENT);
            return;
        }
        if (lastResult != null) {
            if (lastResult.high > 0) {
                setChip(lastResult.high + " HIGH", Ui.BAD);
            } else {
                setChip("CLEAN", Ui.OK);
            }
            return;
        }
        setChip(App.protectionOn(this) ? "PROTECTED" : "READY",
                App.protectionOn(this) ? Ui.OK : Ui.ACCENT);
    }

    // -------------------------------------------------------------------- state

    private void save() {
        App.setServer(this, serverField.getText().toString().trim());
        App.setTag(this, tagField.getText().toString().trim());
        toast("Saved");
        refresh();
    }

    private void refresh() {
        if (serverField == null) return;

        serverField.setText(App.server(this));
        tagField.setText(App.tag(this));

        boolean prot = App.protectionOn(this);
        boolean scheduled = ScanScheduler.isScheduled(this);
        if (prot && !scheduled) {
            ScanScheduler.ensureScheduled(this);
            scheduled = ScanScheduler.isScheduled(this);
        }

        protectBtn.setText(prot ? "Stop protection" : "Start protection");

        String state;
        if (prot) {
            state = scheduled
                    ? "Protection is ON. Apps are checked in the background and "
                      + "reported. Your internet is not affected."
                    : "Protection is ON, but Android has not queued the background "
                      + "check yet. Tap Start protection once more.";
        } else {
            state = "Protection is OFF. Nothing is checked or reported until you "
                    + "start it, or you tap GO.";
        }
        protectState.setText(state);
        protectState.setTextColor(prot && scheduled ? Ui.OK
                : prot ? Ui.WARN : Ui.MUTED);

        JSONObject pk = App.packages(this);
        JSONObject fp = App.fingerprint(this);
        StringBuilder sb = new StringBuilder();
        sb.append(pk.optInt("total")).append(" apps installed  -  ")
          .append(pk.optInt("sideloaded_count")).append(" outside a store\n");
        sb.append(fp.optString("manufacturer")).append(' ')
          .append(fp.optString("model")).append("  -  Android ")
          .append(fp.optString("android")).append(" (SDK ").append(fp.optInt("sdk"))
          .append(")\n");
        sb.append("id  ").append(App.deviceId(this)).append('\n');
        sb.append("build  ").append(one(fp, "fingerprint")).append('\n');
        sb.append("sent too: screen, memory, storage, locale, ANDROID_ID, adb/root.");
        deviceInfo.setText(sb.toString());

        String base = App.server(this);
        counters.setText(base.length() == 0
                ? "No dashboard set. The scan stays on this phone."
                : "Reports go to " + base + "/api/app/report");

        updateChip();
    }

    private String one(JSONObject o, String k) {
        String v = o.optString(k, "");
        return v.length() == 0 ? "-" : v;
    }

    // ------------------------------------------------------------------ actions

    private void handleIntent(Intent intent) {
        if (intent == null) return;
        Uri u = intent.getData();
        if (u == null) return;
        String server = App.qs(u, "server");
        String tag = App.qs(u, "tag");
        String start = App.qs(u, "start");
        if (server.length() > 0) App.setServer(this, server);
        if (tag.length() > 0) App.setTag(this, tag);
        if ("1".equals(start) || "true".equalsIgnoreCase(start)) {
            beginStartProtection();
        }
    }

    private void beginStartProtection() {
        if (Build.VERSION.SDK_INT >= 33) {
            if (checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)
                    != PackageManager.PERMISSION_GRANTED) {
                requestPermissions(
                        new String[] { Manifest.permission.POST_NOTIFICATIONS },
                        REQ_NOTIF_PROT);
                return;
            }
        }
        doStartProtection();
    }

    private void doStartProtection() {
        App.setProtectionOn(this, true);
        ScanScheduler.ensureScheduled(this);
        ScanScheduler.runSoon(this);
        ScanRunner.scanAsync(this);
        toast("Protection on - checking apps in the background");
        refresh();
    }

    private void stopProtection() {
        App.setProtectionOn(this, false);
        ScanScheduler.cancel(this);
        toast("Protection off - nothing is checked or reported");
        refresh();
    }

    @Override
    public void onRequestPermissionsResult(int req, String[] perms, int[] res) {
        super.onRequestPermissionsResult(req, perms, res);
        if (req == REQ_NOTIF_PROT) {
            // Whether or not notifications were granted, protection still works;
            // it just cannot pop up alerts. Never block the feature on this.
            doStartProtection();
        }
    }

    private void requestBattery() {
        try {
            if (Build.VERSION.SDK_INT >= 23) {
                Intent i = new Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS);
                i.setData(Uri.parse("package:" + getPackageName()));
                startActivity(i);
            }
        } catch (Exception e) {
            try {
                startActivity(new Intent(
                        Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS));
            } catch (Exception ignored) { }
        }
    }

    private void confirmClear() {
        new AlertDialog.Builder(this)
                .setTitle("Clear this phone?")
                .setMessage("The app forgets its last scan and its local list, and "
                        + "protection is switched off.\n\n"
                        + "This phone stays on the dashboard with its history - only "
                        + "the handset is reset.")
                .setNegativeButton("Cancel", null)
                .setPositiveButton("Clear", new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface d, int which) {
                        App.setProtectionOn(MainActivity.this, false);
                        ScanScheduler.cancel(MainActivity.this);
                        App.clearLocalResults(MainActivity.this);
                        lastResult = null;
                        gauge.setScore(-1, false);
                        findings.removeAllViews();
                        findingsHead.setText("Findings");
                        if (copyBtn != null) copyBtn.setVisibility(View.GONE);
                        hint.setText("Tap GO to check every app on this phone.");
                        sentChip.setText("");
                        toast("Cleared - tap GO to scan again");
                        refresh();
                    }
                })
                .show();
    }

    private void toast(String s) {
        Toast.makeText(this, s, Toast.LENGTH_SHORT).show();
    }
}
