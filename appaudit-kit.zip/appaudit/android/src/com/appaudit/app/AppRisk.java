package com.appaudit.app;

import java.util.ArrayList;
import java.util.List;

/**
 * Decides how risky one installed app is.
 *
 * This class has NO Android imports on purpose. That means the exact scoring
 * that runs on the phone can also be run and checked on a desktop JVM, which is
 * how it is tested. Every rule below is a signal an app cannot avoid revealing
 * without root, so the result is honest about what it measured.
 *
 * WHAT IT LOOKS AT
 *   where the app came from, whether it is debuggable, which dangerous
 *   capabilities it declared, and - most important - which of those are actually
 *   SWITCHED ON right now (accessibility, device admin, notification access).
 *   An app that merely declares "read your texts" is far less alarming than one
 *   that is currently drawing over the screen with accessibility enabled.
 *
 * SCORING
 *   Signals add up, because any single one is normal on its own: plenty of
 *   legitimate apps read contacts, and plenty are installed outside a store.
 *   A high score needs either a dangerous capability that is switched on, or
 *   several suspicious things together.
 *
 *       6 or more  -> Critical   act now, the app can already harm the user
 *       3 to 5     -> High       review it, something does not add up
 *       below 3    -> Safe       nothing measurable stood out
 */
final class AppRisk {

    // The two levels the dashboard shows, and the only two there are.
    static final String SAFE = "Safe";
    static final String HIGH = "High";

    private AppRisk() {}

    /** Everything measured about one installed app. */
    static final class App {
        String pkg = "";
        String label = "";
        String versionName = "";
        String installer = "";        // who performed the install
        String initiating = "";       // who started it: Play, a browser, adb
        String originating = "";      // where the file originally came from
        String origin = "";           // the human answer for "Installed from"
        int packageSource = -1;       // Android 13+ PackageSource, -1 unknown
        boolean fromStore = false;    // the platform says a store delivered it
        String sha256 = "";           // fingerprint of the APK file itself
        String signerSha256 = "";     // fingerprint of the signing certificate
        long versionCode = 0L;
        long sizeBytes = 0L;
        long firstInstall = 0L;       // epoch ms
        long lastUpdate = 0L;
        int targetSdk = 0;
        boolean system = false;
        boolean debuggable = false;
        boolean sideloaded = false;
        /** Capabilities that are switched ON right now, not just declared. */
        boolean accessibilityOn = false;
        boolean deviceAdminOn = false;
        boolean notifAccessOn = false;
        String[] permissions = new String[0];

        // ---- evidence from reading the APK file itself ------------------
        // Deliberately plain types: this class has no Android imports so the
        // scoring can be tested on a desktop JVM, and that only works if the
        // file evidence arrives as booleans rather than as a PackageManager
        // object. AppScanner copies these across from ApkInspector.
        boolean inspected = false;      // was any part of the file readable
        boolean dexRead = false;        // did the string scan actually run
        boolean packed = false;
        boolean nestedArchive = false;
        boolean dynamicCode = false;
        boolean rootTools = false;
        boolean smsSend = false;
        boolean c2Strings = false;
        boolean obfuscated = false;
        boolean cleartext = false;
        boolean allowBackup = false;
        boolean hidden = false;         // no launcher icon, not a system app
        boolean disabled = false;
        boolean multiSigner = false;
        boolean signerChanged = false;
        int exportedUnprotected = 0;
        int httpUrls = 0;
        int dexCount = 0;
        String packerName = "";
        List<String> fileEvidence = new ArrayList<String>();
    }

    /** The rating for one app: Safe or High, and why. */
    static final class Result {
        String risk = SAFE;
        String reason = "";
        String advice = "";
        String source = "Store";
        int score = 0;
        /** One plain sentence for the dashboard summary line. */
        String summary = "";
    }

    /** Installers that mean "this came from a real store". */
    private static final String[] KNOWN_STORES = {
            "com.android.vending",          // Google Play
            "com.google.android.feedback",
            "org.fdroid.fdroid",            // F-Droid
            "com.amazon.venezia",           // Amazon Appstore
            "com.huawei.appmarket",         // Huawei AppGallery
            "com.sec.android.app.samsungapps",
            "com.xiaomi.mipicks",           // Xiaomi GetApps
            "com.heytap.market",
            "com.oppo.market",
            "com.vivo.appstore",
            "com.bbk.appstore",
            "com.transsion.appstore",
            // The package installer is deliberately NOT here. It is the route a
            // downloaded .apk takes when somebody taps it in Files or a browser,
            // which is exactly the app this table exists to show. adb installs
            // report com.android.shell and are outside a store for the same
            // reason.
            // Preload updaters. A phone that ships with Facebook (Samsung, vivo,
            // OPPO and others) reports com.facebook.system as the installer, not
            // Play. Without these the preinstalled app looked "sideloaded" and
            // was flagged High on a phone where nobody had installed anything.
            "com.facebook.system",
            "com.facebook.appmanager",
            "com.facebook.services"
    };

    /**
     * Brands that get cloned constantly, with the EXACT packages that truly
     * belong to them.
     *
     * Exact matching, not prefix and not substring. A prefix test lets
     * "com.whatsapp.gold" through because it starts with "com.whatsapp", which
     * is precisely the clone that matters. A substring test flags honest apps
     * that merely mention a brand. Only a full package name is trustworthy, so
     * only a full package name is treated as legitimate.
     *
     * The brand token must also appear as a whole dot-separated segment, so
     * "com.example.whatsapp" is flagged while "com.notwhatsapp.app" is not.
     * Brands whose real package list cannot be stated with confidence are left
     * out entirely: a wrong accusation is worse than a missing one.
     */
    private static final String[][] BRANDS = {
            { "whatsapp",  "com.whatsapp,com.whatsapp.w4b" },
            { "paypal",    "com.paypal.android.p2pmobile,com.paypal.here" },
            { "binance",   "com.binance.dev" },
            { "coinbase",  "com.coinbase.android" },
            { "metamask",  "io.metamask" },
            { "netflix",   "com.netflix.mediaclient" },
            { "spotify",   "com.spotify.music" },
            { "facebook",  "com.facebook.katana,com.facebook.lite,com.facebook.orca" },
            { "instagram", "com.instagram.android" },
            { "telegram",  "org.telegram.messenger,org.thunderdog.challegram" },
            { "shopee",    "com.shopee.id,com.shopee.ph,com.shopee.sg,com.shopee.my,com.shopee.th,com.shopee.vn,com.shopee.br,com.shopee.tw,com.shopee.co.id" },
            { "tokopedia", "com.tokopedia.tokopedia" },
            { "dana",      "id.dana" },
            { "ovo",       "id.co.ovo" },
            { "grab",      "com.grabtaxi.passenger" },
    };

    private static boolean isKnownStore(String installer) {
        if (installer == null || installer.length() == 0) return false;
        for (String s : KNOWN_STORES) {
            if (s.equalsIgnoreCase(installer)) return true;
        }
        return false;
    }

    private static boolean has(String[] perms, String name) {
        if (perms == null) return false;
        for (String p : perms) {
            if (p != null && p.equals(name)) return true;
        }
        return false;
    }

    /**
     * "whatsapp" when the package claims the brand without being the real app.
     * Returns "" when the package is genuinely the brand's, or mentions nothing.
     */
    private static String impersonatedBrand(String pkg) {
        String p = pkg == null ? "" : pkg.trim().toLowerCase();
        if (p.length() == 0) return "";

        // Whole segments only: com.example.whatsapp -> yes
        //                     com.notwhatsapp.app -> no
        String[] segs = p.split("\\.");

        for (String[] brand : BRANDS) {
            String token = brand[0];
            String[] official = brand[1].split(",");

            boolean claims = false;
            for (String s : segs) {
                if (s.equals(token)) { claims = true; break; }
            }
            if (!claims) continue;

            boolean genuine = false;
            for (String o : official) {
                if (o.trim().equalsIgnoreCase(p)) { genuine = true; break; }
            }
            if (!genuine) return token;
        }
        return "";
    }

    /**
     * Score one app. The most dangerous finding is reported first, because a
     * user reading one line should see the reason that actually matters.
     */
    static Result score(App a) {
        Result r = new Result();
        if (a == null) return r;

        // The phone's own answer about where the app came from, so the table
        // can say "Opened by Chrome" or "Local file" instead of a bare
        // "Sideload" that hides how the app actually arrived.
        if (a.system) r.source = "System";
        else if (a.origin != null && a.origin.length() > 0) r.source = a.origin;
        else if (a.sideloaded) r.source = "Outside a store";
        else r.source = "Store";

        List<String> why = new ArrayList<String>();
        List<String> urgent = new ArrayList<String>();

        // ---- where did it come from -------------------------------------
        // Arriving outside a store is why this app is on the table at all, not
        // a finding about it. It used to add 5 points, which pushed every
        // listed app over the High line and made the Safe level unreachable.
        // High is now earned on what the app can actually do.

        // ---- capabilities that are switched on right now -----------------
        if (a.accessibilityOn) {
            r.score += 4;
            urgent.add("accessibility service is ON - it can read the screen and tap for you");
        }
        if (a.deviceAdminOn) {
            r.score += 4;
            urgent.add("has device-admin rights - it can lock or wipe this phone");
        }
        if (a.notifAccessOn) {
            r.score += 3;
            urgent.add("can read every notification, including one-time passwords");
        }
        if (a.debuggable) {
            r.score += 4;
            why.add("debuggable build - not a normal release");
        }

        // ---- dangerous permissions ---------------------------------------
        String[] p = a.permissions;
        boolean net = has(p, "android.permission.INTERNET");
        boolean sms = has(p, "android.permission.READ_SMS")
                || has(p, "android.permission.RECEIVE_SMS")
                || has(p, "android.permission.READ_SMS_MESSAGES");
        if (sms && net) {
            r.score += 4;
            urgent.add("can read your text messages and send them off the phone");
        } else if (sms) {
            r.score += 2;
            why.add("reads your text messages");
        }
        if (has(p, "android.permission.BIND_ACCESSIBILITY_SERVICE")) {
            r.score += 2;
            why.add("declares an accessibility service");
        }
        if (has(p, "android.permission.BIND_DEVICE_ADMIN")) {
            r.score += 2;
            why.add("declares a device-admin receiver");
        }
        if (has(p, "android.permission.REQUEST_INSTALL_PACKAGES")) {
            r.score += 2;
            why.add("can install other apps");
        }
        if (has(p, "android.permission.SYSTEM_ALERT_WINDOW")) {
            r.score += 2;
            why.add("can draw over other apps");
        }
        if (has(p, "android.permission.BIND_NOTIFICATION_LISTENER_SERVICE")) {
            r.score += 2;
            why.add("declares notification access");
        }
        // Contacts, camera, microphone and CALL_PHONE are deliberately NOT
        // scored, alone or in combination. Every chat, banking and shopping app
        // asks for them, and counting them flagged both WhatsApp and a real
        // bank as risky during testing. A rule that fires on normal software is
        // worse than no rule: it trains the user to ignore the warning.
        //
        // Scoring instead rests on things a legitimate app has no reason to do:
        // arriving outside a store, running a switched-on accessibility or
        // device-admin service, reading every notification, or hiding a
        // dropper behind install/overlay permissions.

        // ---- pretending to be someone else ------------------------------
        String fake = impersonatedBrand(a.pkg);
        if (fake.length() > 0) {
            r.score += 4;
            urgent.add("uses the " + fake + " name but is not the official " + fake + " app");
        }

        // ---- built for a long-dead Android ------------------------------
        if (a.targetSdk > 0 && a.targetSdk < 23) {
            r.score += 1;
            why.add("built for Android " + a.targetSdk + " or older, before runtime permissions");
        }

        // ---- a system app is far less likely to be the work of a user-installed scam
        if (a.system) {
            r.score -= 2;
        }
        if (r.score < 0) r.score = 0;

        // Two levels, and only two: Safe or High. A third "Critical" tier was
        // removed because the same app could be called dramatic on one screen
        // and mild on another, and it left the operator arguing about where the
        // line sat instead of reading the evidence. Anything that scored high
        // enough to be Critical is still High - the score and the reasons are
        // unchanged, only the label got simpler.
        r.risk = r.score >= 3 ? HIGH : SAFE;

        // Urgent findings first: they are the reason the app was flagged.
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < urgent.size() && i < 3; i++) {
            if (sb.length() > 0) sb.append(" + ");
            sb.append(urgent.get(i));
        }
        for (int i = 0; i < why.size() && i < 3; i++) {
            if (sb.length() > 0) sb.append(" + ");
            sb.append(why.get(i));
        }
        r.reason = sb.length() == 0
                ? "outside-store apk, nothing dangerous switched on"
                : sb.toString();
        r.advice = adviceFor(r.risk, a);
        return r;
    }

    /** Guidance written to be read by a non-technical phone owner. */
    static String adviceFor(String risk, App a) {
        String name = (a == null || a.label == null || a.label.length() == 0)
                ? "this app" : a.label;
        if (HIGH.equals(risk)) {
            return "Check whether you installed " + name + " yourself. If you did not, "
                    + "uninstall it. If you did, open Settings, Apps, " + name
                    + " and switch off every permission it does not need, especially "
                    + "Accessibility, SMS and Notification access.";
        }
        return name + " came from outside a store and has nothing dangerous "
                + "switched on. If you installed it yourself, keep it; run the scan "
                + "again after its next update.";
    }

    /** "com.foo.bar" -> "foo" style short name, for logs. */
    static String shortName(String pkg) {
        if (pkg == null || pkg.length() == 0) return "?";
        String[] parts = pkg.split("\\.");
        return parts.length >= 2 ? parts[1] : pkg;
    }
}
