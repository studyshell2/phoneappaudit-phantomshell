package com.appaudit.app;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/**
 * Keeps protection running across a restart.
 *
 * Protection is the app scanner and its scheduled rescan, and it needs no VPN,
 * so this receiver only re-books work the system dropped. There is nothing here
 * that can change how the phone reaches the network.
 */
public class BootReceiver extends BroadcastReceiver {

    @Override
    public void onReceive(Context context, Intent intent) {
        if (context == null || intent == null) return;
        String action = intent.getAction();
        if (action == null) return;
        if (!Intent.ACTION_BOOT_COMPLETED.equals(action)
                && !Intent.ACTION_MY_PACKAGE_REPLACED.equals(action)) {
            return;
        }
        // Runs before any start decision, so an upgrade from a build that had the
        // VPN filter cannot leave stale flags armed behind it.
        App.migrate(context);
        // Gated on the owner's protection switch: a phone where protection was
        // deliberately turned off must not silently start scanning after a
        // reboot.
        if (App.protectionOn(context)) {
            ScanScheduler.ensureScheduled(context);
            ScanScheduler.runSoon(context);
        }
    }
}
