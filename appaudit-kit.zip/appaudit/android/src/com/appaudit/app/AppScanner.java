package com.appaudit.app;

import android.content.ComponentName;
import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.content.pm.InstallSourceInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.Signature;
import android.content.pm.SigningInfo;
import android.app.admin.DevicePolicyManager;
import android.provider.Settings;
import android.os.Build;
import android.util.Log;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * Reads every installed app and asks AppRisk what to make of it.
 *
 * Nothing here needs root. Every fact comes from PackageManager, the settings
 * database or the device-policy service, which is why the result is something
 * the user can check for themselves on the phone.
 *
 * The important distinction is between what an app DECLARES and what is
 * actually SWITCHED ON. Declared permissions are just a wish list; a switched-on
 * accessibility service or device-admin right means the app can already act.
 * Attackers rely on that gap, so the score weights the live state far higher.
 */
final class AppScanner {

    private static final String TAG = "PSScanner";

    /** Do not hash something absurd: gas for a runaway read, in bytes. */
    private static final long MAX_HASH_BYTES = 200L * 1024L * 1024L;

    private AppScanner() {}

    /**
     * Scan everything. Never throws; a broken package is skipped.
     *
     * Every installed package is returned, including ones with no launcher
     * icon and ones that are currently disabled - those are exactly where a
     * hidden app lives. The dex budget is shared across the whole run so a
     * phone with hundreds of apps cannot make the scan take forever.
     */
    static List<AppRisk.App> scanAll(Context c) {
        List<AppRisk.App> out = new ArrayList<AppRisk.App>();
        Set<String> accessibility = accessibilityPackages(c);
        Set<String> listeners = notificationListenerPackages(c);
        Set<String> admins = deviceAdminPackages(c);
        long[] budget = { ApkInspector.SCAN_BUDGET };
        try {
            PackageManager pm = c.getPackageManager();
            List<PackageInfo> all = pm.getInstalledPackages(0);
            if (all == null) return out;
            for (PackageInfo pi : all) {
                AppRisk.App a = read(c, pm, pi, accessibility, listeners, admins, budget);
                if (a != null) out.add(a);
            }
        } catch (Throwable t) {
            Log.w(TAG, "scanAll: " + t);
        }
        return out;
    }

    /** Scan exactly one package, for the install-time receiver. */
    static AppRisk.App scanOne(Context c, String pkg) {
        if (pkg == null || pkg.length() == 0) return null;
        try {
            PackageManager pm = c.getPackageManager();
            PackageInfo pi = pm.getPackageInfo(pkg, 0);
            long[] budget = { ApkInspector.SCAN_BUDGET };
            return read(c, pm, pi, accessibilityPackages(c),
                    notificationListenerPackages(c), deviceAdminPackages(c), budget);
        } catch (Throwable t) {
            Log.w(TAG, "scanOne " + pkg + ": " + t);
            return null;
        }
    }

    // ------------------------------------------------------------------ details

    private static AppRisk.App read(Context c, PackageManager pm, PackageInfo pi,
                                    Set<String> accessibility, Set<String> listeners,
                                    Set<String> admins, long[] budget) {
        try {
            if (pi == null || pi.applicationInfo == null) return null;
            ApplicationInfo ai = pi.applicationInfo;
            AppRisk.App a = new AppRisk.App();

            a.pkg = pi.packageName == null ? "" : pi.packageName;
            if (a.pkg.length() == 0) return null;
            // Never flag the guard itself.
            if (a.pkg.equals(c.getPackageName())) return null;

            try {
                CharSequence l = pm.getApplicationLabel(ai);
                a.label = l == null ? a.pkg : l.toString();
            } catch (Throwable t) {
                a.label = a.pkg;
            }

            a.versionName = pi.versionName == null ? "" : pi.versionName;
            a.versionCode = Build.VERSION.SDK_INT >= 28
                    ? pi.getLongVersionCode()
                    : (long) pi.versionCode;
            a.firstInstall = pi.firstInstallTime;
            a.lastUpdate = pi.lastUpdateTime;

            a.system = (ai.flags & ApplicationInfo.FLAG_SYSTEM) != 0;
            a.debuggable = (ai.flags & ApplicationInfo.FLAG_DEBUGGABLE) != 0;
            a.targetSdk = ai.targetSdkVersion;

            // Where this app actually came from.
            //
            // The installing package alone cannot answer it: on vivo, Samsung
            // and any app-bundle install the Play Store hands the work to the
            // package installer, so a genuine store app reports
            // com.google.android.packageinstaller. That is why Netflix and
            // Spotify were being listed as sideloads. Android 13 answers
            // outright with PackageSource, and below that the initiating
            // package still names the store.
            Origin org = originOf(pm, a.pkg);
            a.installer = org.installer;
            a.initiating = org.initiating;
            a.originating = org.originating;
            a.packageSource = org.source;
            a.fromStore = org.store;
            a.origin = org.label(pm);
            a.sideloaded = !a.fromStore;

            a.accessibilityOn = accessibility.contains(a.pkg);
            a.notifAccessOn = listeners.contains(a.pkg);
            a.deviceAdminOn = admins.contains(a.pkg);

            a.permissions = pi.requestedPermissions == null
                    ? new String[0] : pi.requestedPermissions;

            String dir = ai.publicSourceDir;
            if (dir != null) {
                File f = new File(dir);
                a.sizeBytes = f.length();
                a.sha256 = sha256File(f);
            }
            a.signerSha256 = signerOf(pm, a.pkg);

            // ----------------------------------------------------------
            // Read the package itself. This is the deep half of the scan:
            // every package gets its archive opened, and user-installed ones
            // also get their dex strings examined, until the shared budget
            // for this scan runs out.
            // ----------------------------------------------------------
            boolean deep = !a.system && budget[0] > 0;
            ApkInspector.Findings f = ApkInspector.inspect(c, pm, pi, budget[0], deep);
            budget[0] -= f.spentBytes;

            a.inspected = f.inspected;
            a.dexRead = f.dexRead;
            a.packed = f.packed;
            a.packerName = f.packerName;
            a.nestedArchive = f.nestedArchive;
            a.dynamicCode = f.dynamicCode;
            a.rootTools = f.rootTools;
            a.smsSend = f.smsSend;
            a.c2Strings = f.c2Strings;
            a.obfuscated = f.obfuscated;
            a.cleartext = f.cleartext;
            a.allowBackup = f.allowBackup;
            a.hidden = f.hidden;
            a.disabled = f.disabled;
            a.multiSigner = f.multiSigner;
            a.exportedUnprotected = f.exportedUnprotected;
            a.httpUrls = f.httpUrls;
            a.dexCount = f.dexCount;
            a.fileEvidence = f.evidence;
            a.signerChanged = rememberSigner(c, a.pkg, a.signerSha256);
            return a;
        } catch (Throwable t) {
            Log.w(TAG, "read: " + t);
            return null;
        }
    }

    /**
     * Remember which key each package was signed with, and notice a change.
     *
     * An app update signed by a different certificate than the one already on
     * the phone is not a normal event: Android itself refuses to install it
     * over the old one unless the old app was removed first. Seeing a new key
     * therefore means either a deliberate reinstall or a rebuilt, tampered
     * package. It is recorded once and then accepted, so it alerts rather than
     * shouting forever.
     */
    private static boolean rememberSigner(Context c, String pkg, String signer) {
        if (pkg == null || pkg.length() == 0 || signer == null || signer.length() == 0) {
            return false;
        }
        try {
            android.content.SharedPreferences p = App.prefs(c);
            String key = "sig:" + pkg;
            String old = p.getString(key, "");
            if (old.length() == 0) {
                p.edit().putString(key, signer).apply();
                return false;
            }
            if (old.equals(signer)) return false;
            p.edit().putString(key, signer).apply();
            return true;
        } catch (Throwable t) {
            return false;
        }
    }

    /**
     * Everything Android will tell us about where one package came from.
     *
     * Kept as plain strings and one int so the answer survives the trip to the
     * dashboard unchanged; the dashboard needs the evidence, not a verdict.
     */
    static final class Origin {
        String installer = "";
        String initiating = "";
        String originating = "";
        int source = -1;
        boolean store = false;

        /** One short phrase for the "Installed from" column. */
        String label(PackageManager pm) {
            if (store) return "Store";
            if (source == SOURCE_DOWNLOADED_FILE) return "Downloaded file";
            if (source == SOURCE_LOCAL_FILE) return "Local file";
            if (initiating.length() > 0) return "Opened by " + friendly(pm, initiating);
            if (installer.length() > 0) return "Installed by " + friendly(pm, installer);
            return "Unknown origin";
        }
    }

    // PackageManager.PackageSource values, repeated as plain ints so this file
    // does not need an API-33 guard on every use.
    static final int SOURCE_UNSPECIFIED = 0;
    static final int SOURCE_STORE = 1;
    static final int SOURCE_LOCAL_FILE = 2;
    static final int SOURCE_DOWNLOADED_FILE = 3;
    static final int SOURCE_OTHER = 4;

    /**
     * Read the whole install chain for one package.
     *
     * Order matters. The platform's own PackageSource is the authority when it
     * is there, because it is the only field that knows a Play Store app went
     * through the package installer. Without it, the initiating package is the
     * next best answer, and the installing package is the last resort.
     */
    static Origin originOf(PackageManager pm, String pkg) {
        Origin o = new Origin();
        try {
            if (Build.VERSION.SDK_INT >= 30) {
                InstallSourceInfo info = pm.getInstallSourceInfo(pkg);
                if (info != null) {
                    o.installer = nz(info.getInstallingPackageName());
                    o.initiating = nz(info.getInitiatingPackageName());
                    o.originating = nz(info.getOriginatingPackageName());
                    if (Build.VERSION.SDK_INT >= 33) {
                        o.source = info.getPackageSource();
                    }
                }
            }
            if (o.installer.length() == 0) {
                o.installer = nz(pm.getInstallerPackageName(pkg));
            }
        } catch (Throwable t) {
            // A package can vanish mid-scan; an empty origin is honest.
        }

        // 1. The platform says a store delivered it. Nothing else matters.
        if (o.source == SOURCE_STORE) {
            o.store = true;
            return o;
        }
        // 2. The platform says it came from a file on the device. That is a
        //    sideload even though the package installer did the install - but a
        //    store named anywhere in the chain still wins, because some stores
        //    deliver through a downloaded file.
        if (o.source == SOURCE_LOCAL_FILE || o.source == SOURCE_DOWNLOADED_FILE) {
            o.store = isStore(o.initiating) || isStore(o.originating)
                    || isStore(o.installer);
            return o;
        }
        // 3. No PackageSource (Android 12 and older, or an unspecified one):
        //    fall back to the packages named in the chain.
        o.store = isStore(o.installer) || isStore(o.initiating)
                || isStore(o.originating);
        return o;
    }

    private static String nz(String s) {
        return s == null ? "" : s;
    }

    /** A readable name for a package: its app label, or the package itself. */
    private static String friendly(PackageManager pm, String pkg) {
        if (pkg == null || pkg.length() == 0) return "";
        try {
            ApplicationInfo ai = pm.getApplicationInfo(pkg, 0);
            CharSequence l = pm.getApplicationLabel(ai);
            if (l != null && l.length() > 0) return l.toString();
        } catch (Throwable ignored) { }
        // A few that are not always visible as an app of their own.
        if ("com.android.shell".equals(pkg)) return "adb";
        if ("com.android.vending".equals(pkg)) return "Google Play";
        if ("com.google.android.packageinstaller".equals(pkg)
                || "com.android.packageinstaller".equals(pkg)) {
            return "Package installer";
        }
        return pkg;
    }

    /**
     * Did this package arrive from a real store?
     *
     * Package-private on purpose: App.packages() sends the phone's own list
     * of outside-store apps to the dashboard, and both lists have to answer
     * with the same rule or the card and the app table name different apps for
     * one handset. Checking only for "vending" here called a Galaxy Store or
     * GetApps install a sideload.
     */
    static boolean isStore(String installer) {
        if (installer == null) return false;
        String i = installer.toLowerCase();
        return i.equals("com.android.vending")
                || i.equals("org.fdroid.fdroid")
                || i.equals("com.amazon.venezia")
                || i.equals("com.huawei.appmarket")
                || i.equals("com.sec.android.app.samsungapps")
                || i.equals("com.xiaomi.mipicks")
                || i.equals("com.heytap.market")
                || i.equals("com.oppo.market")
                || i.equals("com.vivo.appstore")
                || i.equals("com.bbk.appstore")
                || i.equals("com.transsion.appstore")
                || i.equals("com.google.android.feedback")
                // No packageinstaller here on purpose: a manual .apk install is
                // the case this scan is looking for, not a store delivery.
                // Vendor preload updaters: a phone that came with Facebook
                // reports com.facebook.system, not Play. Treating that as
                // "outside a store" flagged a factory app as a sideload.
                || i.equals("com.facebook.system")
                || i.equals("com.facebook.appmanager")
                || i.equals("com.facebook.services");
    }

    /** SHA-256 of the APK file on disk: proof of exactly what was scanned. */
    private static String sha256File(File f) {
        InputStream in = null;
        try {
            if (f == null || !f.isFile() || f.length() <= 0 || f.length() > MAX_HASH_BYTES) {
                return "";
            }
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            in = new FileInputStream(f);
            byte[] buf = new byte[32768];
            int n;
            while ((n = in.read(buf)) > 0) md.update(buf, 0, n);
            return hex(md.digest());
        } catch (Throwable t) {
            // Another app's APK is sometimes unreadable; that is not an error
            // worth surfacing, it just means no hash is available.
            return "";
        } finally {
            if (in != null) { try { in.close(); } catch (Throwable ignored) { } }
        }
    }

    /** SHA-256 of the signing certificate, so repackaged clones stand out. */
    private static String signerOf(PackageManager pm, String pkg) {
        try {
            Signature[] sigs = null;
            if (Build.VERSION.SDK_INT >= 28) {
                PackageInfo pi = pm.getPackageInfo(pkg, PackageManager.GET_SIGNING_CERTIFICATES);
                SigningInfo si = pi == null ? null : pi.signingInfo;
                if (si != null) {
                    sigs = si.hasMultipleSigners()
                            ? si.getApkContentsSigners()
                            : si.getSigningCertificateHistory();
                }
            } else {
                PackageInfo pi = pm.getPackageInfo(pkg, PackageManager.GET_SIGNATURES);
                sigs = pi == null ? null : pi.signatures;
            }
            if (sigs == null || sigs.length == 0 || sigs[0] == null) return "";
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            return hex(md.digest(sigs[0].toByteArray()));
        } catch (Throwable t) {
            return "";
        }
    }

    // ------------------------------------------- capabilities switched on now

    /**
     * Accessibility services that are currently enabled. A package listed here
     * can read the screen and perform taps, which is how most Android banking
     * trojans take over an app.
     */
    private static Set<String> accessibilityPackages(Context c) {
        return settingPackages(c, "enabled_accessibility_services");
    }

    private static Set<String> notificationListenerPackages(Context c) {
        return settingPackages(c, "enabled_notification_listeners");
    }

    /** "com.foo/com.foo.Svc:com.bar/com.bar.Svc" -> {com.foo, com.bar} */
    private static Set<String> settingPackages(Context c, String key) {
        Set<String> out = new HashSet<String>();
        try {
            String raw = Settings.Secure.getString(c.getContentResolver(), key);
            if (raw == null || raw.length() == 0) return out;
            for (String part : raw.split(":")) {
                int slash = part.indexOf('/');
                String pkg = slash > 0 ? part.substring(0, slash) : part;
                pkg = pkg.trim();
                if (pkg.length() > 0) out.add(pkg);
            }
        } catch (Throwable t) {
            Log.w(TAG, "setting " + key + ": " + t);
        }
        return out;
    }

    private static Set<String> deviceAdminPackages(Context c) {
        Set<String> out = new HashSet<String>();
        try {
            DevicePolicyManager dpm =
                    (DevicePolicyManager) c.getSystemService(Context.DEVICE_POLICY_SERVICE);
            if (dpm == null) return out;
            List<ComponentName> admins = dpm.getActiveAdmins();
            if (admins == null) return out;
            for (ComponentName cn : admins) {
                if (cn != null && cn.getPackageName() != null) {
                    out.add(cn.getPackageName());
                }
            }
        } catch (Throwable t) {
            Log.w(TAG, "device admins: " + t);
        }
        return out;
    }

    static String hex(byte[] b) {
        if (b == null) return "";
        StringBuilder sb = new StringBuilder(b.length * 2);
        for (byte x : b) {
            int v = x & 0xFF;
            if (v < 16) sb.append('0');
            sb.append(Integer.toHexString(v));
        }
        return sb.toString();
    }
}
