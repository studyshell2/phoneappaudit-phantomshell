package com.appaudit.app;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.util.TypedValue;
import android.view.View;
import android.widget.TextView;

/**
 * The one place colours, type and spacing are decided.
 *
 * The palette is taken from the dashboard sign-in card so the phone and the
 * browser look like the same product: deep navy, a single blue accent, and
 * muted blue-grey for everything that is not the answer.
 */
final class Ui {

    static final int BG        = 0xFF040D18;
    static final int BG_MID    = 0xFF08182A;
    static final int BG_TOP    = 0xFF0F3050;
    static final int CARD      = 0xE60A1A2D;
    static final int CARD_EDGE = 0xFF16334F;
    static final int LINE      = 0xFF1C4266;
    static final int TEXT      = 0xFFD7E6F7;
    static final int STRONG    = 0xFFEAF3FF;
    static final int MUTED     = 0xFF8AA7C7;
    static final int FAINT     = 0xFF6B88A9;
    static final int ACCENT    = 0xFF4C9AFF;
    static final int ACCENT_D  = 0xFF2C6BB5;
    static final int OK        = 0xFF4ADE80;
    static final int WARN      = 0xFFFBBF24;
    static final int BAD       = 0xFFF87171;
    static final int FIELD      = 0xFF0A1C30;
    static final int FIELD_EDGE = 0xFF24547F;

    static final Typeface MONO   = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD);
    static final Typeface MONO_R = Typeface.create(Typeface.MONOSPACE, Typeface.NORMAL);
    static final Typeface SANS   = Typeface.create(Typeface.SANS_SERIF, Typeface.NORMAL);
    static final Typeface SANS_B = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD);

    private static Bitmap crest;

    private Ui() {}

    static int dp(Context c, float v) {
        return (int) (v * c.getResources().getDisplayMetrics().density + 0.5f);
    }

    static float fdp(Context c, float v) {
        return v * c.getResources().getDisplayMetrics().density;
    }

    /** A filled rounded box, optionally with a hairline edge. */
    static GradientDrawable round(int fill, float radiusPx, int stroke, float strokePx) {
        GradientDrawable d = new GradientDrawable();
        d.setShape(GradientDrawable.RECTANGLE);
        d.setColor(fill);
        d.setCornerRadius(radiusPx);
        if (strokePx > 0f) {
            d.setStroke(Math.max(1, (int) strokePx), stroke);
        }
        return d;
    }

    static void pad(View v, Context c, float l, float t, float r, float b) {
        v.setPadding(dp(c, l), dp(c, t), dp(c, r), dp(c, b));
    }

    /** Body text. */
    static TextView text(Context c, String s, float sp, int color, boolean mono,
                         boolean bold) {
        TextView t = new TextView(c);
        t.setText(s);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, sp);
        t.setTextColor(color);
        if (mono) {
            t.setTypeface(bold ? MONO : MONO_R);
        } else {
            t.setTypeface(bold ? SANS_B : SANS);
        }
        return t;
    }

    /** A heading in the dashboard's dot-matrix register: caps, wide tracking. */
    static TextView heading(Context c, String s, float sp, int color) {
        TextView t = text(c, s.toUpperCase(), sp, color, true, true);
        t.setLetterSpacing(0.16f);
        return t;
    }

    /** Small caps label used above a field or a group. */
    static TextView eyebrow(Context c, String s) {
        TextView t = text(c, s.toUpperCase(), 9f, FAINT, true, true);
        t.setLetterSpacing(0.22f);
        return t;
    }

    /**
     * The crest, decoded once.
     *
     * 340x370 is larger than any use in this app, and decoding it four times
     * (intro, header, and twice for measurements) is wasteful on a phone, so the
     * scaled copy is kept.
     */
    static Bitmap crest(Context c) {
        if (crest == null) {
            try {
                BitmapFactory.Options o = new BitmapFactory.Options();
                o.inScaled = false;
                Bitmap raw = BitmapFactory.decodeResource(c.getResources(),
                        R.drawable.logo, o);
                if (raw != null) {
                    int target = Ui.dp(c, 132);
                    if (raw.getWidth() > target) {
                        float ratio = target / (float) raw.getWidth();
                        crest = Bitmap.createScaledBitmap(raw,
                                target, Math.max(1, (int) (raw.getHeight() * ratio)),
                                true);
                    } else {
                        crest = raw;
                    }
                }
            } catch (Throwable t) {
                crest = null;
            }
        }
        return crest;
    }

    /** Same colour with a different alpha channel, for tints and edges. */
    static int alpha(int color, int a) {
        return (color & 0x00FFFFFF) | ((a & 0xFF) << 24);
    }

    /**
     * A tappable pill.
     *
     * Built as a TextView rather than a Button on purpose: the platform Button
     * carries its own background and padding, which cannot be fully replaced
     * without a theme, and its default look belongs to a different design. This
     * keeps the fill, the edge, the ripple and the type under our control.
     */
    static TextView pill(Context c, String label, float sp, int fill, int stroke,
                         int fg, float radiusDp, boolean mono) {
        TextView t = text(c, label, sp, fg, mono, true);
        float r = fdp(c, radiusDp);
        GradientDrawable bg = round(fill, r, stroke, Math.max(1f, fdp(c, 0.9f)));
        GradientDrawable mask = round(0xFFFFFFFF, r, 0, 0f);
        android.content.res.ColorStateList rip =
                android.content.res.ColorStateList.valueOf(0x33FFFFFF);
        t.setBackground(new android.graphics.drawable.RippleDrawable(rip, bg, mask));
        t.setGravity(android.view.Gravity.CENTER);
        t.setClickable(true);
        t.setFocusable(true);
        pad(t, c, 16f, 12f, 16f, 12f);
        return t;
    }

    /** A text field in the dashboard's palette. */
    static android.widget.EditText field(Context c, String hint) {
        android.widget.EditText e = new android.widget.EditText(c);
        e.setHint(hint);
        e.setHintTextColor(FAINT);
        e.setTextColor(TEXT);
        e.setTextSize(android.util.TypedValue.COMPLEX_UNIT_SP, 13f);
        e.setTypeface(MONO_R);
        e.setSingleLine(true);
        e.setBackground(round(FIELD, fdp(c, 11f), FIELD_EDGE, Math.max(1f, fdp(c, 0.9f))));
        pad(e, c, 13f, 11f, 13f, 11f);
        return e;
    }

    /** Colour for a score band. The thresholds live here, not in the views. */
    static int scoreColor(int score) {
        if (score < 0) return FAINT;
        if (score >= 85) return OK;
        if (score >= 60) return WARN;
        return BAD;
    }

    static int riskColor(String risk) {
        return "High".equalsIgnoreCase(risk) ? BAD : OK;
    }
}
