#!/usr/bin/env bash
# ---------------------------------------------------------------------------
# build_apk.sh - rebuild the AppAudit app APK from android/src
#
# You do NOT have to run this. The kit already ships a signed, ready-to-install
# APK at server/apks/appaudit.apk. Run this only if you want to change
# the Java code and rebuild.
#
# It needs the Android SDK command line tools (aapt2, zipalign, apksigner) plus
# a JDK. Set ANDROID_HOME if your SDK is not in one of the usual places.
#
#   ./build_apk.sh
# ---------------------------------------------------------------------------
set -euo pipefail

KIT="$(cd "$(dirname "$0")" && pwd)"
SRC="$KIT/android"
OUT="$SRC/build"
MIN_SDK=24
TARGET_SDK=34

# ---- find the Android SDK -------------------------------------------------
find_sdk() {
  local c
  for c in "${ANDROID_HOME:-}" "${ANDROID_SDK_ROOT:-}" \
           "$HOME/Android/Sdk" "$HOME/android-sdk" \
           /usr/lib/android-sdk /opt/android /opt/android-sdk; do
    [ -n "$c" ] && [ -d "$c" ] && { echo "$c"; return 0; }
  done
  return 1
}

SDK="$(find_sdk || true)"
if [ -z "$SDK" ]; then
  cat <<'EOF'
[!] Android SDK not found.

Install it once with:

    sudo apt update && sudo apt install -y default-jdk
    mkdir -p ~/android-sdk/cmdline-tools && cd ~/android-sdk/cmdline-tools
    curl -LO https://dl.google.com/android/repository/commandlinetools-linux-11076708_latest.zip
    unzip -q commandlinetools-linux-*.zip && mv cmdline-tools latest
    export ANDROID_HOME=~/android-sdk
    ~/android-sdk/cmdline-tools/latest/bin/sdkmanager --sdk_root=$ANDROID_HOME \
        "platforms;android-34" "build-tools;34.0.0"

Then re-run ./build_apk.sh

Or just skip this: the kit already contains a working APK.
EOF
  exit 1
fi

# pick the newest build-tools that has aapt2
BT="$(ls -d "$SDK"/build-tools/*/ 2>/dev/null | sort -V | tail -1 || true)"
if [ -z "$BT" ] || [ ! -x "${BT}aapt2" ]; then
  echo "[!] no build-tools with aapt2 under $SDK/build-tools"; exit 1
fi
BT="${BT%/}"

AJAR="$(ls "$SDK"/platforms/android-*/android.jar 2>/dev/null | sort -V | tail -1 || true)"
[ -n "$AJAR" ] || { echo "[!] no android.jar under $SDK/platforms"; exit 1; }

# R8/D8: the d8 bundled with some build-tools crashes on anonymous inner classes,
# so prefer a standalone r8.jar when one is present.
if [ -n "${R8JAR:-}" ] && [ -f "$R8JAR" ]; then
  DEXER=(java -cp "$R8JAR" com.android.tools.r8.D8)
elif [ -f /opt/android/r8.jar ]; then
  DEXER=(java -cp /opt/android/r8.jar com.android.tools.r8.D8)
elif [ -x "${BT}/d8" ]; then
  DEXER=("${BT}/d8")
else
  echo "[!] no dexer found (need d8 or r8.jar)"; exit 1
fi

for t in java javac keytool zip; do
  command -v "$t" >/dev/null || { echo "[!] missing tool: $t (apt install default-jdk zip)"; exit 1; }
done

echo "==> SDK      : $SDK"
echo "==> tools    : $BT"
echo "==> android  : $AJAR"

rm -rf "$OUT"
mkdir -p "$OUT/classes" "$OUT/dex"

echo "==> 1/6 resources (aapt2 compile)"
"$BT/aapt2" compile --dir "$SRC/res" -o "$OUT/res.zip"

echo "==> 2/6 link manifest (aapt2 link)"
# The version is NOT set here: aapt2 ignores --version-code when the manifest
# already declares one, and the manifest wins silently. AndroidManifest.xml is
# the single place to bump it, so an upgrade is always seen as an upgrade.
# --java writes R.java for the generated ids. The UI reads R.raw.bg and
# R.drawable.logo, so the ids have to exist as a compilable class, not just as
# entries inside the resource table.
mkdir -p "$OUT/gen"
"$BT/aapt2" link -o "$OUT/base.apk" -I "$AJAR" \
  --manifest "$SRC/AndroidManifest.xml" -R "$OUT/res.zip" \
  --java "$OUT/gen" \
  -0 mp4 \
  --min-sdk-version "$MIN_SDK" --target-sdk-version "$TARGET_SDK" \
  --auto-add-overlay

echo "==> 3/6 compile java"
find "$SRC/src" "$OUT/gen" -name '*.java' > "$OUT/sources.txt"
javac --release 8 -Xlint:-options -cp "$AJAR" -d "$OUT/classes" @"$OUT/sources.txt"

echo "==> 4/6 dex"
find "$OUT/classes" -name '*.class' > "$OUT/classes.txt"
"${DEXER[@]}" --release --min-api "$MIN_SDK" --lib "$AJAR" \
  --output "$OUT/dex" @"$OUT/classes.txt"

echo "==> 5/6 package"
cp "$OUT/base.apk" "$OUT/unsigned.apk"
( cd "$OUT/dex" && zip -q -X "$OUT/unsigned.apk" classes.dex )
"$BT/zipalign" -f -p 4 "$OUT/unsigned.apk" "$OUT/aligned.apk"

echo "==> 6/6 sign"
KS="$SRC/keystore/appaudit.jks"
if [ ! -f "$KS" ]; then
  mkdir -p "$(dirname "$KS")"
  keytool -genkeypair -v -keystore "$KS" -alias appaudit -keyalg RSA -keysize 2048 \
    -validity 10000 -storepass appaudit -keypass appaudit \
    -dname "CN=AppAudit App, OU=Lab, O=AppAudit, L=Lab, S=Lab, C=US" >/dev/null
fi
"$BT/apksigner" sign --ks "$KS" --ks-key-alias appaudit \
  --ks-pass pass:appaudit --key-pass pass:appaudit \
  --v1-signing-enabled true --v2-signing-enabled true \
  --out "$SRC/appaudit.apk" "$OUT/aligned.apk"

mkdir -p "$KIT/server/apks"
cp "$SRC/appaudit.apk" "$KIT/server/apks/appaudit.apk"

echo
echo "==> built: $SRC/appaudit.apk"
echo "==> staged for the server: $KIT/server/apks/appaudit.apk"
"$BT/apksigner" verify --print-certs "$SRC/appaudit.apk" | head -3
ls -l "$KIT/server/apks/appaudit.apk"
