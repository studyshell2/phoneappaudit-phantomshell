Fonts bundled with the AppAudit console
============================================

The console ships its fonts instead of loading them from a CDN, so the pages
still look right on a network with no internet access (a LAN-only bench, a
locked-down lab, or a phone on a captive portal).

  silkscreen-400.woff2   Silkscreen Regular    headings, labels, buttons
  silkscreen-700.woff2   Silkscreen Bold       counter values, risk words
  vt323-400.woff2        VT323 Regular         body copy, app data, terminal text

Both families are by Jason Kottke (Silkscreen) and Peter Hull (VT323), taken
from Google Fonts and licensed under the SIL Open Font License 1.1. The full
licence text is next to each file:

  OFL-silkscreen.txt
  OFL-vt323.txt

SIL OFL 1.1 allows bundling and redistribution with software, including
commercially, as long as the licence travels with the font and the fonts are not
sold on their own. Nothing here needs to be credited on screen, but the licence
files must stay in this folder.

Only the Latin subset is included; that is all these pages use. If you edit
these files, say so in OFL-*.txt as the licence requires (Reserved Font Name).
