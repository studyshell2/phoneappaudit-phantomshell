#!/usr/bin/env bash
# ---------------------------------------------------------------------------
# install.sh - one-time setup on a fresh Kali VM.
#
#   bash install.sh
#
# Run this ONCE, then use ./start.sh every time.
#
# It checks and fixes everything that is easy to get wrong on a new machine:
#   - python3 present
#   - cloudflared present (installs it if missing, so the random tunnel works)
#   - every file present, with the right checksum
#   - the app APK in the exact place the server serves it from
#   - the folders the scripts write into
#   - the server actually starts and answers before you rely on it
#
# It changes nothing outside this folder except installing cloudflared, and it
# asks before doing that.
# ---------------------------------------------------------------------------
set -uo pipefail

KIT="$(cd "$(dirname "$0")" && pwd)"
cd "$KIT" || exit 1

ok()   { printf '  [ok]   %s\n' "$*"; }
warn() { printf '  [warn] %s\n' "$*"; }
bad()  { printf '  [FAIL] %s\n' "$*"; }
step() { printf '\n== %s\n' "$*"; }

FAILED=0
note_fail() { FAILED=$((FAILED + 1)); bad "$*"; }

printf 'AppAudit setup\n'
printf 'kit folder: %s\n' "$KIT"
printf 'host:       %s\n' "$(uname -srm)"

# ---------------------------------------------------------------------------
step "1. python3"
# ---------------------------------------------------------------------------
if command -v python3 >/dev/null 2>&1; then
  ok "python3 $(python3 -V 2>&1 | awk '{print $2}')"
else
  warn "python3 is missing - installing"
  if command -v apt-get >/dev/null 2>&1; then
    sudo apt-get update -qq && sudo apt-get install -y python3 || true
  fi
  if command -v python3 >/dev/null 2>&1; then
    ok "python3 installed"
  else
    note_fail "python3 is not installed and could not be installed automatically"
    printf '         run: sudo apt install -y python3\n'
  fi
fi

# ---------------------------------------------------------------------------
step "2. curl (used for the health checks)"
# ---------------------------------------------------------------------------
if command -v curl >/dev/null 2>&1; then
  ok "curl present"
else
  warn "curl is missing - installing"
  sudo apt-get install -y curl >/dev/null 2>&1 || true
  command -v curl >/dev/null 2>&1 && ok "curl installed" \
    || note_fail "curl missing; the checks in start.sh will not work"
fi

# ---------------------------------------------------------------------------
step "3. cloudflared (this is what makes the random trycloudflare link)"
# ---------------------------------------------------------------------------
if command -v cloudflared >/dev/null 2>&1; then
  ok "cloudflared $(cloudflared --version 2>/dev/null | awk '{print $3}')"
else
  warn "cloudflared is not installed"
  printf '         Without it there is no random public link, and a phone on\n'
  printf '         mobile data could not reach this dashboard.\n'
  printf '\n'
  printf '         Install it now? [y/N] '
  read -r answer </dev/tty 2>/dev/null || answer="n"
  case "$answer" in
    y|Y|yes|YES)
      installed=0
      if command -v apt-get >/dev/null 2>&1 && \
         sudo apt-get install -y cloudflared >/dev/null 2>&1; then
        installed=1
      fi
      if [ "$installed" = "0" ]; then
        # Not in every Kali repo: take the .deb straight from Cloudflare.
        ARCH="$(dpkg --print-architecture 2>/dev/null || echo amd64)"
        URL="https://github.com/cloudflare/cloudflared/releases/latest/download/cloudflared-linux-${ARCH}.deb"
        TMP="$(mktemp -d)"
        if curl -fsSL "$URL" -o "$TMP/cloudflared.deb" 2>/dev/null && \
           sudo dpkg -i "$TMP/cloudflared.deb" >/dev/null 2>&1; then
          installed=1
        fi
        rm -rf "$TMP"
      fi
      if command -v cloudflared >/dev/null 2>&1; then
        ok "cloudflared installed"
      else
        warn "could not install it automatically - LAN-only mode will still work"
        printf '         manual: https://github.com/cloudflare/cloudflared/releases/latest\n'
      fi
      ;;
    *)
      warn "skipped - using LAN addresses only"
      ;;
  esac
fi

# ---------------------------------------------------------------------------
step "4. the kit files"
# ---------------------------------------------------------------------------
check_file() {
  # name  expected_sha256  (empty = just check it exists)
  local path="$1" want="$2" got
  if [ ! -f "$path" ]; then
    note_fail "missing: $path"
    return
  fi
  if [ -z "$want" ]; then
    ok "$path ($(stat -c%s "$path") bytes)"
    return
  fi
  got="$(sha256sum "$path" | awk '{print $1}')"
  if [ "$got" = "$want" ]; then
    ok "$path"
  else
    warn "$path checksum differs from this build"
    printf '         expected %s\n' "$want"
    printf '         found    %s\n' "$got"
    printf '         If you edited this file on purpose, ignore this.\n'
  fi
}

check_file "start.sh" "f75c83811f4f3a3143880feae124ed09621875bb1a8786895e88ba221d031043"
check_file "doctor.sh" "2abef1383408ca3704d7af39c32cbb9e9a2febbf4b5c58b8d3e18ca2a43894c2"
check_file "server/appaudit_server.py" "74a7f566629e74da19320e51615e08a176686b89214012da2269e955ecf9ed7f"
check_file "server/index.html" "ace35a2983e89770f737f8575681db21d8c12248ccd055addd7b85d7c9dcb763"
check_file "server/login.html" "b13c8550658f33217b0130d1c964233702f8b9bdc7b39d5ba5262aec119ad67c"
check_file "server/logo.jpg" "e05bf02b02e74973c9486a45785abcc0baf4b776dbf935ae4ffdadcb71de6d10"
check_file "server/app.html" "3fbe48ed3848192e41d0b902911257368c27614d02a3d03563f82fda4b5f9b25"
# Background loop for the sign-in card and the dashboard, plus its still frame.
# Both are optional to the server (missing files only mean no moving backdrop),
# but they are part of this build, so a corrupt copy is worth flagging here.
check_file "server/dashboard.mp4" "30dd1a02ea1516df54468d0d61e03ef2687aa9cbf2f26babf8a7a8bd1a974d63"
check_file "server/dashboard-poster.jpg" "840c6e0bc31d4ffa9338df1be2ceec32652760dfb8d9eff5e1a52733a46d4627"
# The console serves its own fonts instead of using a CDN, so these three files
# are what keep the pixel/terminal look on a machine with no internet access.
check_file "server/fonts/silkscreen-400.woff2" "e6c72ea4702249202bcdd79d3343057e4e25ef1f04e3fcffd8602ab53b40b4cc"
check_file "server/fonts/silkscreen-700.woff2" "5741b7f01a127f40ed70281fa2f686e8fc2cfe241930a120e4d1a1cebe78f995"
check_file "server/fonts/vt323-400.woff2" "8ddbebcc1048154132e1d78eb9b1f7850bca1b7d857035ccf1cb4318ebc615b6"
# Portraits for the team panel under the helper checker. Missing files only
# cost a picture, but a corrupt one is worth flagging like anything else.
check_file "server/team/shafiq.jpg" "347830b73cdf952e8cdbff1c298743e0470dd5563ed64438f01330b0f8c39754"
check_file "server/team/uwais.jpg" "0322964bcd324179bb60b7ba3f5f4e9fe2b5c1db67829f3b209f36b6637aedf2"
check_file "server/team/saza.jpg" "468b6c2a1bb2ec99b0e289462ab603808020d1f17f42915c6358dbb000e88c0c"
check_file "server/team/aiman.jpg" "ae82ba2fa91e6d83365973910ffa679e2155f11ff0abbf8f263b89e5c669e1eb"
check_file "server/team/haziq.jpg" "710a2ffafda04f886048cf885c06dfae73e8d719d67bd049904e1c34f746d959"

# The APK has to be here, with this exact name, or /appaudit.apk returns 404.
APK="server/apks/appaudit.apk"
check_file "$APK" "c76b6b5f14d1b7d8f6c456f2f3d0daa6fd554b08c3a3c287daa21d3fef13e9f1"
if [ ! -f "$APK" ]; then
  # Helpful recovery: maybe it is sitting in the kit root or ~/Downloads.
  for cand in appaudit.apk android/appaudit.apk "$HOME/Downloads/appaudit.apk"; do
    if [ -f "$cand" ]; then
      mkdir -p server/apks
      cp "$cand" "$APK"
      warn "copied $cand -> $APK"
      break
    fi
  done
fi

# ---------------------------------------------------------------------------
step "5. python syntax and folder permissions"
# ---------------------------------------------------------------------------
if python3 -m py_compile server/appaudit_server.py 2>/dev/null; then
  ok "server/appaudit_server.py compiles"
else
  note_fail "server/appaudit_server.py does not compile - re-copy it from the kit"
  python3 -m py_compile server/appaudit_server.py 2>&1 | tail -3 | sed 's/^/         /'
fi
rm -rf server/__pycache__

if bash -n start.sh 2>/dev/null; then
  ok "start.sh syntax is valid"
else
  note_fail "start.sh has a syntax error - re-copy it from the kit"
fi

mkdir -p helpers .run server/apks server/downloads
if [ -w helpers ] && [ -w .run ]; then
  ok "helpers/ and .run/ are writable"
else
  warn "helpers/ or .run/ not writable - fixing ownership"
  sudo chown -R "$(id -un):$(id -gn)" helpers .run server/apks 2>/dev/null || true
  [ -w helpers ] && ok "fixed" || note_fail "still not writable - check folder ownership"
fi

# Scripts must be executable, and writable by the person running them. A file
# left owned by root after an earlier "sudo nano" is what causes the
# "chmod: Operation not permitted" error later, so check writability directly.
OWNER_HINT=0
for f in start.sh install.sh doctor.sh; do
  [ -f "$f" ] || continue
  [ -x "$f" ] || { chmod +x "$f" 2>/dev/null || sudo chmod +x "$f" 2>/dev/null || true; }
  if [ -w "$f" ]; then
    [ -x "$f" ] && ok "$f is ready"
  else
    warn "$f is not writable by $(id -un)"
    hint="sudo chown $(id -un):$(id -gn) $f"
    printf '         fix: %s\n' "$hint"
    OWNER_HINT=1
  fi
done
[ "$OWNER_HINT" = "1" ] && printf '         (run that once; it is why chmod failed before)\n'

# ---------------------------------------------------------------------------
step "6. does the server actually start?"
# ---------------------------------------------------------------------------
PORT="${AA_PORT:-8085}"
if command -v ss >/dev/null 2>&1 && ss -ltn 2>/dev/null | grep -q ":$PORT "; then
  warn "port $PORT is already in use - skipping the start test"
  printf '         that is fine if AppAudit is already running:\n'
  ss -ltnp 2>/dev/null | grep ":$PORT " | sed 's/^/         /'
else
  setsid nohup python3 server/appaudit_server.py >.run/install-test.log 2>&1 \
      </dev/null &
  TEST_PID=$!
  sleep 3
  HEALTH="$(curl -fsS -m 5 "http://127.0.0.1:$PORT/health" 2>/dev/null || true)"
  APK_CODE="$(curl -s -m 8 -o /dev/null -w '%{http_code}' \
              "http://127.0.0.1:$PORT/appaudit.apk" 2>/dev/null || true)"
  LOGIN_CODE="$(curl -s -m 8 -o /dev/null -w '%{http_code}' \
              "http://127.0.0.1:$PORT/login" 2>/dev/null || true)"
  GATE_CODE="$(curl -s -m 8 -o /dev/null -w '%{http_code}' \
              "http://127.0.0.1:$PORT/dashboard" 2>/dev/null || true)"
  kill "$TEST_PID" 2>/dev/null || true
  wait "$TEST_PID" 2>/dev/null || true

  if [ "$HEALTH" = "alive" ]; then
    ok "server starts and /health answers"
  else
    note_fail "server did not answer /health"
    tail -6 .run/install-test.log | sed 's/^/         /'
  fi
  [ "$LOGIN_CODE" = "200" ] && ok "sign-in page serves (200)" \
    || note_fail "sign-in page returned $LOGIN_CODE"
  [ "$GATE_CODE" = "302" ] && ok "dashboard is gated behind the sign-in (302)" \
    || note_fail "dashboard should redirect to /login, got $GATE_CODE"
  if [ "$APK_CODE" = "200" ]; then
    ok "app APK serves (200)"
  else
    note_fail "app APK returned $APK_CODE (404 means the file is not in server/apks/)"
  fi
  rm -f .run/install-test.log
fi

# ---------------------------------------------------------------------------
step "7. DNS for the tunnel"
# ---------------------------------------------------------------------------
if getent hosts api.trycloudflare.com >/dev/null 2>&1; then
  ok "api.trycloudflare.com resolves - the tunnel will work"
else
  warn "cannot resolve api.trycloudflare.com - the random tunnel will NOT work"
  printf '         The phone would then only reach this dashboard on the same Wi-Fi.\n'
  printf '\n'
  printf '         Fix for this session:\n'
  printf '           echo '"'"'nameserver 1.1.1.1'"'"' | sudo tee /etc/resolv.conf\n'
  printf '         Fix that survives a reboot:\n'
  printf '           nmcli con show --active\n'
  printf '           sudo nmcli con mod "<name>" ipv4.dns "1.1.1.1 8.8.8.8"\n'
  printf '           sudo nmcli con mod "<name>" ipv4.ignore-auto-dns yes\n'
  printf '           sudo nmcli con up "<name>"\n'
fi

# ---------------------------------------------------------------------------
step "8. this machine's addresses"
# ---------------------------------------------------------------------------
for ip in $(hostname -I 2>/dev/null); do
  case "$ip" in
    127.*|169.254.*|::*) continue ;;
  esac
  case "$ip" in *:*) continue ;; esac
  printf '  LAN        http://%s:%s/login\n' "$ip" "$PORT"
done
PUB="$(curl -fsS -m 4 https://api.ipify.org 2>/dev/null || true)"
if [ -n "$PUB" ]; then
  printf '  public IP  http://%s:%s/login   (needs %s/tcp forwarded on the router)\n' \
    "$PUB" "$PORT" "$PORT"
else
  printf '  public IP  (could not look it up)\n'
fi

# ---------------------------------------------------------------------------
printf '\n'
if [ "$FAILED" -eq 0 ]; then
  cat <<'EOF'
================================================================================
  SETUP COMPLETE

  Next, every time you want to run it:

      cd ~/appaudit
      AA_REQUIRE_TUNNEL=1 bash ./start.sh

  Then open the console, press "Create account" and make your own login:

      username  your choice
      email     for password resets
      password  8 characters or more

  There is no built-in username or password - the server ships with no
  account, and the first one is made on that page. "Forgot your password?"
  emails a six-digit code, so set AA_SMTP_HOST / AA_SMTP_FROM / AA_SMTP_PASS
  before you rely on it; with no mailbox the page says plainly that no code
  can be sent.

  Data is filed per account: a phone belongs to the account that owns it, so a
  scan that finishes while the browser is closed is still written to
  state.json. Signing out does not throw it away; signing back in reads the
  same phones and the same log back.

  You want to see:
      tunnel verified: https://<random-words>.trycloudflare.com/health answered

  If something looks wrong later, run:

      bash ./doctor.sh

  It checks the running server, the APK, the helpers and the tunnel, and
  tells you which one is broken.
================================================================================
EOF
else
  printf '================================================================================\n'
  printf '  SETUP FINISHED WITH %d PROBLEM(S) - see [FAIL] lines above.\n' "$FAILED"
  printf '  Run: bash ./doctor.sh   for details on anything still broken.\n'
  printf '================================================================================\n'
  exit 1
fi
