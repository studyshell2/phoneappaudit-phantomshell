#!/usr/bin/env bash
# ---------------------------------------------------------------------------
# doctor.sh - find out exactly what is broken, without guessing.
#
#   bash doctor.sh
#
# Safe to run any time. It only reads state and makes a few local HTTP requests;
# it never modifies your files.
#
# The single most common confusion this clears up:
#
#   http=000 bytes=0     -> curl never reached the server. Nothing is listening
#                           on the port. The server is NOT running.
#   http=404             -> the server IS running, but that file/path is missing.
#
# They are completely different problems.
# ---------------------------------------------------------------------------
set -uo pipefail

KIT="$(cd "$(dirname "$0")" && pwd)"
cd "$KIT" || exit 1
PORT="${AA_PORT:-8085}"
BASE="http://127.0.0.1:$PORT"
PROBLEMS=0

ok()   { printf '  [ok]   %s\n' "$*"; }
warn() { printf '  [warn] %s\n' "$*"; }
bad()  { PROBLEMS=$((PROBLEMS + 1)); printf '  [FAIL] %s\n' "$*"; }
hint() { printf '         %s\n' "$*"; }
step() { printf '\n== %s\n' "$*"; }

printf 'AppAudit doctor\n'
printf 'kit folder: %s\n' "$KIT"

# ---------------------------------------------------------------------------
step "1. is the server running?"
# ---------------------------------------------------------------------------
LISTENING=0
if command -v ss >/dev/null 2>&1; then
  if ss -ltn 2>/dev/null | grep -q ":$PORT "; then
    LISTENING=1
    ok "something is listening on port $PORT"
    ss -ltnp 2>/dev/null | grep ":$PORT " | sed 's/^/         /'
  else
    bad "nothing is listening on port $PORT"
    hint "This is why curl shows http=000 bytes=0. The server is not running."
    hint "Start it:  AA_REQUIRE_TUNNEL=1 bash ./start.sh"
  fi
fi

SERVER_PID="$(pgrep -f 'appaudit_server\.py' | head -1 || true)"
if [ -n "$SERVER_PID" ]; then
  ok "server process is alive (pid $SERVER_PID)"
else
  [ "$LISTENING" = "0" ] && warn "no appaudit_server.py process found"
fi

# Stale pidfile from a crash or a hard kill.
if [ -f .run/server.pid ]; then
  OLD="$(cat .run/server.pid 2>/dev/null || true)"
  if [ -n "$OLD" ] && ! kill -0 "$OLD" 2>/dev/null; then
    warn "stale .run/server.pid (process $OLD is gone) - start.sh will clean it up"
  fi
fi

# ---------------------------------------------------------------------------
step "2. does it answer?"
# ---------------------------------------------------------------------------
if [ "$LISTENING" = "1" ]; then
  JAR="$(mktemp 2>/dev/null || echo /tmp/ps_doctor_cookies.txt)"

  show() {
    # label, path, optional cookie jar
    local label="$1" path="$2" jar="${3:-}" code size
    if [ -n "$jar" ]; then
      code="$(curl -s -m 8 -b "$jar" -o /dev/null -w '%{http_code}' "$BASE$path" 2>/dev/null || true)"
      size="$(curl -s -m 8 -b "$jar" -o /dev/null -w '%{size_download}' "$BASE$path" 2>/dev/null || true)"
    else
      code="$(curl -s -m 8 -o /dev/null -w '%{http_code}' "$BASE$path" 2>/dev/null || true)"
      size="$(curl -s -m 8 -o /dev/null -w '%{size_download}' "$BASE$path" 2>/dev/null || true)"
    fi
    case "$code" in
      200) ok "$label -> 200, $size bytes" ;;
      000) bad "$label -> 000 (connection failed, server died?)" ;;
      401) warn "$label -> 401 (this request was not signed in)" ;;
      302) warn "$label -> 302 (redirected - expect the sign-in page instead)" ;;
      404) if [ "$path" = "/appaudit.apk" ]; then
             bad "$label -> 404 (the APK is not in server/apks/ with the right name)"
           elif [ "$path" = "/helpers/helper_type_address.txt" ]; then
             warn "$label -> 404 (run ./start.sh once to write the helper files)"
           else
             bad "$label -> 404"
           fi ;;
      *)   warn "$label -> $code" ;;
    esac
  }
  printf '  health      -> %s\n' "$(curl -s -m 5 "$BASE/health" 2>/dev/null || echo 'no answer')"
  show "sign-in page" "/login"
  show "crest image " "/logo.jpg"

  # There is one way in now, so a retired Google route must be gone: 404 is the
  # healthy answer, and anything else means an old server is still running.
  STALE_CODE="$(curl -s -m 8 -o /dev/null -w '%{http_code}' \
      "$BASE/auth/google" 2>/dev/null || true)"
  case "$STALE_CODE" in
    404) ok "retired google route -> 404 (as expected)" ;;
    200|302) warn "retired google route -> $STALE_CODE (old server still running?)" ;;
    *)   warn "retired google route -> $STALE_CODE" ;;
  esac

  # The gated pages can only be probed with a real account, and the server no
  # longer ships one. Pass your own and this section goes further; without it
  # the public pages still get checked, which is the part that catches a
  # broken install.
  if [ -n "${AA_ADMIN_USER:-}" ] && [ -n "${AA_ADMIN_PASS:-}" ]; then
    THE_USER="$AA_ADMIN_USER"
    THE_PASS="$AA_ADMIN_PASS"
    LOGIN_CODE="$(curl -s -m 8 -c "$JAR" -o /dev/null -w '%{http_code}' \
        -H 'Content-Type: application/json' \
        --data "{\"username\":\"$THE_USER\",\"password\":\"$THE_PASS\"}" \
        "$BASE/api/login" 2>/dev/null || true)"
    if [ "$LOGIN_CODE" = "200" ]; then
      ok "console login -> 200 (signed in as $THE_USER)"
    else
      warn "console login -> $LOGIN_CODE (that account did not sign in)"
      printf '         check the password, or that the account still exists\n'
    fi
  else
    warn "console login -> skipped (no account given)"
    printf '         run it with your own to check the gated pages:\n'
    printf '           AA_ADMIN_USER=you AA_ADMIN_PASS=... bash ./doctor.sh\n'
  fi

  show "dashboard  " "/dashboard" "$JAR"
  show "state JSON " "/api/state" "$JAR"
  show "app page " "/app?tag=phone"
  show "app APK  " "/appaudit.apk"
  show "helper txt" "/helpers/helper_type_address.txt" "$JAR"
  show "helper zip" "/helpers.zip" "$JAR"
  show "downloads  " "/downloads" "$JAR"
  show "PDF log    " "/api/log.pdf" "$JAR"

  # The moving backdrop is optional to the server, so it needs its own check. A
  # browser needs Accept-Ranges and a 206 reply to play it: a plain 200 here
  # means seeking and looping are broken, not that the file is missing.
  VCODE="$(curl -s -m 8 -r 0-1023 -o /dev/null -w '%{http_code}' \
           "$BASE/dashboard.mp4" 2>/dev/null || true)"
  VSIZE="$(curl -s -m 8 -r 0-1023 -o /dev/null -w '%{size_download}' \
           "$BASE/dashboard.mp4" 2>/dev/null || true)"
  case "$VCODE" in
    206) ok "backdrop video -> 206, $VSIZE bytes (byte ranges ok)" ;;
    000) bad "backdrop video -> 000 (connection failed)" ;;
    200) warn "backdrop video -> 200 (no range support - seek and loop may fail)" ;;
    404) bad "backdrop video -> 404 (server/dashboard.mp4 is missing)" ;;
    *)   warn "backdrop video -> $VCODE" ;;
  esac
  show "backdrop art" "/dashboard-poster.jpg"
  rm -f "$JAR" 2>/dev/null || true
else
  warn "skipping HTTP checks - nothing is listening"
fi

# ---------------------------------------------------------------------------
step "3. the app APK"
# ---------------------------------------------------------------------------
APK="server/apks/appaudit.apk"
WANT="c76b6b5f14d1b7d8f6c456f2f3d0daa6fd554b08c3a3c287daa21d3fef13e9f1"
if [ -f "$APK" ]; then
  SIZE="$(stat -c%s "$APK")"
  GOT="$(sha256sum "$APK" | awk '{print $1}')"
  ok "$APK exists ($SIZE bytes)"
  if [ "$GOT" = "$WANT" ]; then
    ok "checksum matches the tested build"
  else
    warn "checksum differs from the tested build"
    hint "expected $WANT"
    hint "found    $GOT"
  fi
else
  bad "$APK is missing - /appaudit.apk will return 404"
  hint "Put the file there with this exact name:"
  hint "  cp ~/Downloads/appaudit.apk $APK"
  for cand in appaudit.apk android/appaudit.apk "$HOME/Downloads/appaudit.apk"; do
    [ -f "$cand" ] && hint "found a candidate: $cand"
  done
fi

# ---------------------------------------------------------------------------
step "4. helper files"
# ---------------------------------------------------------------------------
if [ -f helpers/helper_type_address.txt ]; then
  ok "helper files exist in helpers/"
  for pf in helper_type_address.txt helper_open_page.txt; do
    [ -f "helpers/$pf" ] || warn "helpers/$pf is missing (re-run ./start.sh)"
  done
  # Leftovers from an older kit: neither name is written or offered any more.
  for old in server_address.txt connect.txt; do
    [ -f "helpers/$old" ] && warn "helpers/$old is left over from an older kit - delete it"
  done
  ADDR="$(cat .run/address 2>/dev/null || cat helpers/server_address.txt 2>/dev/null || true)"
  if [ -n "$ADDR" ]; then
    ok "helpers were baked with: $ADDR"
    case "$ADDR" in
      *api.trycloudflare.com*)
        bad "that is Cloudflare's API host, not a tunnel - the helpers are unusable"
        hint "re-run ./start.sh once DNS works; the current start.sh rejects this address"
        ;;
      *127.0.0.1*|*localhost*)
        warn "helpers point at localhost - only this machine can use them"
        hint "fix DNS so the tunnel works, or use the LAN address instead"
        ;;
      *.trycloudflare.com*)
        # Retry a few times, plain then forced IPv4. Tunnel names are served by
        # Cloudflare and can resolve to IPv6 only, so a machine with a flaky
        # IPv6 route gets instant failures even though the tunnel is healthy.
        TUNNEL_ALIVE=0
        for _attempt in 1 2 3; do
          if curl -fsS -m 8 "$ADDR/health" 2>/dev/null | grep -q alive \
             || curl -4 -fsS -m 8 "$ADDR/health" 2>/dev/null | grep -q alive; then
            TUNNEL_ALIVE=1
            break
          fi
          sleep 1
        done
        TUNNEL_HOST="${ADDR#https://}"
        TUNNEL_HOST="${TUNNEL_HOST%%/*}"
        if [ "$TUNNEL_ALIVE" = "1" ]; then
          ok "that tunnel is still alive right now"
        elif getent hosts "$TUNNEL_HOST" >/dev/null 2>&1; then
          # The name resolves, so the failure is real: the tunnel is gone.
          warn "the tunnel did not answer - it is dead"
          hint "the address changes every run, and dies when you stop start.sh"
          hint "re-run ./start.sh and re-copy the helper to your text helper"
        else
          # Cannot resolve it: that is a fault on this machine, not proof.
          warn "could not check the tunnel: this machine cannot resolve"
          hint "  $TUNNEL_HOST"
          hint "that is a DNS problem here, not proof the tunnel is down"
          hint "check with: getent hosts $TUNNEL_HOST"
        fi
        ;;
    esac
  fi
else
  warn "no helper files yet - they are created by ./start.sh"
fi

# ---------------------------------------------------------------------------
step "5. the tunnel prerequisites"
# ---------------------------------------------------------------------------
if command -v cloudflared >/dev/null 2>&1; then
  ok "cloudflared installed ($(cloudflared --version 2>/dev/null | awk '{print $3}'))"
else
  warn "cloudflared not installed - LAN only, no random public link"
  hint "sudo apt install -y cloudflared"
fi

if getent hosts api.trycloudflare.com >/dev/null 2>&1; then
  ok "api.trycloudflare.com resolves (DNS ok)"
else
  bad "cannot resolve api.trycloudflare.com - the tunnel cannot be created"
  hint "echo 'nameserver 1.1.1.1' | sudo tee /etc/resolv.conf"
  hint "permanent: nmcli con mod \"<name>\" ipv4.dns \"1.1.1.1 8.8.8.8\" ipv4.ignore-auto-dns yes"
fi

if [ -f .run/tunnel.log ]; then
  if grep -q 'Registered tunnel connection' .run/tunnel.log 2>/dev/null; then
    ok "tunnel log shows a registered connection"
  else
    warn "tunnel log has no successful connection"
    grep -iE 'failed|error' .run/tunnel.log 2>/dev/null | tail -2 | sed 's/^/         /'
  fi
fi

# ---------------------------------------------------------------------------
step "6. addresses"
# ---------------------------------------------------------------------------
for ip in $(hostname -I 2>/dev/null); do
  case "$ip" in
    127.*|169.254.*|::*) continue ;;
  esac
  case "$ip" in *:*) continue ;; esac
  printf '  LAN        http://%s:%s/login\n' "$ip" "$PORT"
done
printf '  local      %s/login\n' "$BASE"

# ---------------------------------------------------------------------------
printf '\n'
if [ "$PROBLEMS" -eq 0 ]; then
  printf '================================================================================\n'
  printf '  ALL CHECKS PASSED\n'
  printf '================================================================================\n'
else
  printf '================================================================================\n'
  printf '  %d PROBLEM(S) FOUND - see the [FAIL] lines and the hints under them.\n' "$PROBLEMS"
  printf '================================================================================\n'
  exit 1
fi
