# Release history

This is the engineering log kept with the kit: what changed in every version
and why. For how to install and use PhantomShell, see the [README](../README.md).

# PhantomShell

A phone-safety dashboard for Android, driven from a Kali box.

The phone installs a small agent. It looks at every app installed on the phone,
keeps the ones that did **not** come from an app store, opens the app file where
Android lets it, and answers one question per app: **safe or high**. Those
answers reach a dashboard you open in a browser, worst first.

It does not filter or inspect network traffic at all; that feature was removed
in 1.4.

It does **not** read page contents, passwords, messages or files. See
"Limits" at the bottom — that ceiling is real and matters.

---

## Fresh Kali VM: two commands

```bash
cd ~/phantomshell
bash install.sh                        # once per machine
PS_REQUIRE_TUNNEL=1 bash ./start.sh    # every time you want to run it
```

`install.sh` checks python3 and curl, installs `cloudflared` if it is missing,
verifies every file's checksum, confirms the APK is where the server serves it
from, then actually starts the server and proves it answers before telling you
it is ready.

`start.sh` starts the dashboard, opens a **new random**
`https://<words>.trycloudflare.com` tunnel, verifies the tunnel answers
`/health`, then writes the payload files with that address baked in.

Success looks like this:

```
[1/4] starting dashboard server on port 8085 ...
      server is up -> http://127.0.0.1:8085/login (pid 12043)
[2/4] requesting a random Cloudflare tunnel (quic) ...
      waiting for the address.....
      tunnel verified: https://example-words-here.trycloudflare.com/health answered
[3/4] writing payload files ...
[4/4] READY
```

---

## If anything looks wrong

```bash
bash doctor.sh
```

It answers the questions you would otherwise guess at, and it distinguishes the
two failures that look identical in a browser:

| What you see | What it means |
|---|---|
| `http=000 bytes=0` | **Nothing is listening.** The server is not running. Run `start.sh`. |
| `http=404` | The server **is** running, but that file or path is missing. |

`doctor.sh` exits `0` when everything is healthy and `1` when something is
broken, so you can trust it in a script.

---

## What is in the kit

| Path | What it is |
|---|---|
| `install.sh` | one-time setup for a fresh machine |
| `start.sh` | starts the server + tunnel, writes the payloads |
| `doctor.sh` | diagnoses a broken setup |
| `server/phantomshell_server.py` | the whole server: dashboard, API, PDF log |
| `server/index.html` | the dashboard page (live, no polling) |
| `server/login.html` | the sign-in card you see first |
| `server/logo.jpg` | the crest on the sign-in card, the dashboard and page one of the PDF |
| `server/team/*.jpg` | the five portraits in the team panel |
| `server/agent.html` | the install page the phone opens |
| `server/phantomshell.mp4` | the moving backdrop on both console pages (1280x720, 685 KB, no audio) |
| `server/phantomshell-poster.jpg` | still frame used before the video loads and when reduced motion is on |
| `server/apks/phantomshell-agent.apk` | the Android agent, 86,485 bytes (v1.6) |
| `server/downloads/` | optional folder for qFlipper / RustDesk installers you supply |
| `payloads/` | created by `start.sh` — the two phone payloads |
| `android/` | agent source, manifest, keystore, build script |

`payloads/` and `.run/` do not exist until you run `start.sh`. That is normal.

---

## Getting the payload onto the phone

`start.sh` writes two files into `payloads/`, both pointing at the same address.
The dashboard's **Files for the phone** panel lists those two plus the APK, and
nothing else is written to that folder.

| File | Use it when |
|---|---|
| `payload_tunnel_apk.txt` | phone already has the app — types this run's dashboard address into the app's **Dashboard address** field |
| `payload_android_ducky.txt` | BadUSB plugged into an **unlocked phone** via OTG — types the install page into the browser |

For QFlipper / Kiisu v4b: load the `.txt` into the BadUSB payload slot, set the
keyboard layout to US, plug in, trigger. The DuckyScript is plain
`DELAY` / `STRING` / `ENTER`, which Kiisu accepts unchanged.

Then on the phone: open the install page → download the APK → allow
"install unknown apps" for that browser → install → open **PhantomShell** →
**Start protection** → allow notifications (optional) → allow background
running.

**This build has no web guard at all.** There is no `VpnService`, no DNS
interception and no packet handling anywhere in the agent, so it cannot cut the
phone's internet or make browsing look broken. Wi-Fi and mobile data are
untouched: the agent only reads the list of installed apps and reports it, and
it asks for the notification permission only so it can post scan alerts. The
Android VPN consent dialog never appears, because nothing requests a tunnel.

---

## Opening the dashboard

`start.sh` prints all the addresses it found, and keeps this run's baked address
in `.run/address`. The dashboard's own **Connect to this dashboard** panel shows
the same list, clickable.

| Viewer | Address | Needs |
|---|---|---|
| the Kali box itself | `http://127.0.0.1:8085/login` | nothing |
| your host / another PC, same Wi-Fi | `http://<LAN-IP>:8085/login` | nothing |
| phone on mobile data or another network | the `trycloudflare.com` link + `/login` | a working tunnel |
| phone, other network, no tunnel | `http://<public-IP>:8085/login` | router forwards `8085/tcp` |

`127.0.0.1` is loopback — it means "this same machine". Your host's
`127.0.0.1` will never reach a VM. Use the LAN address, or add a hypervisor
port-forward (VirtualBox: Network → Advanced → Port Forwarding, host `8085` →
guest `<LAN-IP>:8085`).

### Signing in, accounts and password reset

Every console page is behind one sign-in screen. **The server ships with no
account at all** — no built-in username, no default password, and nothing printed
on the card. The first thing to do on a fresh copy is press *Create account* and
make one:

| Field | Rules |
|---|---|
| username | 3-24 characters: letters, numbers, `.` `_` `-` |
| email | used only for a password reset |
| password | 8 characters or more, typed twice |

**Everyone makes their own account.** The same *Create account* tab makes one for
each person, and signs them in as soon as it is made. Usernames and addresses are unique and
matched without regard to case. The address is never shown to anybody else; it
exists so a forgotten password can be reset. Accounts are separate workspaces:
each one sees only its own phones and its own log, even when everybody is on the
same network and the same server. See *One account, one set of phones* below.

**Forgot password.** *Forgot your password?* asks for the username or the email
address, mails a six-digit code, then takes that code plus a new password on the
same pane. A code works once and expires after 10 minutes; five wrong tries
cancel it. To give the server a mailbox:

```bash
PS_SMTP_HOST=smtp.gmail.com PS_SMTP_PORT=465 PS_SMTP_TLS=ssl \
PS_SMTP_USER=you@gmail.com PS_SMTP_PASS='app-password' \
PS_SMTP_FROM=you@gmail.com bash ./start.sh
```

`PS_SMTP_TLS` takes `ssl` (port 465, the default), `starttls` (587) or `none`.
With no mailbox configured the page says plainly that no code can be sent
instead of pretending one is on its way. On a bench with no mail at all,
`PS_OTP_CONSOLE=1` prints each code in the terminal instead — useful for
testing, not for anything real.

**Delete my account.** The bar under the header shows who is signed in, and
*Delete my account* there asks for the password again before removing the
account for good: no undo, no recovery, and any session it had is closed. The
phones and log rows saved under that account are deleted with it, so nothing is
left behind on `server/state.json`; other accounts keep their own.

### One account, one set of phones

Two people can use one server on one network and never see each other's
handsets. Each account has:

- **its own phones** — a phone keeps reporting to the address it was given, and
  the first dashboard it reaches keeps it. Its fingerprint, apps, sites,
  counters, charts and PDF pages belong to that one account. Another account's
  dashboard does not list the phone, its log rows or its numbers;
- **its own log** — every row is filed under the account that owns the phone;
- **its own erase** — *Erase my data* clears the signed-in account's phones and
  log only, and deleting the account removes its data with it.

A phone that points at the bare address (`http://<server>/agent`, what the two
payload files type) belongs to the account that used the dashboard last: sign
in, let the phone scan, and the finished scan lands on that dashboard. The
choice is saved in `server/state.json`, so a scan that arrives while the console
is closed — or after the server is restarted — still lands on the same account.
A phone that already has an owner keeps it: the next person to sign in on the
same network does not inherit it, and its rows cannot be moved to another
account.

An account also has a private address, `http://<server>/u/<address>`. The address
is random, not the username, and a phone pointed at it is pinned to that one
account no matter who signed in last. The install page at
`.../u/<address>/agent` hands the app that address already filled in, or you can
type it into the app's server field with the `/u/<address>` part kept on the end.
Keep it to yourself: anyone who has it can send phones to your dashboard.

Set `PS_SIGNUP_CODE=...` when the sign-in page is reachable by people who should
not be able to create accounts; *Create account* then also asks for that invite
code. The server keeps at most 50 accounts and allows five sign-ups per address
per quarter hour.

Sessions last 12 hours in an `HttpOnly` cookie, **Sign out** in the header drops
it, and 8 wrong passwords from one address pauses that address for 5 minutes.

The phone and the install page never need to sign in — `/agent`, `/agent.apk`,
`/api/agent/*` and `/health` stay open so a phone can enrol.

---

## Dashboard features

- **Live updates.** One Server-Sent Events connection; the page updates the
  instant a phone reports. No refresh, no polling.
- **Remove this phone.** Forgets one of your phones and its log rows; another
  account's phone is not yours to remove. The agent keeps running and returns if
  it reports again.
- **Erase my data.** Wipes the signed-in account's phones, its log rows and its
  totals, and rewrites `server/state.json` without them, so a restart does not
  bring them back. Other accounts on the same server keep their own phones and
  log.
- **Download PDF report.** A real A4 PDF, built without any pip packages. Page
  one opens with a dark masthead carrying the **PhantomShell logo** top-left
  (embedded as a JPEG, copied into the file untouched), the report title, and the
  date and account. Under it: one approval line, four numbers — phones, reports,
  high-risk apps, apps outside a store — and one sentence saying what they mean.
  Below that, one compact block per phone (model, Android build, security patch,
  last seen, last scan, which apps may install unknown apps, any warning) and one
  table of every app from outside a store: risk, app, package, **where it came
  from in plain words** ("Downloaded file", "Opened by Chrome", "adb install
  (computer)", "Local file") and which phone it is on, worst first. Each row
  carries its own **Remediation** line, wrapped under the app it belongs to —
  the same advice the dashboard shows in its Remediation column. A **Remediation**
  section follows the table and always prints: what to remove when something is
  High, or plainly that nothing needs action when nothing is. Page two is
  **At a glance**: one bar chart of the outside-store apps by risk, with two bars
  (High and Safe) and a number on each, so the picture still reads when printed in
  black and white. The activity log starts on page three,
  newest first, capped at 60 entries, with its column head repeated on every
  page. Every page carries a running head and "page N of M"; the writer does its
  own vector drawing (filled rectangles for bars and row shading, stroked lines
  for rules and axes), so nothing extra has to be installed. Page one carries the
  approval line — **"Approved by Uwais Azzaidani Bin Mohd Norazhar - Leader,
  PhantomShell Project"** — and there is no signature block: a name here states
  who approved the report, it does not sign it. The same name is written into the
  PDF's document properties as the author, so it travels with an emailed copy. To
  change who approves, edit `APPROVER_NAME` / `APPROVER_TITLE` near the top of the
  PDF section in `server/phantomshell_server.py`.
- **Apps from outside a store.** The only apps listed are the ones that did not
  arrive from Play, Galaxy Store, GetApps, AppGallery or a vendor preload
  updater — the software a store never signed. Worst first, with risk, score,
  package, version, where it came from, the permissions and flags that mattered,
  why it was flagged and what the owner should do. Filter box for long lists.
- **Risk / Apps.** How many outside-store apps the phones have, and how many of
  them are High.
- **Payloads and agent.** The APK and every payload `.txt` are downloadable from
  the dashboard, plus a zip of all of them.
- **About phantomshell.** One plain paragraph at the very top of the page: what
  the app sends, what this page shows, and where the data is kept. No tables.
- **Payload safety.** Paste a BadUSB `.txt` or load one from disk, press *Check
  payload*, and read the verdict: a 0-100 risk score, whether the file targets a
  PC or a phone, every matched line with why it matters and what to do about it,
  then general guidance. The server only reads the text; it never runs the file.
- **Supervisor & group members.** The project team, under the checker: circular
  portraits, names, student IDs, with the group leader marked. The five portraits
  are `server/team/*.jpg`, served from disk, and the names are plain markup in
  `server/index.html`, so both are easy to change.

### How an app is rated

The phone does the measuring; the dashboard only repeats what it decided.

1. **Only apps from outside a store are listed.** A row is created only when the
   installer is not a known store and the app is not a system app. Play, Galaxy
   Store, GetApps, AppGallery and the vendor preload updaters sign and vet what
   they ship, and the owner cannot act on those rows anyway. The package
   installer itself (`com.android.packageinstaller`) is **not** a store: it is
   the route a downloaded `.apk` takes when somebody taps it in Files or a
   browser, which is the case this table exists to show. An `adb install`
   reports `com.android.shell` and is treated the same way.
2. **Two levels.** `High` means the app asked for something that can watch or
   control the phone: a switched-on accessibility service (+4), device-admin
   rights (+4), notification access (+3), reading SMS with internet access (+4),
   a debuggable build (+4), or a brand name it does not own (+4). Declaring an
   install-package, overlay or notification-listener service adds +2 each, and a
   build older than Android 6 adds +1. `Safe` means none of that reached 3 points.
3. **The score is shown, the level is the answer.** Contacts, camera, microphone
   and `CALL_PHONE` are deliberately not scored: every chat, banking and shopping
   app asks for them, and a rule that fires on normal software trains the user to
   ignore warnings.

The +5 that used to be added just for "sideloaded" is gone. Every listed app now
arrives from outside a store by definition, so that point made every row High and
left the Safe level unreachable.

### Payload safety checker

The checker is a set of weighted patterns (`PAYLOAD_RULES`) matched over the
text, so it is a second opinion, not a sandbox: a payload made only of ordinary
`STRING` lines can still do something unusual and score low.

| Verdict | Score | Meaning |
|---|---|---|
| Safe | under 15 | typing and waiting only |
| Caution | 15-39 | legitimate but risky, or a phone-side action such as `adb` |
| Dangerous | 40 and over | downloader, encoded command, persistence, credentials, data access |

Each match carries a severity and its own points (`critical` 30-40, `high`
16-26, `medium` 10-14, `low` 6-8); points are summed and capped at 100. An
encoded PowerShell downloader or a `schtasks` persistence line therefore lands
at 100, while `adb install` of the agent sits at Caution.

### Risk grading

Hostname-only, weighted, because a single weak signal on its own is normal
traffic (`bankofamerica.com` contains "bank", `secure` is everywhere):

| Points | Signal |
|---|---|
| 2 | abused TLD (`.top .xyz .tk .icu .click` …) |
| 2 | a brand name on a domain that is not that brand's |
| 2 | punycode lookalike (`xn--`) |
| 2 | bare IP instead of a name |
| 1 | account/payment wording in the name |
| 1 | 5+ dot sub-domain chain |

**3+ → Critical (blocked) · 2 → High (allowed, warned) · else Safe.**

Critical hostnames are answered `0.0.0.0`, so the connection dies and the phone
shows a notification. Real infrastructure is allowlisted so `googleapis.com`,
`login.microsoftonline.com` and `apple-dns.net` stay Safe.

---

## Endpoints

| Route | Purpose |
|---|---|
| `GET /health` | `alive` |
| `GET /` | redirects to `/dashboard` |
| `GET /login` | sign-in card (public) |
| `GET /logo.jpg` | the crest (public) |
| `GET /phantomshell.mp4` | the backdrop loop (public, answers byte ranges with 206) |
| `GET /phantomshell-poster.jpg` | the backdrop still frame (public) |
| `GET /fonts/<name>.woff2` | the two bundled fonts, allowlisted (public) |
| `GET /team/<name>.jpg` | a team portrait, allowlisted (public) |
| `GET /dashboard` | the dashboard, **sign-in required** (only that account's phones) |
| `GET /logout` | drops the session, back to `/login` |
| `POST /api/login` | username (or email) + password, sets the session cookie |
| `POST /api/logout` | clears the session |
| `POST /api/register` | create an account (username, email, password) and sign in |
| `POST /api/forgot` | email a six-digit reset code |
| `POST /api/reset-password` | reset code + new password |
| `POST /api/account/delete` | permanently delete the signed-in account (password required) |
| `GET /agent?tag=X` | install page for the phone |
| `GET /agent.apk` | the APK |
| `GET /downloads` | the installers found in `server/downloads/` (JSON, sign-in required) |
| `GET /download/<key>` | one of those installers, as a file (sign-in required) |
| `GET /install.ps1` | one-shot Windows installer used by the adb payload |
| `POST /api/agent/grade` | phone asks about one hostname |
| `POST /api/agent/report` | phone sends its apps, the deep-scan result and sites |
| `GET /api/state` | dashboard snapshot |
| `GET /api/stream` | live push (SSE) |
| `GET /api/log.pdf` | PDF report |
| `GET /api/net` | every address this dashboard is reachable on |
| `GET /payload/<file>` | a payload file (allowlisted) |
| `GET /payloads.zip` | all payload files |
| `POST /api/payload/check` | grade a BadUSB payload (alias `/api/payload/scan`) |
| `POST /api/device/delete` | forget one of your phones |
| `POST /api/device/claim` | add a waiting phone to your account by device id |
| `POST /api/reset` | erase the signed-in account's phones and log |
| `GET /u/<address>/agent` | a private install page that points the phone at one account |
| `GET /u/<address>/agent.apk`, `/u/<address>/install.ps1` | the same files behind that address |
| `POST /u/<address>/api/agent/report`, `/u/<address>/api/agent/grade` | the phone's report, filed under one account |

Environment: `PS_PORT` (8085), `PS_BIND` (0.0.0.0), `PS_TUNNEL` (1),
`PS_REQUIRE_TUNNEL` (0), `PS_SIGNUP_CODE` (none), `PS_SMTP_HOST` (none),
`PS_SMTP_PORT` (465), `PS_SMTP_TLS` (ssl), `PS_SMTP_USER`, `PS_SMTP_PASS`,
`PS_SMTP_FROM`, `PS_OTP_CONSOLE` (0). Password reset needs `PS_SMTP_HOST`,
`PS_SMTP_FROM` and `PS_SMTP_PASS`; without them there is no mailbox, and the
reset pane says so. `PS_PASSWORD` is accepted as an extra password-only gate on
the JSON API if you already script against it; leave it unset normally.

---

## Limits — read this once

**It opens APK files, but never runs them.** For every installed app the agent
tries to read the APK as a zip: entry names, `classes*.dex` strings, native
library names and manifest flags. It does not execute app code, does not load a
class, does not detonate anything in a sandbox, and has no reputation or
threat-intelligence feed. So "Secure" means "nothing suspicious in the file as
far as these static rules can see", not "proven clean".

**No traffic is inspected in this version.** 1.4 removed the DNS filter, so the
agent has no visibility into what the phone browses. The dashboard's site log
and "Sites seen" counter only fill up if you still have an older agent
installed on a handset; a 1.5 or 1.6 phone reports its apps, the scan result and
its own device details only.

**What the deep scan can and cannot see.**

- It reads up to 6 MB of each `classes*.dex`, and stops reading after 120 MB per
  scan. Apps past that budget are reported as **Unverified**, never as Secure.
- A packed, encrypted or split-payload app usually lands in **Review** or
  **Unverified**: the file may hold no readable dex at all.
- Apps whose APK the system will not let it open (some system and work-profile
  apps) are **Unverified** too — that is an absence of evidence, not a pass.
- An APK sitting in `Downloads` is invisible until someone installs it, and a
  brand-new clean-looking malicious package can still come back Secure.

**Scoring is pattern-based.** It catches impersonation of a known brand, risky
permission combinations, debug builds, sideloaded packages, nested APKs, a
changed signer, SMS-sending code, C2-looking strings and runtime code loading.
It does not know reputation, so it can be wrong in both directions.

**Tunnels are temporary.** The random address changes every run and dies when you
stop `start.sh`. A payload flashed yesterday points at a dead tunnel and shows
Cloudflare **error 1033** — re-run and re-copy. Cloudflare's own banner states
these account-less tunnels carry no uptime guarantee.

**Localhost payloads are useless on a phone.** If DNS is broken so no tunnel can
be made, `start.sh` says so loudly; with `PS_REQUIRE_TUNNEL=1` it stops instead
of writing LAN/localhost payloads.

---

## Rebuilding the agent

Source is in `android/`. The APK in this kit is the tested build:

```
size    832084 bytes
sha256  df4f3cc7676d28988444cedb2ea89dda57f4386433db1b562c4ad2258b425719
package com.phantomshell.agent   versionCode 13   versionName 2.1.1
minSdk 24   targetSdk 34   signed v2 + v3
```

### What is new in 2.1.1: the tab underline lines up

The blue bar under SCAN / SETTINGS sat to one side of its own word. It was not a
spacing tweak that was needed - the two were being laid out by different rules. A
child added to a vertical `LinearLayout` without explicit params is given
`MATCH_PARENT` width, so the label filled the whole cell and its text ran from the
left edge, while the bar - which did have an explicit 26dp width - was centred by
the parent's gravity. Measured on the real screen (360 dp wide, captured at 540 px):
word centre 65.5 px, bar centre 149.5 px, 84 px apart.

Both are now drawn by one small `TabView`, from the same centre, with the bar
measured from the very letters above it. The word and its underline share a
centre by construction, instead of by two layout rules happening to agree. The
bar is also as wide as the word now; it was a fixed 26dp under a 65dp word,
which is not what a tab underline is supposed to look like.

### What is new in 2.1: a phone app that looks like the dashboard

- **The film is the header.** The same clip the sign-in card plays is bundled in
  the APK and fills the screen behind the app, cropped to cover (never stretched),
  muted and looping. A scrim darkens the top for the header and goes almost solid
  at the bottom where the controls are, so the text stays readable over moving
  video. If a handset refuses the codec, a navy gradient with a faint grid and two
  slow glows is drawn underneath, so the screen still looks deliberate instead of
  showing a black rectangle.
- **An intro, then the app.** On launch the crest draws itself over the video and
  fades out, so the first thing you see is the mark rather than a half-built form.
- **SCAN and SETTINGS slide.** Two full-screen pages, swiped sideways, with a tab
  bar that moves with them: SCAN holds the score and the buttons, SETTINGS holds
  the dashboard address, the device tag, protection and the schedule. The pager is
  written by hand - this kit carries no AndroidX, so a ViewPager2 would have meant
  a dependency the rest of the build does not need. A vertical drag is left to the
  page's own ScrollView, or the settings list could not be scrolled.
- **One round GO button.** Press it and the phone scans; the gauge sweeps to the
  score. The arc and the number are driven by the same animated float, so the ring
  can never come to rest somewhere the digits do not point at, and the caption
  (SAFE / WATCH / AT RISK) changes band exactly as the number crosses 85 or 60.
  GO follows the saved settings: it reports when a dashboard address is set and
  stays local when it is not.
- **The 2.0 promise is still an explicit button.** Under GO sits **SCAN THIS
  PHONE ONLY**, which passes `report=false` whatever is saved, so a phone can be
  checked on a bench with no dashboard address and no device tag. The 2.0 button
  is not gone; it is one tap below the new one.
- **The APK is bigger, and that is the video.** 90,581 bytes in 2.0, 832,084 here;
  `res/raw/bg.mp4` is stored uncompressed so `MediaPlayer` can read it without a
  decode pass, and it is 685,114 of those bytes. Audio is muted at the player.
- `versionCode` went 11 -> 12, so installing this over 2.0 is an in-place upgrade:
  settings, the saved dashboard address and the remembered per-app signatures all
  survive.

### What is new in 2.0: a scan that needs no dashboard

- **Scan this phone only (no dashboard).** A second button on the main screen. It
  lists and grades every installed app exactly as the reporting scan does — same
  app list, same scoring, same rows — but it never touches the network, reads no
  device tag, and needs no dashboard address. It works on a phone that has never
  been configured at all.
- **The result opens on the phone.** A scrollable screen, one block per app,
  worst first: risk, name, package, *where it came from*, why it was flagged and
  what to do. Text is selectable, so a finding can be copied out without a
  screenshot.
- **The network is skipped in code, not by convention.** The scan path takes an
  explicit `report` flag; the phone-only button passes `false`, so `send()` is
  never reached even when a dashboard address is saved. A test can read that in
  the source, which is what makes the claim checkable.
- A High finding still raises its notification. Only the "all clear" popup is
  suppressed, because the person is already looking at the result.

`versionCode` and `versionName` live in `android/AndroidManifest.xml`. `aapt2
link` quietly ignores `--version-code` / `--version-name`, so the manifest is the
only place that decides them.

### What is new in 1.8: only what came from outside a store

- **Store apps are not listed any more.** A phone that ships with Facebook used
  to show it as **High**, because its installer is `com.facebook.system` — the
  vendor's own preload updater — which the agent did not recognise as a store.
  The row was technically honest about the installer and completely wrong about
  the phone. Store apps are now never sent and never stored, and the vendor
  updaters are in the known-store list as well.
- **Two levels, not four.** An app is **Safe** or **High**. The separate
  "Verdict" column (Secure / Review / Unsafe / Unverified) was answered by a
  different set of rules from the risk badge, which is how a row could read
  HIGH next to SECURE. The column is gone; the badge is the only answer, and the
  PDF and the phone's own summary screen say the same two words.
- **High has to be earned.** The +5 for "sideloaded" was removed: with only
  outside-store apps on the table it applied to every row, so everything was
  High. Points now come from what the app can do, which means a plain APK with
  no dangerous permissions lands on Safe and the High rows stand out again.
- **Four tiles: Phones, Reports, Risk, Apps.** Risk counts the High rows, Apps
  counts the outside-store rows. The Sites / Blocked / Critical / Secure /
  Unsafe tiles that belonged to the removed web guard are gone with it.
- **An older phone is filtered on the server too.** A 1.7 build still reports
  every app it sees; the server drops store and system rows on arrival, so an
  un-upgraded handset cannot put them back on the board.

### What is new in 1.7: Clear on the phone, and phones that stay put

- **"Clear - start fresh" on the phone.** The PhantomShell screen has a new
  button under *Scan installed apps now*. It wipes only what the handset keeps
  about itself — the last scan, its detection list and the remembered per-app
  signatures — stops the scheduled job and shows the screen the way a fresh
  install looks. It never calls the server, so the phone stays on your dashboard
  with its history and its app table exactly where they were. Use it when a scan
  looks wrong and you want the phone clean, not when you want it unregistered.
- **A finished scan lands on your account even with the console closed.** Reports
  used to be written only while somebody was signed in. The row already belongs
  to an account, so it is saved either way: sign in afterwards and the phone and
  its log are waiting.
- **Signing out keeps everything.** Sign-out closes the cookie and nothing else;
  signing back in reads the same phones and the same log back.
- **The phone-link card is gone.** A phone that reports to the bare address is
  filed under the account that used the dashboard last — remembered in
  `server/state.json`, so it survives a restart — and a phone that already has
  an owner never moves to the next person who signs in. The private
  `/u/<address>` address still exists when you want to pin a handset to one
  account.

### What is new in 1.6: the device fingerprint is back

1.5 identified a phone by a bare id, so two handsets in the same household
looked alike. 1.6 sends the details again, built once per run and attached to
every report.

- **What is collected.** Manufacturer, model, brand, device, product, full build
  fingerprint, Android release, SDK level, security patch level, ABI list,
  screen size and density, cores, total RAM, total storage, locale,
  `ANDROID_ID`, the adb switch, and root/emulator signals. All of it is
  permission-free: no IMEI, no serial, no phone number, no contacts.
- **Where it shows on the dashboard.** Under each device name: a `Fingerprint`
  line, a `Hardware` line (screen, dpi, cores, RAM) and a `Flags` line
  (adb / emulator / root). The PDF log carries the same fields.
- **On the phone itself**, the PhantomShell screen prints `Phone:` (make, model,
  Android version, SDK) and the build fingerprint, so you can read off what was
  sent without signing in anywhere.
- **Every path sends it.** The button in the app, the 6-hour scheduled scan
  and the new-app receiver all attach the same fingerprint, so a row that
  appears while the app is closed still names the real handset.
- **It identifies, it does not track.** `ANDROID_ID` is per app-signing-key and
  per user on Android 8+, so it does not follow the phone across other apps or
  survive a factory reset. Nothing is sent while the app is idle; the phone only
  reports when you run a scan or press Send now.

### What is new in 1.5: the file-level scan

1.4 answered from metadata alone. 1.5 opens the app.

- **Every installed APK is read, not just described.** `ApkInspector` walks the
  zip, reads up to 6 MB of each `classes*.dex`, lists native libraries, counts
  manifest entries and looks for nested `.apk` / `.jar` / `.dex` files hidden in
  `assets/`. The whole scan stops reading after 120 MB.
- **One answer per app.** Secure, Review, Unsafe or Unverified — plus High,
  Medium or Low confidence and one plain sentence saying why.
- **Hidden apps are named.** An app with no launcher icon and no system flag is
  flagged, because that is how a lot of unwanted software hides.
- **New file evidence counts toward the score.** A nested APK (+6), a signer
  that changed since the last scan of that package (+8), SMS-sending code (+4),
  C2-looking strings (+5), a packer or encrypted dex (+3), runtime code loading
  (+3), root tooling (+3), no launcher icon (+3), base64-run obfuscation (+2),
  three or more exported components (+2), several signers (+2), no readable dex
  (+2).

Dashboard side of the same release:

- **Tools you can install** panel for qFlipper and RustDesk. The kit does not
  ship them: put the real installer in `server/downloads/` and the panel shows
  its size and sha256. Nothing is listed, and no checksum is invented, when the
  file is absent.
- **`payload_tunnel_apk.txt`**: a BadUSB payload for a phone that already has
  the app. Open PhantomShell, tap the "Dashboard address" field, plug the Kiisu
  in, run the payload: it types this run's Cloudflare address into that field and
  presses nothing else.
- **One sign-in, and it is what files the data.** Each row is written under the
  account that owns the phone. Since 1.7 that happens whether or not a console
  is open, and signing out leaves the file alone rather than erasing it.

### What is new in 1.4: the web guard is gone

The optional DNS filter was removed from the app completely, not just switched
off. `GuardVpnService`, the DNS packet parser, the VPN consent flow, the
`BIND_VPN_SERVICE` service entry and both foreground-service permissions are all
deleted, so there is no code path left that could take over the phone's DNS.

- **Protection = app scanner.** It scans every installed app and reports it.
  That is the whole feature set now.
- **No VPN permission is ever requested**, and Android's VPN consent dialog no
  longer appears.
- **No foreground service.** The scanner runs as a scheduled `JobService`, which
  needs no ongoing notification and no special-use permission.
- **Upgrades clean up after themselves.** Android keeps the old preference keys,
  so `migrate()` deletes `enabled`, `consent` and `vpn_consent` on first launch
  of 1.4. Three keys whose only purpose was to build the tunnel.
- **The proof list moved to the dashboard.** The on-phone detection list was
  filled by the guard, so it went with it; the payload checker and app table on
  the dashboard are the places to look now.

The binary confirms it: `strings classes.dex` finds zero occurrences of
`VpnService`, `GuardVpnService`, `DnsPacket` or `BIND_VPN_SERVICE`, and
`aapt dump badging` lists only INTERNET, ACCESS_NETWORK_STATE,
POST_NOTIFICATIONS, QUERY_ALL_PACKAGES, RECEIVE_BOOT_COMPLETED and
REQUEST_IGNORE_BATTERY_OPTIMIZATIONS.

### What changed in 1.3 (history)

1.2 had one bad habit: **Start protection** created the DNS `VpnService`. That is
exactly why the phone looked offline afterwards — any fault inside the tunnel
(a stalled upstream, query saturation, an OEM killing the worker) leaves the
phone with no name resolution at all. 1.3 separates the two features:

- **Start protection = scanner only.** No `VpnService`, no route, no DNS server,
  so Wi-Fi and mobile data keep working exactly as before. It runs the package
  scan, books the 6-hour job and reports to the dashboard.
- **Turn web guard ON = the DNS filter.** Separate button, separate consent,
  clearly labelled as optional and as the only part that can affect browsing.
- **The off switch really turns off.** The flag, the scheduled job and any
  running web guard are cleared together, so nothing keeps scanning after the
  user says stop.
- **The screen shows reality, not a wish.** The status line reads live service
  state, so it can no longer say "off" while something still runs, or "on"
  while nothing does.
- **A dead upstream answers SERVFAIL** instead of staying silent, so apps fail
  fast instead of hanging until their own timeout.

### What changed in 1.1 (and why browsing broke in 1.0)

Three faults in the DNS path made the phone unusable on many networks:

1. **Hardcoded resolvers.** 1.0 always forwarded to `1.1.1.1` and `8.8.8.8`.
   Any carrier, campus or office network that only permits its own resolver
   made every lookup fail — which looks exactly like "no internet". 1.1 reads
   the network's real DNS servers with `ConnectivityManager` +
   `LinkProperties.getDnsServers()`, keeps them first, and refreshes them via a
   `NetworkCallback` when the phone moves between Wi-Fi and mobile data.
2. **Silence on failure.** 1.0 wrote nothing back when no resolver answered, so
   each app waited out its own timeout. 1.1 writes a proper **SERVFAIL**, so
   the browser fails fast instead of hanging.
3. **HTTP inside the DNS path.** 1.0 posted to `/api/agent/grade` with a 2500 ms
   timeout for *every* query, on one thread. A slow or unreachable dashboard
   stalled every lookup. 1.1 grades locally and instantly, caches dashboard
   verdicts for 5 minutes, and consults the dashboard in the background.

Queries are now resolved by a small thread pool rather than one serial loop, and
writes to the tunnel are synchronised.

### What is new in 1.2: the background malware scanner

The agent now works like an antivirus product on the handset, not only a DNS
filter:

- **First scan the moment protection starts.** Every installed app is measured
  and sent in one batch: package, label, version, size, installer, `targetSdk`,
  debuggable, system/updated-system, accessibility service, device admin,
  notification access, the dangerous permissions, the APK `sha256` and the
  signer.
- **Real-time monitoring.** `ScanReceiver` listens for `PACKAGE_ADDED`,
  `PACKAGE_REPLACED` and `PACKAGE_REMOVED`, so an app installed while the phone
  sits in a pocket is scanned seconds later. It calls `goAsync()` so Android does
  not kill the work halfway through.
- **Periodic rescan.** `ScanJobService` runs a JobScheduler job every 6 hours and
  after a reboot, so a phone nobody touches still reports.
- **On-phone alert.** Critical and High results raise a notification with the app
  name, the reason and what to do, and are listed in the in-app "Detections on
  this phone" screen.
- **Dashboard.** The new **Installed apps — malware scan** panel, plus the same
  rows inside the PDF log.

Scoring was calibrated against real packages rather than guessed. A genuine
WhatsApp (camera, contacts, microphone, `CALL_PHONE`) scores **Safe**; a clone
using the WhatsApp name with a different package name scores **High**.
Impersonation is matched against an exact package list per brand (`com.whatsapp`,
`com.whatsapp.w4b`, …) instead of a prefix, so `com.whatsapp.gold` no longer
passes as the real app.

### Alerting (as of 1.4)

Every risky app (High **and** Critical) produces a **notification** carrying the
app name, the reason and the guidance text, and a row in the dashboard's app
table and PDF log. The old on-phone "Detections" list belonged to the DNS guard
and was removed with it in 1.4.

`build_apk.sh` rebuilds and re-signs with `android/keystore/ps-agent.jks`. If you
rebuild, bump `versionCode` in `AndroidManifest.xml` so Android treats it as an
upgrade rather than the same version.
