PhantomShell - third-party installers
=====================================

This folder is where the dashboard looks for the two tools it offers in its
"Tools you can install" panel. The kit does not ship them and never downloads
them for you: they belong to their own makers, and you should get them from the
maker's own page.

    qFlipper   https://flipper.net/pages/downloads    (Flipper Devices)
    RustDesk   https://rustdesk.com/download          (RustDesk)

Put the real installer here, and the panel lists it with the size and the
sha256 of that exact file:

    cp ~/Downloads/qFlipper-*-win64-installer.exe   ~/phantomshell/server/downloads/
    cp ~/Downloads/RustDesk-*-x86_64.exe            ~/phantomshell/server/downloads/

Rules the panel follows:

  * a file is offered only if its name contains "qflipper" or "rustdesk"
    (case does not matter) and ends in .exe, .msi or .zip;
  * an .exe wins over an .msi or .zip when both are there;
  * the checksum shown is calculated from the file on this machine, so it
    changes when you replace the file;
  * if the file is absent the panel says "not bundled" and shows no checksum.
    It never invents one.

Nothing here is required for PhantomShell to work. The phone agent, the
dashboard, the payloads and the PDF report all run without this folder.
