#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
PhantomShell dashboard server  (clean, single file)
===================================================

This one file does everything the Kali side needs:

    GET  /health              simple liveness check -> "alive"
    GET  /login               the sign-in / create-account card
    GET  /dashboard           the dashboard page (index.html), login required
    GET  /logout              drop the session, back to /login
    GET  /agent               the install page for the phone
    GET  /agent.apk           the agent APK the phone downloads
    GET  /downloads           third-party installers found on this machine
    GET  /download/<key>      one of those installers, as a file
    POST /api/agent/grade     phone asks "is this site safe?" -> verdict
    POST /api/agent/report    phone sends fingerprint + sites it visited
    GET  /api/state           dashboard asks "what do we know so far?"

The phone reaches this server from ANY network through the public tunnel
address printed by start.sh (a Cloudflare quick tunnel). Both sides are on the
same URL, so nothing has to be on the same Wi-Fi.

Run:   python3 phantomshell_server.py
Env:   PS_PORT                port to listen on            (default 8085)
       PS_BIND                address to bind              (default 0.0.0.0)
       PS_SIGNUP_CODE         if set, creating an account needs this code

There is no built-in login. The first account is made in the browser, on the
sign-in page, and nothing ships with a password already set.

Signing in is the only way in. Data is filed per account: a phone belongs to the
account that owns it, so a report is written to state.json even when no console
is open, and signing out leaves the phones and the log in place for the next
sign-in.
"""

import base64
import collections
import hashlib
import hmac
import io
import json
import os
import re
import secrets
import smtplib
import socket
import subprocess
import threading
import time
import urllib.request
import zipfile
from datetime import datetime
from email.message import EmailMessage
from html import escape
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from http.cookies import SimpleCookie
from urllib.parse import urlparse, parse_qs, urlencode

# --------------------------------------------------------------------------
# Where things live
# --------------------------------------------------------------------------
HERE = os.path.dirname(os.path.abspath(__file__))
APK_PATH = os.path.join(HERE, "apks", "phantomshell-agent.apk")
INDEX_PATH = os.path.join(HERE, "index.html")
AGENT_PAGE_PATH = os.path.join(HERE, "agent.html")
STATE_PATH = os.path.join(HERE, "state.json")

# The payloads are written by start.sh into ../payloads (or ./payloads if you
# copied the server on its own). The dashboard offers them for download.
PAYLOAD_DIR = os.path.join(os.path.dirname(HERE), "payloads")
if not os.path.isdir(PAYLOAD_DIR):
    PAYLOAD_DIR = os.path.join(HERE, "payloads")

# The files a phone can actually use, and the only ones the dashboard offers.
# start.sh writes exactly these two into payloads/ - nothing else is generated,
# listed on the page, or packed into the zip.
PAYLOAD_FILES = (
    "payload_tunnel_apk.txt",
    "payload_android_ducky.txt",
)

# --------------------------------------------------------------------------
# Third-party installers
#
# The kit never ships or fetches somebody else's binary. Put the real installer
# in server/downloads/ and the dashboard lists it with the size and the sha256
# of the file that is actually sitting there. When the file is absent the row
# says "not bundled" and shows no checksum - nothing is invented.
# --------------------------------------------------------------------------
DOWNLOAD_DIR = os.path.join(HERE, "downloads")
DOWNLOADS = (
    {"key": "qflipper", "label": "qFlipper", "match": ("qflipper",),
     "what": "Windows app for Kiisu",
     "why": "drags the payload onto the board",
     "vendor": "Flipper Devices", "site": "https://flipper.net/pages/downloads"},
    {"key": "rustdesk", "label": "RustDesk", "match": ("rustdesk",),
     "what": "remote desktop for Windows",
     "why": "supports the phone from another machine",
     "vendor": "RustDesk", "site": "https://rustdesk.com/download"},
    # A pointer, not an installer. kind=link skips server/downloads entirely,
    # because there is no file to hash: the row is the address itself. It sits
    # last so it reads as "and the source is here" after the two tools above.
    {"key": "github", "label": "PhantomShell on GitHub", "kind": "link",
     "match": (),
     "what": "the project source",
     "why": "read the code and follow releases",
     "vendor": "GitHub",
     "site": "https://github.com/phantomshell2026/phantomshell-project-2026"},
)

# sha256 of an installer is cached by (path, mtime, size), so pressing refresh
# does not re-read a 60 MB file on every dashboard frame.
DOWNLOAD_CACHE = {}

# android.content.pm.PackageManager.PackageSource, as the phone reports it.
# STORE is the answer that matters here: it is the platform saying a store
# delivered the app, which no heuristic should be allowed to override.
PACKAGE_SOURCE_UNSPECIFIED = 0
PACKAGE_SOURCE_STORE = 1
PACKAGE_SOURCE_LOCAL_FILE = 2
PACKAGE_SOURCE_DOWNLOADED_FILE = 3
PACKAGE_SOURCE_OTHER = 4

# Answered on both sides, on purpose. The phone decides with the same rules, and
# the server decides again for every row it stores, so a row written by an older
# build cannot bring a store app back into the table.
AGENT_PACKAGE = "com.phantomshell.agent"

# Packages that mean "a store delivered this". Anything here wins over every
# other signal, because Play, Galaxy Store and friends hand the actual install
# to com.google.android.packageinstaller on most phones - so the package that
# performed the install says nothing about where the app came from.
STORE_PACKAGES = {
    "com.android.vending": "Google Play",
    "com.google.android.feedback": "Google Play",
    "com.sec.android.app.samsungapps": "Galaxy Store",
    "com.xiaomi.mipicks": "GetApps",
    "com.huawei.appmarket": "AppGallery",
    "com.heytap.market": "HeyTap Store",
    "com.oppo.market": "HeyTap Store",
    "com.vivo.appstore": "vivo Store",
    "com.bbk.appstore": "vivo Store",
    "com.transsion.appstore": "Transsion Store",
    "com.amazon.venezia": "Amazon Appstore",
    "org.fdroid.fdroid": "F-Droid",
}

# Apps a phone ships with. They have no install chain because no app installed
# them, which otherwise looks exactly like a sideload. Only consulted when there
# is no chain at all, so a real download of the same app still counts.
PRELOAD_PACKAGES = {
    "com.facebook.system": "came with the phone",
    "com.facebook.appmanager": "came with the phone",
    "com.facebook.services": "came with the phone",
    "com.facebook.katana": "came with the phone",
    "com.netflix.mediaclient": "came with the phone",
    "com.spotify.music": "came with the phone",
    "com.linkedin.android": "came with the phone",
    "com.amazon.mShop.android.shopping": "came with the phone",
    "com.microsoft.skydrive": "came with the phone",
}


def _install_chain(row):
    """The packages Android names for one install, most specific first."""
    chain = []
    for key in ("originating", "initiating", "installer"):
        val = str(row.get(key) or "").strip()
        if val and val not in chain:
            chain.append(val)
    return chain


def outside_store(row):
    """Did this app come from outside a store?  Returns (answer, reason).

    True only when the evidence says it is a user app that no store delivered.
    Every other answer carries the reason it was kept out, so a row that is
    missing from the table can always be explained rather than just absent.

    A store anywhere in the chain outranks everything else. That is the whole
    bug this replaces: one installing package name called every Play app on a
    vivo and a Samsung a sideload, because both hand the install to the package
    installer.
    """
    pkg = str(row.get("package") or "").strip()
    if pkg == AGENT_PACKAGE:
        return False, "the PhantomShell agent itself"
    if row.get("system"):
        return False, "a system app"

    chain = _install_chain(row)
    for link in chain:
        store = STORE_PACKAGES.get(link)
        if store:
            return False, "delivered by " + store
    if row.get("from_store"):
        return False, "delivered by a store"

    try:
        source = int(row.get("package_source"))
    except (TypeError, ValueError):
        source = -1
    if source == PACKAGE_SOURCE_STORE:
        return False, "delivered by a store"

    # No chain at all means no app installed it. On this platform that is a
    # vendor preload sitting in the system image, not a choice the owner made,
    # so it is named only for packages known to ship that way.
    if not chain:
        preload = PRELOAD_PACKAGES.get(pkg)
        if preload:
            return False, preload
        if source not in (PACKAGE_SOURCE_LOCAL_FILE,
                          PACKAGE_SOURCE_DOWNLOADED_FILE) \
                and not row.get("sideloaded"):
            return False, "Android recorded no install source"

    return True, "not from a store"


def refresh_scan_note(dev):
    """Make the scan log line say what the table says.

    The phone writes its own summary, and its count includes the agent and the
    vendor preloads that the table keeps out, so the log could claim four while
    three rows sit above it. After the rows are reconciled this rewrites the
    note from the rows themselves, which is the only number that can be seen.
    """
    did = dev.get("device_id") or "unknown"
    with LOCK:
        rows = visible_apps([dict(r) for r in STATE["apks"].values()
                             if r.get("device_id") == did])
        high = sum(1 for r in rows if r.get("risk") == "High")
        summary = dev.get("scan") or {}
        note = "{} apps checked, {} from outside a store: {} high, {} safe".format(
            summary.get("checked", 0), len(rows), high, len(rows) - high)
        if summary.get("store"):
            note += ", {} from a store".format(summary["store"])
        summary["details"] = note
        summary["outside"] = len(rows)
        summary["high"] = high
        summary["safe"] = len(rows) - high
        dev["scan"] = summary
        for row in STATE["recent"]:
            if row.get("action") == "scan" and row.get("device_id") == did:
                row["reason"] = note
                break
    return note


def purge_device_apps(did, keep_packages):
    """A full scan is the truth for that phone.

    When a report carries a scan summary, every stored row for that device that
    the scan did not re-report is dropped. Without this a row written by an
    older build - a Play app called a sideload, an app since uninstalled - sits
    in the table forever, because the phone only ever sends apps that are still
    outside a store.
    """
    prefix = (did or "unknown") + "|"
    dropped = 0
    with LOCK:
        for key in [k for k in STATE["apks"] if str(k).startswith(prefix)]:
            if str(key)[len(prefix):] not in keep_packages:
                del STATE["apks"][key]
                dropped += 1
    return dropped

# Public IP is looked up once and cached for a few minutes.
NET_CACHE = {"at": 0.0, "public": ""}

PORT = int(os.environ.get("PS_PORT", "8085"))
BIND = os.environ.get("PS_BIND", "0.0.0.0")

# --------------------------------------------------------------------------
# Console login
#
# One page guards the dashboard: /login -> /dashboard. It carries three panes:
# sign in, create an account, and reset a forgotten password. Nothing ships
# with a login already set - the first account is made on that page - so the
# card never prints a username or a password.
# --------------------------------------------------------------------------
LOGIN_HTML_PATH = os.path.join(HERE, "login.html")
LOGO_PATH = os.path.join(HERE, "logo.jpg")
# Background video for the sign-in card and the console, plus the still frame
# that paints instantly while the video buffers.
VIDEO_PATH = os.path.join(HERE, "phantomshell.mp4")
POSTER_PATH = os.path.join(HERE, "phantomshell-poster.jpg")
# Fonts are served from disk rather than a CDN, so the console renders the same
# on a LAN-only bench or a locked-down network with no internet access.
FONT_DIR = os.path.join(HERE, "fonts")
FONT_TYPES = {
    "silkscreen-400.woff2": "font/woff2",
    "silkscreen-700.woff2": "font/woff2",
    "vt323-400.woff2": "font/woff2",
    "OFL-silkscreen.txt": "text/plain; charset=utf-8",
    "OFL-vt323.txt": "text/plain; charset=utf-8",
    "README.txt": "text/plain; charset=utf-8",
}
# Portraits for the team panel at the bottom of the dashboard. Served from disk
# like the fonts, and named against a fixed list for the same reason: a path
# that is not on the list never reaches the filesystem.
TEAM_DIR = os.path.join(HERE, "team")
TEAM_TYPES = {
    "shafiq.jpg": "image/jpeg",
    "uwais.jpg": "image/jpeg",
    "saza.jpg": "image/jpeg",
    "aiman.jpg": "image/jpeg",
    "haziq.jpg": "image/jpeg",
}
FALLBACK_LOGIN = (
    "<!DOCTYPE html><html><head><meta charset='utf-8'>"
    "<title>PhantomShell - sign in</title></head>"
    "<body style='font-family:Georgia,serif;background:#12181c;color:#2b271f'>"
    "<form method='post' action='/api/login' "
    "style='max-width:360px;margin:12vh auto;padding:26px;background:#f8f3e7;"
    "border:1px solid #a98a4b'>"
    "<h2 style='letter-spacing:.16em;text-transform:uppercase;font-size:18px'>"
    "PhantomShell</h2><p>Username<br><input name='username' style='width:100%'>"
    "</p><p>Password<br><input name='password' type='password' "
    "style='width:100%'></p>"
    "<button style='width:100%;padding:10px'>Sign in</button></form></body></html>"
)
# --------------------------------------------------------------------------
# Accounts
# --------------------------------------------------------------------------
# Accounts live in their own file next to state.json, so clearing the activity
# log never touches who can sign in, and removing an account never touches the
# log.
#
# There is NO built-in account and no default password. A fresh install starts
# with an empty list and whoever opens /login makes the first account there -
# which is also why nothing prints a username or password on the sign-in card.
# The file is the only authority: once it exists, deleting an account (even the
# last one) is permanent and a restart does not bring anything back. To start
# over on a bench machine, delete accounts.json and restart.
ACCOUNTS_PATH = os.path.join(HERE, "accounts.json")
ACCOUNT_ROUNDS = 240000
MIN_PASSWORD = 8
USERNAME_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._-]{2,23}$")
ACCOUNTS = {}
ACCOUNT_LOCK = threading.Lock()
# Optional invite code. Empty means anyone who can load /login may make an
# account. Set PS_SIGNUP_CODE when the dashboard is reachable from the public
# tunnel and you do not want strangers registering.
SIGNUP_CODE = os.environ.get("PS_SIGNUP_CODE", "").strip()
SIGNUP_TRIES = {}
SIGNUP_MAX = 6
SIGNUP_WINDOW = 600
MAX_ACCOUNTS = 50

# --------------------------------------------------------------------------
# Email, and the password reset that depends on it
#
# An account carries an email address so a forgotten password can be reset
# without an administrator. Nothing is mailed unless somebody asks for a reset,
# and the address never leaves this machine except as the envelope of that one
# message.
# --------------------------------------------------------------------------
# Deliberately loose: this checks the shape of an address, not whether it can
# receive mail. The only real proof of that is the code arriving.
EMAIL_RE = re.compile(r"^[^@\s]{1,64}@[^@\s]{1,190}\.[A-Za-z]{2,24}$")

# Outgoing mail. PS_SMTP_HOST and PS_SMTP_FROM are the two that must be set;
# the rest have working defaults for Gmail-style SSL on port 465.
#   PS_SMTP_PORT  465 (ssl) / 587 (starttls) / 25 (none)
#   PS_SMTP_TLS   ssl | starttls | none
#   PS_SMTP_USER / PS_SMTP_PASS   mailbox login, if it needs one
SMTP_HOST = os.environ.get("PS_SMTP_HOST", "").strip()
SMTP_PORT = int(os.environ.get("PS_SMTP_PORT", "465").strip() or 465)
SMTP_USER = os.environ.get("PS_SMTP_USER", "").strip()
SMTP_PASS = os.environ.get("PS_SMTP_PASS", "")
SMTP_FROM = os.environ.get("PS_SMTP_FROM", "").strip() or SMTP_USER
SMTP_TLS = os.environ.get("PS_SMTP_TLS", "ssl").strip().lower()
MAIL_READY = bool(SMTP_HOST and SMTP_FROM)

# One live code per account: six digits, works once, expires after OTP_TTL
# seconds, and is stored ONLY as an HMAC of the account and the digits. Reading
# accounts.json therefore reveals no code that could still be used.
OTP_TTL = int(os.environ.get("PS_OTP_TTL", "600").strip() or 600)
OTP_MAX_TRIES = 5
OTP_RESEND = 60
RESET_CODES = {}                 # account key -> {hash, exp, tries, sent}
FORGOT_TRIES = {}                # client ip -> [count, first_epoch]
FORGOT_MAX = 5
FORGOT_WINDOW = 900
# Lab only, for a box with no mailbox: PS_OTP_CONSOLE=1 also prints the code to
# the server log. Off unless it is asked for on purpose.
OTP_CONSOLE = os.environ.get("PS_OTP_CONSOLE", "").strip() in ("1", "yes", "true")

# Kept for backwards compatibility: PS_PASSWORD still works as an extra
# password-only gate on the JSON API (leave it unset on a normal install).
PASSWORD = os.environ.get("PS_PASSWORD", "").strip()

COOKIE = "ps_session"
SESSION_TTL = 12 * 3600          # a shift-length session
SESSIONS = {}                    # token -> {exp, provider, email}
LOGIN_TRIES = {}                 # client ip -> [count, first_epoch]
LOGIN_MAX_TRIES = 8
LOGIN_WINDOW = 300

# --------------------------------------------------------------------------
# What is remembered, and by whom
#
# A phone's batch is kept whether or not a dashboard tab happens to be open.
# The row carries the account it belongs to, the file is written as soon as
# the report arrives, and the same file is read back on the next sign-in or
# after a restart. What keeps two people apart is the owner on each row, not
# which session was open when the phone reported.
#
# A session only decides one thing: which account a phone is paired with when
# it reports on the shared address. That is the account whose dashboard was
# used last, remembered in state.json.
# --------------------------------------------------------------------------
def _prune_sessions():
    """Forget sessions that have expired."""
    now = time.time()
    for token in list(SESSIONS):
        if SESSIONS[token].get("exp", 0) < now:
            SESSIONS.pop(token, None)


def live_sessions():
    """How many console sessions have not expired."""
    _prune_sessions()
    return len(SESSIONS)


def auth_state(user=""):
    """What the dashboard should say about the session it is showing."""
    open_now = live_sessions() > 0
    return {
        "provider": "console" if open_now else "none",
        "user": user or "",
        "saving": bool(_account_key(user)) or open_now,
        "signup_open": True,
        "signup_code": bool(SIGNUP_CODE),
    }


def enforce_signed_out():
    """Notice that the last console has gone. Nothing is thrown away.

    Phones, apps and the log stay in memory and in state.json: they belong to
    an account, and the next sign-in reads the same rows back. Dropping them
    here is what used to make a phone vanish from its own dashboard after a
    sign-out.
    """
    _prune_sessions()


def start_local_session():
    """Signing in: bring back the log that was saved last time."""
    restore_state()


def _hash_password(password, salt=None, rounds=ACCOUNT_ROUNDS):
    """PBKDF2-SHA256, stored as one printable string."""
    if salt is None:
        salt = secrets.token_hex(16)
    digest = hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"),
                                bytes.fromhex(salt), rounds)
    return "pbkdf2_sha256${}${}${}".format(rounds, salt, digest.hex())


def _check_password(stored, password):
    """Compare a password with a stored hash. No early exit on purpose."""
    try:
        kind, rounds, salt, want = str(stored).split("$", 3)
        if kind != "pbkdf2_sha256":
            return False
        got = hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"),
                                 bytes.fromhex(salt), int(rounds)).hex()
    except (TypeError, ValueError):
        return False
    return hmac.compare_digest(got, want)


def load_accounts():
    """Read accounts.json. A missing or broken file means no accounts."""
    global ACCOUNTS
    try:
        with open(ACCOUNTS_PATH, "r") as f:
            raw = json.load(f)
    except (OSError, ValueError):
        raw = None
    found = {}
    rows = raw.get("accounts") if isinstance(raw, dict) else None
    if isinstance(rows, list):
        for row in rows:
            if not isinstance(row, dict):
                continue
            name = str(row.get("user") or "").strip()
            pwhash = str(row.get("hash") or "")
            if not name or not pwhash:
                continue
            found[name.lower()] = {"user": name, "hash": pwhash,
                                   "email": str(row.get("email") or ""),
                                   "created": row.get("created") or now_str(),
                                   "ingest": str(row.get("ingest") or "")}
    with ACCOUNT_LOCK:
        ACCOUNTS = found
    return len(found)


def save_accounts():
    """Write the account list atomically, readable by this user only."""
    with ACCOUNT_LOCK:
        rows = sorted(ACCOUNTS.values(), key=lambda a: a["user"].lower())
    blob = json.dumps({"accounts": rows}, indent=2) + "\n"
    tmp = ACCOUNTS_PATH + ".tmp"
    with open(tmp, "w") as f:
        f.write(blob)
    try:
        os.chmod(tmp, 0o600)
    except OSError:
        pass
    os.replace(tmp, ACCOUNTS_PATH)


def account_count():
    with ACCOUNT_LOCK:
        return len(ACCOUNTS)


def _account_key(name):
    """Usernames are matched without regard to case."""
    return str(name or "").strip().lower()


def normalise_email(address):
    """One spelling for an address, so case cannot make a second account."""
    return str(address or "").strip().lower()


def _email_owner(email):
    """The account key that already holds this address, or ""."""
    want = normalise_email(email)
    if not want:
        return ""
    with ACCOUNT_LOCK:
        for key, row in ACCOUNTS.items():
            if normalise_email((row or {}).get("email")) == want:
                return key
    return ""


def account_by_identifier(ident):
    """Look an account up by username or by email address."""
    ident = str(ident or "").strip()
    if not ident:
        return ""
    key = _account_key(ident)
    with ACCOUNT_LOCK:
        if key in ACCOUNTS:
            return key
    return _email_owner(ident)


# --------------------------------------------------------------------------
# One address per account for the phones
#
# Every account gets a private ingest token. The phone is pointed at
# /u/<token> instead of the bare server address, and whatever it reports is
# filed under that account only. The token is random and never derived from
# the username, so knowing somebody's name does not let you post into their
# log, and it is only ever shown on that account's own dashboard.
# --------------------------------------------------------------------------
INGEST_LEN = 12


def _new_ingest_token():
    """A short random path segment. Not guessable from the username."""
    return secrets.token_urlsafe(9)[:INGEST_LEN]


def ingest_token(name):
    """The token for one account, made on first use and remembered on disk."""
    key = _account_key(name)
    if not key:
        return ""
    with ACCOUNT_LOCK:
        row = ACCOUNTS.get(key)
        if row is None:
            return ""
        tok = str(row.get("ingest") or "")
    if tok:
        return tok
    tok = _new_ingest_token()
    made = False
    with ACCOUNT_LOCK:
        row = ACCOUNTS.get(key)
        if row is None:
            return ""
        if not row.get("ingest"):
            row["ingest"] = tok
            made = True
        else:
            tok = str(row["ingest"])
    if made:
        save_accounts()
    return tok


def account_for_token(token):
    """The account key a phone address belongs to ("" when it is not ours)."""
    tok = str(token or "").strip()
    if not tok:
        return ""
    with ACCOUNT_LOCK:
        for key, row in ACCOUNTS.items():
            if str((row or {}).get("ingest") or "") == tok:
                return key
    return ""


def ensure_ingest_tokens():
    """Give every account a token, including ones made before this existed."""
    made = 0
    with ACCOUNT_LOCK:
        for row in ACCOUNTS.values():
            if not row.get("ingest"):
                row["ingest"] = _new_ingest_token()
                made += 1
    if made:
        save_accounts()
    return made


def only_account_key():
    """The single account on this server, or "" when there are none or several."""
    with ACCOUNT_LOCK:
        if len(ACCOUNTS) == 1:
            return next(iter(ACCOUNTS))
    return ""


def set_account_password(name, password):
    """Replace the stored hash for one account. True when it existed."""
    key = _account_key(name)
    with ACCOUNT_LOCK:
        row = ACCOUNTS.get(key)
        if row is None:
            return False
        row["hash"] = _hash_password(password)
        row["changed"] = now_str()
    save_accounts()
    return True


# --------------------------------------------------------------------------
# Reset codes
# --------------------------------------------------------------------------
def _code_hash(key, code):
    """A code is stored only as this, so the file gives nothing away."""
    return hmac.new(b"phantomshell-reset",
                    "{}|{}".format(key, code).encode("utf-8"),
                    hashlib.sha256).hexdigest()


def issue_reset_code(key):
    """Make a fresh six-digit code for one account and remember it."""
    code = "{:06d}".format(secrets.randbelow(1000000))
    now = time.time()
    RESET_CODES[key] = {"hash": _code_hash(key, code),
                        "exp": now + OTP_TTL, "tries": 0, "sent": now}
    return code


def check_reset_code(key, code):
    """(ok, reason). A code is good once; after that it is gone."""
    code = str(code or "").strip()
    row = RESET_CODES.get(key)
    if not row:
        return False, "That code has expired. Ask for a new one."
    if row.get("exp", 0) < time.time():
        RESET_CODES.pop(key, None)
        return False, "That code has expired. Ask for a new one."
    if row.get("tries", 0) >= OTP_MAX_TRIES:
        RESET_CODES.pop(key, None)
        return False, "Too many wrong codes. Ask for a new one."
    row["tries"] = row.get("tries", 0) + 1
    if not hmac.compare_digest(_code_hash(key, code), str(row.get("hash"))):
        return False, "That code is not right."
    RESET_CODES.pop(key, None)
    return True, ""


def reset_mail_body(key, code):
    """What the person actually receives. Plain words, no links to click."""
    minutes = max(OTP_TTL // 60, 1)
    return (
        "Someone asked to reset the PhantomShell password for the account\n"
        "'{key}'.\n\n"
        "    Your code: {code}\n\n"
        "Type it on the sign-in page to choose a new password. It works once\n"
        "and expires in {minutes} minutes.\n\n"
        "If this was not you, ignore this email: the password stays as it is,\n"
        "and the code on its own cannot be used to sign in.\n"
    ).format(key=key, code=code, minutes=minutes)


def send_mail(to_addr, subject, body_text):
    """(sent, reason). One short-lived SMTP connection; no queue, no retry."""
    if not MAIL_READY:
        return False, "no mailbox is configured"
    msg = EmailMessage()
    msg["From"] = SMTP_FROM
    msg["To"] = to_addr
    msg["Subject"] = subject
    msg.set_content(body_text)
    server = None
    try:
        if SMTP_TLS == "ssl":
            server = smtplib.SMTP_SSL(SMTP_HOST, SMTP_PORT, timeout=15)
        else:
            server = smtplib.SMTP(SMTP_HOST, SMTP_PORT, timeout=15)
        if SMTP_TLS == "starttls":
            server.starttls()
        if SMTP_USER:
            server.login(SMTP_USER, SMTP_PASS)
        server.send_message(msg)
    except Exception as exc:            # any failure here is "not sent"
        return False, str(exc)[:200]
    finally:
        if server is not None:
            try:
                server.quit()
            except Exception:
                pass
    return True, ""


def create_account(name, email, password, require_email=True):
    """Add one account. Returns (ok, message).

    An email address is part of the account, because a forgotten password is
    reset by a code sent to it. Two accounts cannot share one address, or the
    reset would have to guess which account was meant.

    require_email is False in exactly one place: the very first account, which
    an operator may want to make without a mailbox. That account can still sign
    in, but it cannot be reset by email until an address is put on it.
    """
    name = str(name or "").strip()
    email = normalise_email(email)
    password = str(password or "")
    if not USERNAME_RE.match(name):
        return False, ("Username must be 3-24 characters: letters, numbers, "
                       "dot, dash or underscore, starting with a letter or "
                       "number.")
    if require_email or email:
        if not EMAIL_RE.match(email):
            return False, "That does not look like an email address."
    if len(password) < MIN_PASSWORD:
        return False, "Password must be at least {} characters.".format(MIN_PASSWORD)
    if len(password) > 200:
        return False, "That password is too long."
    if password.lower() in (name.lower(), email):
        return False, "The password cannot be the username or the email."
    key = _account_key(name)
    with ACCOUNT_LOCK:
        if key in ACCOUNTS:
            return False, "That username is already taken."
        # Checked inside the lock, and written with it held, so two people
        # cannot claim the same address or the same name at the same moment.
        if email and any(normalise_email((a or {}).get("email")) == email
                         for a in ACCOUNTS.values()):
            return False, "That email already has an account."
        if len(ACCOUNTS) >= MAX_ACCOUNTS:
            return False, ("This server already holds the most accounts it "
                           "will take ({}).".format(MAX_ACCOUNTS))
        ACCOUNTS[key] = {"user": name, "email": email,
                         "hash": _hash_password(password),
                         # Made here, not on first use: an account created
                         # while the server is running gets its private
                         # /u/<token> routes straight away.
                         "ingest": _new_ingest_token(),
                         "created": now_str()}
    save_accounts()
    return True, "Account created."


def verify_account(name, password):
    """The stored username when the password matches, otherwise ""."""
    password = str(password or "")
    with ACCOUNT_LOCK:
        row = ACCOUNTS.get(_account_key(name))
    if row is None:
        # The sign-in box accepts the email address too, so fall back to it.
        key = account_by_identifier(name)
        if key:
            with ACCOUNT_LOCK:
                row = ACCOUNTS.get(key)
    if row is None:
        # Do the same work as a real check, so response time does not reveal
        # whether a username exists.
        _hash_password(password, "00" * 16)
        return ""
    if not _check_password(row.get("hash"), password):
        return ""
    return row.get("user") or ""


def delete_account(name):
    """Remove one account from the file. Returns True if it existed."""
    key = _account_key(name)
    with ACCOUNT_LOCK:
        if key not in ACCOUNTS:
            return False
        ACCOUNTS.pop(key, None)
    save_accounts()
    return True


def drop_sessions_for(name):
    """Close every session that belongs to one account."""
    key = _account_key(name)
    gone = 0
    for token, meta in list(SESSIONS.items()):
        if _account_key((meta or {}).get("user")) == key:
            SESSIONS.pop(token, None)
            gone += 1
    if gone:
        enforce_signed_out()
    return gone


def restore_state():
    """Read the last saved session back when someone signs in again."""
    with LOCK:
        empty = not (STATE["devices"] or STATE["apks"] or STATE["recent"])
    if empty:
        load_state()


def remember_dashboard_owner(user):
    """Remember which account used this dashboard last, on disk as well.

    A phone that reports on the shared address is paired with this account, so
    a scan that finishes while the console is closed still lands on the right
    dashboard. The hint lives in state.json and therefore survives a restart.
    """
    key = _account_key(user)
    if not key:
        return ""
    with LOCK:
        STATE["dashboard_owner"] = key
    save_state()
    print("[state] dashboard owner is now {}".format(key), flush=True)
    return key


def clear_dashboard_owner(user):
    """Forget a hint that points at an account which no longer exists."""
    key = _account_key(user)
    with LOCK:
        if _account_key(STATE.get("dashboard_owner") or "") != key:
            return False
        STATE["dashboard_owner"] = ""
    save_state()
    return True


def dashboard_owner():
    """The account a phone reporting on the shared address belongs to now.

    The account that used the dashboard last wins. If that account has since
    been deleted, fall back to the only account on the server, when there is
    exactly one; with several, no honest guess exists and the row stays
    unpaired until its owner signs in again.
    """
    with LOCK:
        hint = _account_key(STATE.get("dashboard_owner") or "")
    with ACCOUNT_LOCK:
        known = hint in ACCOUNTS if hint else False
    if known:
        return hint
    return only_account_key()

# --------------------------------------------------------------------------
# Risk rules
#
# A hostname is the only thing the phone agent can honestly see (it watches DNS,
# not page contents), so the rules below are hostname-only. Every flag that
# matches raises the score; two or more flags means Critical, one means High.
# --------------------------------------------------------------------------
BAD_TLDS = (
    ".top", ".xyz", ".tk", ".ml", ".ga", ".cf", ".gq", ".work", ".click",
    ".link", ".buzz", ".rest", ".fit", ".cam", ".surf", ".monster", ".quest",
    ".cfd", ".sbs", ".icu", ".loan", ".download", ".zip", ".mov", ".country",
    ".stream", ".gdn", ".review",
)
BAD_WORDS = (
    "login", "verify", "secure", "account", "update", "signin", "wallet",
    "password", "passwd", "otp", "kyc", "refund", "invoice", "bonus", "prize",
    "gift", "lucky", "winner", "bank", "payment", "paypal", "netbanking",
    "upi", "unlock", "recover", "confirm", "support", "helpdesk", "offer",
    "reward", "claim", "urgent", "suspended", "blocked",
)

# Brands that phishing pages copy. If a brand name appears in a domain that is
# NOT that brand's own domain, that is a strong signal on its own.
BRANDS = (
    "paypal", "google", "apple", "microsoft", "amazon", "netflix", "whatsapp",
    "facebook", "instagram", "dhl", "fedex", "binance", "coinbase", "metamask",
    "maybank", "cimb", "bca", "mandiri", "bri", "gopay", "ovo", "dana",
    "shopee", "tokopedia", "alipay", "wechat", "icici", "hdfc", "sbi",
)

ADVICE = {
    "Safe": "Nothing unusual was measured. Normal browsing is fine - just check "
            "the address bar matches the site name.",
    "High": "Be careful. Do not enter personal details, do not allow downloads or "
            "'install' prompts, and do not continue past a warning page. If a page "
            "asks you to sign in, open the site from its own address instead of the "
            "link that brought you here.",
    "Critical": "Stop here. Do not type a password, card number or one-time code on "
                "this page. Close it. If you already typed something, change that "
                "password from a different app or tab.",
}

# Guidance for INSTALLED APPS. Kept separate from the web-page advice above: telling
# someone to "check the address bar" about an app on their phone makes no sense. The
# phone writes its own advice and it wins; this is only the fallback.
# Two answers only. A third entry here would let a stale phone file a level the
# dashboard, the chart and the PDF cannot draw.
APP_ADVICE = {
    "Safe": "Nothing unusual was measured for this app. Keep Play Protect on and "
            "scan again after the next update.",
    "High": "This app did not come from an app store. If you installed it yourself "
            "and trust where it came from, open Settings, Apps, pick it and switch "
            "off every permission it does not need - Accessibility, SMS and "
            "notification access first. If you do not recognise it, uninstall it: "
            "Settings, Apps, pick the app, Uninstall.",
}


def clean_host(raw):
    """Turn whatever the phone sent into a bare hostname."""
    h = (raw or "").strip().lower()
    h = h.split("://")[-1]          # drop any scheme
    h = h.split("/")[0]             # drop any path
    h = h.split("?")[0]             # drop any query
    h = h.split("@")[-1]            # drop any userinfo
    if h.count(":") == 1:           # drop a port, but keep IPv6 brackets
        h = h.split(":")[0]
    if h.endswith("."):
        h = h[:-1]
    return h[:253]


# Second-level labels that belong to the public suffix, so that
# shopee.co.id is read as "shopee" + "co.id" and not as "co" + "id".
SUFFIX_SECOND = {"co", "com", "net", "org", "gov", "ac", "edu", "or", "ne",
                 "go", "mil", "sch", "biz", "info"}


def reg_name(h):
    """The registered name of a host: 'www.paypal.com' -> 'paypal'."""
    labels = [p for p in h.split(".") if p]
    if len(labels) >= 3 and len(labels[-1]) == 2 and labels[-2] in SUFFIX_SECOND:
        return labels[-3]
    if len(labels) >= 2:
        return labels[-2]
    return labels[0] if labels else ""


# Real infrastructure domains that legitimately contain a brand-like token.
# Without this, apple-dns.net or login.microsoftonline.com look like a spoof.
KNOWN_GOOD_SUFFIX = (
    "apple-dns.net", "microsoftonline.com", "windowsupdate.com",
    "googleapis.com", "googleusercontent.com", "gstatic.com", "googlevideo.com",
    "paypalobjects.com", "paypal.com", "amazonaws.com", "cloudfront.net",
    "netflix.net", "nflxvideo.net", "whatsapp.net", "fbcdn.net", "instagram.com",
)


def brand_spoof(h):
    """A real brand name used as a whole label on someone else's domain.

    Matched label-by-label, not as a substring, so that googleapis.com or
    microsoftonline.com are not mistaken for a brand on a foreign domain.
    A label is split on '-' too, so paypal-verify-secure.com still matches.
    """
    for suffix in KNOWN_GOOD_SUFFIX:
        if h == suffix or h.endswith("." + suffix):
            return ""
    own = reg_name(h).replace("-", "")
    for label in h.split("."):
        for token in label.split("-"):
            if token in BRANDS and own != token:
                return token
    return ""


def grade(raw_host):
    """One hostname -> (risk, reason). risk is Safe / High / Critical.

    Signals are weighted, because a single weak signal on its own is normal:
    banks have "bank" in their domain, and "secure" appears everywhere. A
    keyword only matters when something else backs it up.

        strong (2 points) : abused TLD, brand name on the wrong domain, punycode
        medium (2 points) : bare IP instead of a name
        weak   (1 point)  : account/payment wording, very deep sub-domains

    3+ points -> Critical (blocked), 2 points -> High, else Safe.
    """
    h = clean_host(raw_host)
    if not h:
        return "Safe", "no host to check"

    flat = h.replace("-", "").replace(".", "")
    flags = []
    score = 0

    if any(h.endswith(t) for t in BAD_TLDS):
        flags.append("domain uses a heavily abused extension")
        score += 2

    spoof = brand_spoof(h)
    if spoof:
        flags.append("uses the " + spoof + " name on a domain that is not theirs")
        score += 2

    if "xn--" in h:
        flags.append("lookalike (punycode) address")
        score += 2

    if re.fullmatch(r"\d{1,3}(\.\d{1,3}){3}", h):
        flags.append("bare IP address instead of a domain name")
        score += 2

    if any(w in flat for w in BAD_WORDS):
        flags.append("address contains account or payment wording")
        score += 1

    if h.count(".") >= 5:
        flags.append("unusually deep sub-domain chain")
        score += 1

    if score >= 3:
        return "Critical", " + ".join(flags)
    if score == 2:
        return "High", " + ".join(flags)
    return "Safe", "nothing unusual in the address"


def blocks(risk):
    """The verdict the phone acts on: Critical sites are swallowed as 0.0.0.0."""
    return risk == "Critical"


# --------------------------------------------------------------------------
# Server state (kept in memory, mirrored to state.json)
# --------------------------------------------------------------------------
LOCK = threading.Lock()
STATE = {
    "devices": {},   # device_id -> {tag, ip, last_seen, fingerprint, packages, counts}
    "dashboard_owner": "",   # account that signed in last, survives a restart
    "apks": {},      # "device|package" -> the latest scan of that app on that phone
    "recent": collections.deque(maxlen=400),   # newest site/event rows first
    "totals": {
        "reports": 0,      # POSTs received from the phone
        "events": 0,       # individual rows ingested
        "sites": 0,        # hostnames graded/seened
        "blocked": 0,      # hostnames swallowed by the phone
        "high": 0,
        "critical": 0,
        "apps_flagged": 0,
        "last_report": None,
    },
}


# Bumped every time the data changes. The dashboard's live stream watches this
# instead of polling, so the page updates the moment a phone reports.
VERSION = 0


def bump():
    global VERSION
    with LOCK:
        VERSION += 1


def load_state():
    """Bring back devices from the last run, so a restart is not a total wipe."""
    try:
        with open(STATE_PATH, "r") as f:
            saved = json.load(f)
    except (OSError, ValueError):
        return
    with LOCK:
        if isinstance(saved.get("dashboard_owner"), str):
            STATE["dashboard_owner"] = saved["dashboard_owner"]
        if isinstance(saved.get("devices"), dict):
            STATE["devices"] = saved["devices"]
        if isinstance(saved.get("apks"), dict):
            STATE["apks"] = saved["apks"]
        if isinstance(saved.get("recent"), list):
            for row in reversed(saved["recent"]):
                STATE["recent"].appendleft(row)
        if isinstance(saved.get("totals"), dict):
            STATE["totals"].update(saved["totals"])


def save_state():
    """Write devices, the last events and the dashboard owner to disk.

    A report is written as soon as it arrives, signed in or not: the row has
    an owner, and that owner is the only account that will be shown it. This
    is what makes a phone stay on its dashboard after a sign-out and after the
    server is stopped and started again.
    """
    with LOCK:
        snapshot = {
            "devices": STATE["devices"],
            "apks": STATE["apks"],
            "recent": list(STATE["recent"])[:200],
            "totals": STATE["totals"],
            "dashboard_owner": STATE.get("dashboard_owner") or "",
        }
    try:
        tmp = STATE_PATH + ".tmp"
        with open(tmp, "w") as f:
            json.dump(snapshot, f, indent=2)
        os.replace(tmp, STATE_PATH)
    except OSError:
        return False
    return True


def now_str():
    return datetime.now().strftime("%d/%m/%Y %H:%M:%S")


# --------------------------------------------------------------------------
# Where can the dashboard be reached from?
# --------------------------------------------------------------------------
def local_ipv4():
    """Every non-loopback IPv4 address on this machine (hostname -I)."""
    found = []
    try:
        out = subprocess.run(["hostname", "-I"], capture_output=True,
                             text=True, timeout=3).stdout
        found = [a for a in out.split() if "." in a and not a.startswith("127.")]
    except (OSError, subprocess.SubprocessError):
        found = []
    if not found:
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            s.connect(("1.1.1.1", 80))
            found = [s.getsockname()[0]]
            s.close()
        except OSError:
            pass
    # Drop link-local leftovers such as 169.254.x.x (that is a sandbox artefact).
    return [a for a in found if not a.startswith("169.254.")]


def public_ip(max_age=300):
    """The router's WAN address. Only useful if you forwarded the port."""
    now = time.time()
    if NET_CACHE["public"] and now - NET_CACHE["at"] < max_age:
        return NET_CACHE["public"]
    for url in ("https://api.ipify.org", "https://ifconfig.me/ip", "https://icanhazip.com"):
        try:
            out = subprocess.run(
                ["curl", "-fsS", "-m", "4", url],
                capture_output=True, text=True, timeout=6).stdout.strip()
            if out and 6 <= len(out) <= 45 and " " not in out:
                NET_CACHE["public"] = out
                NET_CACHE["at"] = now
                return out
        except (OSError, subprocess.SubprocessError):
            continue
    return ""


def read_text(path, limit=4000):
    try:
        with open(path, "r") as f:
            return f.read(limit).strip()
    except OSError:
        return ""


def baked_address():
    """The address start.sh baked into this run's payloads, if it is there.

    start.sh writes it to .run/address. Older kits wrote the same value to
    payloads/server_address.txt, so that path is still read when present.
    The value can be a LAN address, so callers decide what kind it is.
    """
    for path in (os.path.join(os.path.dirname(HERE), ".run", "address"),
                 os.path.join(HERE, ".run", "address"),
                 os.path.join(PAYLOAD_DIR, "server_address.txt")):
        txt = read_text(path, 200)
        if txt.startswith("http"):
            return txt
    return ""


def tunnel_address():
    """Only report the baked address as a tunnel when it really is one."""
    txt = baked_address()
    return txt if ".trycloudflare.com" in txt else ""


def scheme():
    """The scheme a browser uses to reach this listener directly.

    The console speaks plain http on the LAN. The phone's https address comes
    from the Cloudflare tunnel, which terminates TLS at Cloudflare's edge, so
    there is no certificate to manage here.
    """
    return "http"


def net_info():
    """Everything the dashboard shows in its Connect panel."""
    lan = local_ipv4()
    pub = public_ip()
    tun = tunnel_address()
    proto = scheme()
    urls = []
    for ip in lan:
        urls.append({"kind": "LAN", "url": "{}://{}:{}".format(proto, ip, PORT),
                     "note": "works on the same Wi-Fi"})
    if pub:
        urls.append({"kind": "public IP", "url": "{}://{}:{}".format(proto, pub, PORT),
                     "note": "needs port {} open on your router".format(PORT)})
    if tun and "api.trycloudflare" not in tun:
        urls.append({"kind": "tunnel", "url": tun,
                     "note": "works anywhere; new address every run"})
    return {"lan": lan, "public": pub, "tunnel": tun, "port": PORT,
            "urls": urls, "scheme": proto, "tls": False}


def payload_list():
    """The payload files that exist, with their size and purpose."""
    purposes = {
        "payload_tunnel_apk.txt": "fills the app's dashboard-address field with this run's tunnel",
        "payload_android_ducky.txt": "for an unlocked phone - types the install link",
    }
    out = []
    for name in PAYLOAD_FILES:
        path = os.path.join(PAYLOAD_DIR, name)
        try:
            size = os.path.getsize(path)
        except OSError:
            continue
        out.append({"name": name, "size": size,
                    "purpose": purposes.get(name, ""),
                    "url": "/payload/" + name})
    return out


def _download_file(spec):
    """The installer the operator placed for one entry, or None.

    Only regular files inside server/downloads whose name carries the entry's
    token are considered, and a symlink is refused, so this cannot be pointed
    at anything outside that folder.
    """
    try:
        names = sorted(os.listdir(DOWNLOAD_DIR))
    except OSError:
        return None
    best = None
    for name in names:
        low = name.lower()
        if not low.endswith((".exe", ".msi", ".zip")):
            continue
        if not any(tok in low for tok in spec["match"]):
            continue
        path = os.path.join(DOWNLOAD_DIR, name)
        if os.path.islink(path) or not os.path.isfile(path):
            continue
        rank = 0 if low.endswith(".exe") else 1
        if best is None or rank < best[0]:
            best = (rank, path, name)
    return (best[1], best[2]) if best else None


def file_sha256(path, size=0):
    """sha256 of a file, cached on path + mtime + size.

    Hashing a 60 MB installer on every dashboard frame would be wasteful, and
    the cache key means a replaced file is hashed again automatically.
    """
    try:
        mtime = os.path.getmtime(path)
    except OSError:
        return ""
    key = (mtime, size)
    hit = DOWNLOAD_CACHE.get(path)
    if hit and hit[0] == key:
        return hit[1]
    digest = hashlib.sha256()
    try:
        with open(path, "rb") as f:
            for chunk in iter(lambda: f.read(1024 * 1024), b""):
                digest.update(chunk)
    except OSError:
        return ""
    DOWNLOAD_CACHE[path] = (key, digest.hexdigest())
    return digest.hexdigest()


def download_list():
    """The third-party installers this dashboard can hand out.

    present/False means the operator has not put the file on this machine yet.
    A missing file never gets a made-up size or checksum.
    """
    out = []
    for spec in DOWNLOADS:
        if spec.get("kind") == "link":
            # Nothing on disk to look for, so nothing to measure. Emitting the
            # address as its own kind keeps this row out of the checksum path
            # instead of pretending the file is missing.
            out.append({
                "key": spec["key"],
                "label": spec["label"],
                "what": spec["what"],
                "why": spec["why"],
                "vendor": spec["vendor"],
                "site": spec["site"],
                "present": False,
                "link": True,
                "file": "",
                "size": 0,
                "sha256": "",
                "url": "",
                "note": "",
            })
            continue
        found = _download_file(spec)
        row = {
            "key": spec["key"],
            "label": spec["label"],
            "what": spec["what"],
            "why": spec["why"],
            "vendor": spec["vendor"],
            "site": spec["site"],
            "present": False,
            "file": "",
            "size": 0,
            "sha256": "",
            "url": "",
            "note": "add {}*.exe to server/downloads/".format(spec["key"]),
        }
        if found:
            path, name = found
            try:
                size = os.path.getsize(path)
            except OSError:
                size = 0
            digest = file_sha256(path, size)
            row.update({
                "present": True,
                "file": name,
                "size": size,
                "sha256": digest,
                "url": "/download/" + spec["key"],
                "note": "checksum from this file",
            })
        out.append(row)
    return out


def download_path(key):
    """Resolve /download/<key> to a real file path, or None."""
    for spec in DOWNLOADS:
        if spec["key"] != key or spec.get("kind") == "link":
            # A link entry has no file, so /download/github must 404 rather
            # than look for a match token it does not have.
            continue
        found = _download_file(spec)
        return found[0] if found else None
    return None


def clamp(text, n=200):
    return str(text or "")[:n]


def touch_device(did, tag, ip, owner=None):
    """Create or refresh the row for one phone. Returns the row.

    `owner` is the account whose address the report arrived on. A phone that is
    already paired keeps its account: a report arriving on somebody else's
    address never moves it, so one account cannot take over another's phone.
    """
    did = did or "unknown"
    with LOCK:
        dev = STATE["devices"].get(did) or {}
        dev.setdefault("counts", {"sites": 0, "blocked": 0, "high": 0, "critical": 0})
        dev["device_id"] = did
        dev["tag"] = tag or dev.get("tag") or "phone"
        dev["ip"] = ip or dev.get("ip") or "?"
        dev["last_seen"] = now_str()
        dev.setdefault("owner", "")
        wanted = _account_key(owner)
        if wanted and not dev.get("owner"):
            dev["owner"] = wanted
        STATE["devices"][did] = dev
        return dev


def add_site(dev, host, risk, reason, action):
    """Record one hostname the phone resolved, and count it."""
    with LOCK:
        STATE["totals"]["sites"] += 1
        counts = dev["counts"]
        counts["sites"] += 1
        if action == "blocked":
            STATE["totals"]["blocked"] += 1
            counts["blocked"] += 1
        if risk == "High":
            STATE["totals"]["high"] += 1
            counts["high"] += 1
        if risk == "Critical":
            STATE["totals"]["critical"] += 1
            counts["critical"] += 1
        STATE["recent"].appendleft({
            "time": datetime.now().strftime("%H:%M:%S"),
            "tag": dev.get("tag", "phone"),
            "device_id": dev.get("device_id", "unknown"),
            "host": host,
            "risk": risk,
            "reason": reason,
            "advice": ADVICE.get(risk, ""),
            "action": action,
        })


def add_text_event(dev, etype, risk, details):
    """Agent start/stop and similar plain messages."""
    with LOCK:
        STATE["totals"]["events"] += 1
        STATE["recent"].appendleft({
            "time": datetime.now().strftime("%H:%M:%S"),
            "tag": dev.get("tag", "phone"),
            "device_id": dev.get("device_id", "unknown"),
            "host": etype,
            "risk": risk or "Safe",
            "reason": details,
            "action": etype,
        })


# --------------------------------------------------------------------------
# Installed-app scanner
#
# The phone sends one "apk" event for each app that did NOT come from an app
# store, and an "apk_removed" event when something is uninstalled. The dashboard
# keeps the LATEST record per app per device, so a rescan updates a row instead
# of piling up duplicates. Store apps are never sent and never stored: Play,
# Galaxy Store, GetApps, AppGallery and the vendor preload updaters have already
# signed and vetted them, and the phone owner cannot act on them anyway.
# --------------------------------------------------------------------------
def apk_key(did, pkg):
    return "{}|{}".format(did or "unknown", pkg or "")


def visible_apps(rows):
    """The only app rows the dashboard may show: user apps from outside a store.

    One rule, `outside_store`, and it is the same rule ingest uses. The table,
    the phone card and the PDF all read this one list, so they cannot disagree
    about which apps are outside a store or how many there are.
    """
    out = []
    for r in (rows or []):
        ok, _why = outside_store(r)
        if ok:
            out.append(r)
    return out


def add_apk(dev, ev):
    """Store one scanned app reported by the phone."""
    pkg = clamp(ev.get("package") or "", 200)
    if not pkg:
        return
    # Only software that arrived from outside a store is kept, decided by the
    # same function that filters the table. Checking one installer name called
    # every Play Store app a sideload on vivo and Samsung, where the store hands
    # the install to the package installer.
    ok, _why = outside_store(ev)
    if not ok:
        return
    try:
        source = int(ev.get("package_source"))
    except (TypeError, ValueError):
        source = -1
    did = dev.get("device_id") or "unknown"
    # Two answers only. Anything that is not Safe reads as High, so a stale
    # "Critical" from an older build cannot add a third colour to the table.
    risk = "High" if str(ev.get("risk") or "").strip().lower() in (
        "high", "critical") else "Safe"

    row = {
        "device_id": did,
        "tag": dev.get("tag", "phone"),
        "package": pkg,
        "label": clamp(ev.get("label") or pkg, 120),
        "version_name": clamp(ev.get("version_name") or "", 40),
        "version_code": ev.get("version_code") or 0,
        "sha256": clamp(ev.get("sha256") or "", 64),
        "signer": clamp(ev.get("signer") or "", 64),
        "size": ev.get("size") or 0,
        "installer": clamp(ev.get("installer") or "", 120),
        # The whole chain, kept as evidence. installer is who performed the
        # install, initiating is who started it (Play, a browser, adb) and
        # originating is where the file came from. package_source is Android's
        # own answer, and -1 means the phone was too old to give one.
        "initiating": clamp(ev.get("initiating") or "", 120),
        "originating": clamp(ev.get("originating") or "", 120),
        "package_source": source,
        "from_store": bool(ev.get("from_store")),
        "origin": clamp(ev.get("origin") or "", 60),
        "source": clamp(ev.get("source") or "Store", 40),
        "target_sdk": ev.get("target_sdk") or 0,
        "debuggable": bool(ev.get("debuggable")),
        "system": bool(ev.get("system")),
        "sideloaded": bool(ev.get("sideloaded")),
        "accessibility": bool(ev.get("accessibility")),
        "device_admin": bool(ev.get("device_admin")),
        "notif_access": bool(ev.get("notif_access")),
        "score": ev.get("score") or 0,
        "risk": risk,
        "summary": clamp(ev.get("summary") or "", 240),
        "hidden": bool(ev.get("hidden")),
        "inspected": bool(ev.get("inspected")),
        "dex_read": ev.get("dex_read") or 0,
        "packed": bool(ev.get("packed")),
        "evidence": [clamp(x, 160) for x in (ev.get("evidence") or [])][:10],
        "reason": clamp(ev.get("reason"), 300),
        "advice": clamp(ev.get("advice") or APP_ADVICE.get(risk, ""), 400),
        "permissions": [clamp(x, 60) for x in (ev.get("permissions") or [])][:12],
        "seen": now_str(),
    }
    with LOCK:
        STATE["apks"][apk_key(did, pkg)] = row
        if len(STATE["apks"]) > 4000:
            keep = sorted(STATE["apks"].items(),
                          key=lambda kv: str(kv[1].get("seen") or ""))[-3000:]
            STATE["apks"] = dict(keep)
        STATE["totals"]["apps_flagged"] = sum(
            1 for x in STATE["apks"].values() if x.get("risk") != "Safe")
        STATE["recent"].appendleft({
            "time": datetime.now().strftime("%H:%M:%S"),
            "tag": dev.get("tag", "phone"),
            "device_id": did,
            "host": row["label"] + "  [" + pkg + "]",
            "risk": risk,
            "reason": row["reason"],
            "advice": row["advice"],
            "action": "app",
        })


def add_scan(dev, ev):
    """One phone's app scan: how many outside-store apps, and how many are High.

    The scan used to arrive as four verdict buckets. It now answers the same two
    levels as the table, so a phone card and an app row can never disagree.
    """
    def num(*keys):
        """The first key the phone actually sent, as a count."""
        for key in keys:
            val = ev.get(key)
            if val is None:
                continue
            try:
                return max(0, int(val))
            except (TypeError, ValueError):
                return 0
        return 0

    summary = {
        "safe": num("safe", "secure"),
        "high": num("high", "unsafe"),
        "outside": num("outside", "sideload"),
        "store": num("store"),
        "checked": num("checked", "deep"),
        "at": now_str(),
        "details": clamp(ev.get("details"), 200),
    }
    with LOCK:
        dev["scan"] = summary
    add_text_event(dev, "scan", ev.get("risk") or "Safe",
                   summary["details"] or "app scan finished")


def remove_apk(dev, ev):
    """An uninstalled app should not linger looking like an active threat."""
    pkg = clamp(ev.get("package") or "", 200)
    did = dev.get("device_id") or "unknown"
    with LOCK:
        gone = STATE["apks"].pop(apk_key(did, pkg), None)
        STATE["totals"]["apps_flagged"] = sum(
            1 for x in STATE["apks"].values() if x.get("risk") != "Safe")
    if gone:
        with LOCK:
            STATE["recent"].appendleft({
                "time": datetime.now().strftime("%H:%M:%S"),
                "tag": dev.get("tag", "phone"),
                "device_id": did,
                "host": pkg,
                "risk": "Safe",
                "reason": "uninstalled - removed from the app list",
                "advice": "",
                "action": "app_removed",
            })


def apk_list(rows=None, limit=300):
    """Worst first, so the thing to deal with is at the top.

    `rows` is what one account is allowed to see. Without it the whole table is
    used, which only the phone reply and the older callers do.
    """
    order = {"High": 0, "Safe": 1}
    if rows is None:
        with LOCK:
            rows = [dict(r) for r in STATE["apks"].values()]
    rows = visible_apps(rows)
    rows.sort(key=lambda r: (order.get(r.get("risk"), 3),
                             -(r.get("score") or 0),
                             str(r.get("label") or "").lower()))
    return rows[:limit]


def apk_totals(rows=None):
    """The two numbers behind the app table: how many, and how many are High."""
    if rows is None:
        with LOCK:
            rows = list(STATE["apks"].values())
    rows = visible_apps(rows)
    high = sum(1 for r in rows if r.get("risk") == "High")
    return {
        "tracked": len(rows),
        "high": high,
        "safe": len(rows) - high,
        "accessibility": sum(1 for r in rows if r.get("accessibility")),
        "hidden": sum(1 for r in rows if r.get("hidden")),
        "packed": sum(1 for r in rows if r.get("packed")),
    }


# --------------------------------------------------------------------------
# Whose phone is it
#
# Every phone row carries an "owner": the account key that paired it. Every
# read below filters on that key, so two people signed in to the same server -
# or sitting on the same Wi-Fi - see their own phones, their own apps and their
# own log, and nothing else.
#
# A phone is paired in one of two ways:
#   * it reports to /u/<token>, the private address of one account (the normal
#     case: the dashboard shows that address and the install page bakes it in);
#   * or it reports to the bare address and somebody claims it with the device
#     id printed on that phone's screen.
# An unpaired phone is stored but shown to nobody, so nothing leaks while it is
# waiting.
# --------------------------------------------------------------------------
def owner_of(device):
    """The account key on one phone row ("" when nobody has paired it)."""
    return _account_key((device or {}).get("owner"))


def owned_snapshot(user):
    """Devices, log rows and app rows belonging to one account.

    Everything is copied while the lock is held, so the caller works on a
    consistent picture instead of on live dictionaries.
    """
    key = _account_key(user)
    if not key:
        return [], [], []
    with LOCK:
        devices = [dict(d) for d in STATE["devices"].values()
                   if owner_of(d) == key]
        mine = set(str(d.get("device_id") or "") for d in devices)
        rows = [dict(r) for r in STATE["recent"]
                if str(r.get("device_id") or "") in mine]
        apps = [dict(a) for a in STATE["apks"].values()
                if str(a.get("device_id") or "") in mine]
    return devices, rows, apps


def _latest_stamp(devices):
    """The newest last_seen across a set of phone rows."""
    best_text = None
    best_when = None
    for d in devices:
        stamp = str(d.get("last_seen") or "")
        if not stamp:
            continue
        try:
            when = datetime.strptime(stamp, "%d/%m/%Y %H:%M:%S")
        except ValueError:
            when = None
        if when is None:
            if best_text is None or stamp > best_text:
                best_text = stamp
            continue
        if best_when is None or when > best_when:
            best_text, best_when = stamp, when
    return best_text


def _sum_counts(devices, field):
    total = 0
    for d in devices:
        counts = d.get("counts") or {}
        try:
            total += int(counts.get(field) or 0)
        except (TypeError, ValueError):
            continue
    return total


def totals_for(devices, apps):
    """The numbers one account's own dashboard shows.

    They are summed from that account's phones instead of read from a shared
    counter, so one sign-in never sees the size of somebody else's log.
    """
    return {
        "reports": sum(int(d.get("reports") or 0) for d in devices),
        "events": sum(int(d.get("events") or 0) for d in devices),
        "sites": _sum_counts(devices, "sites"),
        "blocked": _sum_counts(devices, "blocked"),
        "high": _sum_counts(devices, "high"),
        "critical": _sum_counts(devices, "critical"),
        "apps_flagged": sum(1 for a in visible_apps(apps)
                            if a.get("risk") == "High"),
        "last_report": _latest_stamp(devices),
    }


def dashboard_totals(user):
    devices, _rows, apps = owned_snapshot(user)
    return totals_for(devices, apps)


def claim_device(did, user):
    """Pair one waiting phone with an account. -> (ok, message)

    The device id is the proof: it is printed on that phone's own screen, so
    only somebody holding the handset can take the row over. A phone that
    already belongs to another account cannot be moved this way.
    """
    key = _account_key(user)
    did = str(did or "").strip()
    if not key:
        return False, "sign in first"
    if not did:
        return False, "the phone id is required"
    with LOCK:
        dev = STATE["devices"].get(did)
        if dev is None:
            return False, "no waiting phone has that id"
        holding = owner_of(dev)
        if holding and holding != key:
            return False, "that phone is already paired with another account"
        dev["owner"] = key
    save_state()
    bump()
    print("[dashboard] phone {} paired with {}".format(did, key), flush=True)
    return True, "phone added to your dashboard"


def adopt_unowned_devices(user=""):
    """Give waiting phones to the dashboard that is being used.

    This covers the two honest cases: a phone that reported before anybody had
    ever signed in, and a server upgraded from a version without owners. Once a
    row has an account it is never moved here, so one account cannot take a
    phone away from another.
    """
    key = _account_key(user) or dashboard_owner()
    if not key:
        return 0
    moved = 0
    with LOCK:
        for dev in STATE["devices"].values():
            if not owner_of(dev):
                dev["owner"] = key
                moved += 1
    if moved:
        save_state()
    if moved:
        print("[state] {} saved phone(s) paired with {}".format(moved, key),
              flush=True)
    return moved


def _recount_locked():
    """Rebuild the shared counters from what is actually stored (lock held)."""
    devices = list(STATE["devices"].values())
    apps = list(STATE["apks"].values())
    STATE["totals"]["reports"] = sum(int(d.get("reports") or 0) for d in devices)
    STATE["totals"]["events"] = sum(int(d.get("events") or 0) for d in devices)
    for field in ("sites", "blocked", "high", "critical"):
        STATE["totals"][field] = _sum_counts(devices, field)
    STATE["totals"]["apps_flagged"] = sum(
        1 for a in apps if a.get("risk") != "Safe")
    STATE["totals"]["last_report"] = _latest_stamp(devices)


def recount_totals():
    with LOCK:
        _recount_locked()


# --------------------------------------------------------------------------
# HTTP handler
# --------------------------------------------------------------------------
# /u/<token> is one account's private phone address. Everything after it is an
# ordinary route (report, grade, the install page, the APK), so a phone only has
# to be given a different base address to land in the right account.
USER_PATH_RE = re.compile(r"^/u/([A-Za-z0-9_-]{6,64})(/.*)?$")

# The Windows script the BadUSB payload runs. __BASE__ and __TAG__ are filled in
# per request, so the phone always gets the address of the tunnel that served it.
INSTALL_PS1 = '''# PhantomShell one-shot installer - served by the dashboard, run by the payload
$ErrorActionPreference = 'SilentlyContinue'
$base = '__BASE__'
$tag  = '__TAG__'
$apk  = Join-Path $env:TEMP 'phantomshell-agent.apk'

Write-Host '[*] PhantomShell: downloading the agent ...'
Invoke-WebRequest -UseBasicParsing "$base/agent.apk" -OutFile $apk

$adb = Get-Command adb -ErrorAction SilentlyContinue
if ($adb -and (Test-Path $apk)) {
    Write-Host '[*] installing on the USB-connected phone (adb) ...'
    & adb install -r $apk
    $deep = "psagent://set?server=$base&tag=$tag&start=1"
    & adb shell am start -a android.intent.action.VIEW -d $deep
    Write-Host '[*] done - unlock the phone and accept the VPN prompt'
} else {
    Write-Host '[!] adb not found - opening the install page in your browser instead'
    Start-Process "$base/agent?tag=$tag"
}
Write-Host "[*] dashboard: $base/"
'''


# ---------------------------------------------------------------------------
# BadUSB payload checker
#
# A BadUSB payload is a text file of HID keystrokes: DELAY, GUI r, STRING ...,
# ENTER. This reads the file and reports what it would do to whichever machine
# it is plugged into. Nothing here executes the payload; it is pattern matching
# over the text, so a verdict is a guide to read, not a guarantee.
# ---------------------------------------------------------------------------
# (severity, points, pattern, label, what it does, what to do about it)
PAYLOAD_RULES = [
    ("critical", 40,
     r"powershell[^\n]*(-enc|-encodedcommand|-e\s+[A-Za-z0-9+/=]{16,})",
     "Hidden PowerShell command",
     "Runs PowerShell from a coded block, so you cannot read what it does.",
     "Decode it first. If you cannot read the result, do not run the file."),

    ("critical", 34,
     r"\b(iex|invoke-expression)\b|\bdownloadstring\b|\bnet\.webclient\b|\binvoke-restmethod\b",
     "Downloads code and runs it",
     "Fetches a script from the internet and runs it, without saving a copy you "
     "can check first.",
     "Only point it at a server you control."),

    ("critical", 36,
     r"(iwr|invoke-webrequest|curl|wget|certutil\s+-urlcache|bitsadmin)[^\n]{0,90}\|\s*(iex|bash|sh|powershell)",
     "Downloads and runs in one step",
     "Runs whatever the download sends back, with no check in between.",
     "Remove it, or use a link you control."),

    ("critical", 36,
     r"\b(mimikatz|secretsdump|procdump[^\n]*lsass|reg\s+save[^\n]*hklm\\(sam|system|security))",
     "Steals passwords",
     "Copies saved passwords or password hashes off the computer.",
     "Only on a test machine you own."),

    ("critical", 34,
     r"\b(nc|ncat|netcat)\b[^\n]*-e\b|/dev/tcp/|bash\s+-i\s*>&|mkfifo[^\n]*\bnc\b",
     "Gives remote control",
     "Opens a command prompt on the computer for whoever is listening.",
     "This is full remote control. Make sure the listener is yours."),

    ("critical", 34,
     r"\b(vssadmin[^\n]*delete[^\n]*shadows|wbadmin[^\n]*delete|bcdedit[^\n]*(recoveryenabled\s+no|bootstatuspolicy)|wevtutil\s+cl|cipher\s+/w)",
     "Deletes backups or logs",
     "Deletes backups and logs, so the computer cannot be restored and the "
     "activity cannot be checked.",
     "Never on a computer you may need to restore."),

    ("critical", 30,
     r"\bformat\s+[a-z]:|\bdiskpart[^\n]*clean|\bdel\s+/[fsq][^\n]*/s|\brm\s+-rf\s+/(\s|$)",
     "Wipes files",
     "Deletes files with no way to undo it.",
     "Only on a computer you can throw away."),

    ("critical", 32,
     r"set-mppreference[^\n]*disable|add-mppreference[^\n]*exclusion|netsh[^\n]*firewall[^\n]*set[^\n]*off",
     "Turns off security",
     "Turns off Defender or the firewall, so other things can get in unseen.",
     "Only on a lab machine you can rebuild."),

    ("high", 26,
     r"reg\s+add[^\n]*currentversion\\+run|schtasks[^\n]*/create|new-scheduledtask|\\startup\\+",
     "Comes back after a reboot",
     "Adds itself to startup, so it runs again after the computer restarts.",
     "Remove the startup entry when you finish."),

    ("high", 24,
     r"\bnet\s+(user|localgroup)[^\n]*(/add|\+\s*/add)",
     "Adds a login",
     "Leaves a user account behind after the test.",
     "Delete the account when you finish."),

    ("high", 22,
     r"\b(fodhelper|eventvwr|computerdefaults|sdclt)\b[^\n]*shell|runas[^\n]*/savecred",
     "Gets admin without asking",
     "Raises itself to administrator without a prompt.",
     "Only where admin testing is in scope."),

    ("high", 20,
     r"\bcmd(\.exe)?\s*/c\b|start-process[^\n]*-windowstyle\s+hidden|-w(indowstyle)?\s+hidden|-nop\b|-noprofile\b",
     "Hides its window",
     "Hides the window, so nobody at the keyboard sees anything happen.",
     "Check the logs, not the screen."),

    ("high", 18,
     r"frombase64string|[A-Za-z0-9+/]{120,}={0,2}",
     "Coded or hidden text",
     "Part of the file is coded, so you cannot read what it does.",
     "Decode it first. If you cannot explain the result, do not run it."),

    ("high", 16,
     # A bare /sdcard/ is not suspicious: it is where every APK download lands,
     # and an install path there is normal. Only treat it as data access when
     # the line actually reads or copies something out of shared storage.
     r"content://(sms|contacts|call_log)|(cat|cp|pull|tar|zip|base64|copy)\b[^\n]{0,48}/sdcard/|whatsapp[^\n]*databases|\bsms\b[^\n]*\.db",
     "Reads messages or app data",
     "Copies messages, contacts or app data off the phone.",
     "Ask the phone owner first, in writing."),

    ("medium", 14,
     r"\bsu\s+-c\b|\badb\s+(root|shell\s+su)\b|\bmagisk\b",
     "Uses root on the phone",
     "Gets around the phone's normal app limits.",
     "Only on a test phone you can wipe."),

    ("medium", 12,
     r"\badb\s+shell\s+(pm\s+(install|uninstall)|am\s+start|input\s+(tap|swipe|text)|settings\s+put|svc\s+)",
     "Controls the phone over USB",
     "Taps, installs and changes settings on the phone by itself.",
     "Fine on your own phone, not on someone else's."),

    ("medium", 12,
     r"^\s*STRING(LN)?[^\n]*\b(powershell|pwsh|cmd\.exe|cmd\s+/[ck])",
     "Types a command",
     "Types a command into the computer, so the shell runs whatever follows.",
     "Read the rest of that line first."),

    ("medium", 10,
     r"\b(pm\s+install|adb\s+install)\b[^\n]*\.apk|install\s+-r\s",
     "Installs an app from outside the store",
     "Installs an app without Play Protect checking it first.",
     "Check what the app is before you run this."),

    ("medium", 10,
     r"\b(reg\s+delete|sc\s+delete|taskkill|stop-process|net\s+stop)\b",
     "Stops or removes something",
     "Can switch off security tools or break normal use of the computer.",
     "Note what it stops so you can start it again."),

    ("low", 8,
     r"attrib\s+\+[hs]",
     "Hides files",
     "Makes files left on the disk harder to find.",
     "Unhide them when you clean up."),

    ("low", 6,
     r"^\s*(GUI|WINDOWS)\s+[rse]\b|^\s*CTRL\s+SHIFT\s+ENTER|^\s*ALT\s+F4|^\s*SHIFT\s+F10",
     "Opens a system window",
     "Opens Run or an admin prompt. Normal for a payload, but that is how the "
     "typing reaches a shell.",
     "Harmless on its own. Read what it types next."),

    ("low", 6,
     r"https?://\d{1,3}(\.\d{1,3}){3}|https?://[a-z0-9.-]+\.(top|xyz|tk|zip|mov|click)\b",
     "Uses a bare IP or throwaway domain",
     "Addresses like this are often set up for one job, then dropped.",
     "Use a server you control."),

    ("info", 3,
     r"https?://[^\s'\"<>]+|\b\d{1,3}(\.\d{1,3}){3}:\d{2,5}\b",
     "Contains a web address",
     "The computer will connect to this address.",
     "Check it is a server you own."),
]

SEVERITY_RANK = {"critical": 0, "high": 1, "medium": 2, "low": 3, "info": 4}


def check_badusb_payload(text):
    """Grade a BadUSB payload file. Returns the verdict, findings and guidance."""
    text = (text or "").replace("\r\n", "\n").replace("\r", "\n")
    lines = text.split("\n")

    findings = []
    seen = set()
    for severity, points, pattern, label, why, fix in PAYLOAD_RULES:
        if label in seen:
            continue
        try:
            match = re.search(pattern, text, re.I | re.M)
        except re.error:
            continue
        if not match:
            continue
        seen.add(label)
        line_no = text.count("\n", 0, match.start()) + 1
        raw = lines[line_no - 1].strip() if line_no - 1 < len(lines) else ""
        if len(raw) > 120:
            raw = raw[:117] + "..."
        findings.append({
            "severity": severity,
            "points": points,
            "label": label,
            "line": line_no,
            "excerpt": raw,
            "why": why,
            "fix": fix,
        })

    findings.sort(key=lambda f: (SEVERITY_RANK.get(f["severity"], 9), f["line"]))
    score = min(100, sum(f["points"] for f in findings))

    if score >= 40:
        verdict = "Dangerous"
        headline = "Do not run this on a real computer."
    elif score >= 15:
        verdict = "Caution"
        headline = "Read every line before you run this."
    else:
        verdict = "Safe"
        headline = "Nothing in this file damages the computer by itself."

    com = [l for l in lines if l.strip() and re.match(r"^\s*(REM\b|#|//)", l, re.I)]
    cmd = [l for l in lines if l.strip() and not re.match(r"^\s*(REM|#|//)", l, re.I)]
    strings = [l for l in lines if re.match(r"^\s*STRING(LN)?\b", l, re.I)]

    low = text.lower()
    windows = bool(re.search(r"powershell|pwsh|\bcmd\b|gui\s+r|win\+r|schtasks|reg\s+add|explorer", low))
    android = bool(re.search(r"\badb\b|\bpm\s+install\b|\bam\s+start\b|\binput\s+(tap|swipe|text)\b|\bsu\s+-c\b|termux", low))
    if windows and android:
        target = "a PC and a phone"
    elif android:
        target = "an Android phone"
    elif windows:
        target = "a Windows PC"
    else:
        target = "not clear"

    strong = [f["label"] for f in findings if f["severity"] in ("critical", "high")][:3]
    if not strong:
        strong = [f["label"] for f in findings if f["severity"] == "medium"][:2]
    if strong:
        summary = "Worst things found: " + "; ".join(s.lower() for s in strong) + "."
    else:
        summary = "No command here does more than type and wait."

    guidance = [headline]
    if verdict == "Dangerous":
        guidance.append(
            "If you must run it, use a throwaway virtual machine: no shared folders, no "
            "shared clipboard and no link to your real network.")
    elif verdict == "Caution":
        guidance.append(
            "Read every typed line and every address. If you cannot say what a line "
            "does, delete it before running the rest.")
    else:
        guidance.append(
            "Low risk, but the stick still types into whatever window is in front.")
    guidance.append(
        "Click the target window before you plug the stick in, or the typing lands "
        "somewhere else.")
    if android:
        guidance.append(
            "This one talks to an Android phone. Turn on USB debugging, approve this "
            "computer on the phone, and unlock the screen first.")
    guidance.append(
        "The check only reads the text. It never runs the file, so treat the result as "
        "a second opinion, not proof.")

    return {
        "verdict": verdict,
        "score": score,
        "summary": summary,
        "target": target,
        "findings": findings,
        "guidance": guidance,
        "stats": {
            "lines": len(cmd) + len(com),
            "commands": len(cmd),
            "strings": len(strings),
            "comments": len(com),
            "bytes": len(text.encode("utf-8", "replace")),
        },
    }


class Handler(BaseHTTPRequestHandler):
    server_version = "PhantomShell/1.0"

    # ---------------------------------------------------------------- helpers
    def log_message(self, fmt, *args):
        print("[http] {} - {}".format(self.address_string(), fmt % args), flush=True)

    def _src(self):
        """Real client address, even behind the Cloudflare tunnel."""
        return (self.headers.get("CF-Connecting-IP")
                or self.headers.get("X-Forwarded-For", "").split(",")[0].strip()
                or self.client_address[0])

    def _base_url(self):
        """The public address of this server as the phone should see it."""
        host = self.headers.get("Host") or "{}:{}".format(BIND, PORT)
        proto = self.headers.get("X-Forwarded-Proto") or scheme()
        return "{}://{}".format(proto, host)

    def _json(self, obj, code=200):
        body = json.dumps(obj).encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.send_header("Access-Control-Allow-Origin", "*")
        self.end_headers()
        self._write(body)

    def _html(self, text, code=200):
        body = text.encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self._write(body)

    def _redirect(self, where, code=302):
        self.send_response(code)
        self.send_header("Location", where)
        self.send_header("Content-Length", "0")
        self.send_header("Cache-Control", "no-store")
        self.end_headers()

    def _text(self, text, code=200):
        body = text.encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", "text/plain; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self._write(body)

    def _write(self, body):
        try:
            self.wfile.write(body)
        except (BrokenPipeError, ConnectionResetError):
            pass

    def _read_json(self):
        try:
            n = int(self.headers.get("Content-Length") or 0)
        except ValueError:
            n = 0
        if n <= 0 or n > 5_000_000:
            return {}
        try:
            return json.loads(self.rfile.read(n).decode("utf-8", "replace"))
        except ValueError:
            return {}

    # ------------------------------------------------------------- sessions
    def _cookie_token(self):
        raw = self.headers.get("Cookie") or ""
        if not raw:
            return ""
        try:
            jar = SimpleCookie()
            jar.load(raw)
        except Exception:
            return ""
        morsel = jar.get(COOKIE)
        return morsel.value if morsel else ""

    def _session_ok(self):
        """True when this browser carries a live console session."""
        token = self._cookie_token()
        if not token:
            return False
        meta = SESSIONS.get(token)
        if not meta:
            return False
        if meta.get("exp", 0) < time.time():
            SESSIONS.pop(token, None)
            # An expired session is a signed-out console: drop what it showed.
            enforce_signed_out()
            return False
        return True

    def _need_login(self):
        """True when this request may see the console."""
        if self._session_ok():
            return True
        # Legacy gate: only active when PS_PASSWORD was set explicitly.
        if PASSWORD:
            header = self.headers.get("Authorization") or ""
            if header.startswith("Basic "):
                try:
                    decoded = base64.b64decode(header[6:]).decode("utf-8", "replace")
                except Exception:
                    return False
                _, _, pw = decoded.partition(":")
                return hmac.compare_digest(pw.encode("utf-8"), PASSWORD.encode("utf-8"))
        return False

    def _ask_login(self):
        """Send a browser to the sign-in page; answer the API with 401 JSON."""
        if urlparse(self.path).path.startswith("/api/"):
            return self._json({"status": "error", "message": "sign in required"}, 401)
        self.send_response(302)
        self.send_header("Location", "/login")
        self.send_header("Content-Length", "0")
        self.send_header("Cache-Control", "no-store")
        self.end_headers()

    def _begin_session(self, user=""):
        """Mint a session token and remember who it belongs to."""
        _prune_sessions()
        token = secrets.token_urlsafe(32)
        SESSIONS[token] = {"exp": time.time() + SESSION_TTL, "user": user}
        return token

    def _session_user(self):
        """Which account this browser is signed in as ("" if none)."""
        token = self._cookie_token()
        if not token:
            return ""
        return str((SESSIONS.get(token) or {}).get("user") or "")

    def _cookie_header(self, token):
        """The session cookie. No Secure flag: this listener is plain http.

        A cookie marked Secure is silently dropped by a browser on an http
        address, which would leave the console unable to sign in at all.
        """
        return "{}={}; Path=/; HttpOnly; SameSite=Lax; Max-Age={}".format(
            COOKIE, token, SESSION_TTL)

    def _handle_login(self, body):
        """POST /api/login - check the account, hand back a session cookie."""
        user = clamp(str(body.get("username") or ""), 64).strip()
        pw = body.get("password")
        if not isinstance(pw, str):
            pw = ""
        ip = self._src()
        now = time.time()

        tries = LOGIN_TRIES.get(ip)
        if tries and now - tries[1] > LOGIN_WINDOW:
            LOGIN_TRIES.pop(ip, None)
            tries = None
        if tries and tries[0] >= LOGIN_MAX_TRIES:
            wait = int(LOGIN_WINDOW - (now - tries[1])) + 1
            print("[login] throttled {} ({} failures)".format(ip, tries[0]), flush=True)
            return self._json({
                "status": "error",
                "message": "Too many attempts. Wait {}s and try again.".format(max(wait, 1)),
            }, 429)

        stored = verify_account(user, pw)
        if not stored:
            LOGIN_TRIES[ip] = [(tries[0] + 1) if tries else 1, tries[1] if tries else now]
            print("[login] rejected sign-in for '{}' from {}".format(user or "-", ip),
                  flush=True)
            return self._json({"status": "error",
                               "message": "Username or password is incorrect."}, 401)

        LOGIN_TRIES.pop(ip, None)
        token = self._begin_session(stored)
        # Signing in brings back the log saved by the previous run, then makes
        # this account the one a phone on the shared address reports to.
        start_local_session()
        remember_dashboard_owner(stored)
        adopt_unowned_devices(stored)
        payload = json.dumps({
            "status": "ok",
            "user": stored,
            "saving": True,
        }).encode("utf-8")
        self.send_response(200)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(payload)))
        self.send_header("Cache-Control", "no-store")
        self.send_header("Set-Cookie", self._cookie_header(token))
        self.end_headers()
        self._write(payload)
        print("[login] {} signed in from {} (this session saves)".format(
            stored, ip), flush=True)

    def _end_session(self):
        """Forget this browser's session. Writes no response of its own."""
        token = self._cookie_token()
        if token:
            SESSIONS.pop(token, None)
        enforce_signed_out()

    def _handle_logout(self, body=None):
        """POST /api/logout - clear the session and answer in JSON."""
        self._end_session()
        return self._json({"status": "ok"})

    def _handle_forgot(self, body):
        """POST /api/forgot - email a six-digit code for a forgotten password."""
        ident = body.get("identifier")
        ident = ident.strip() if isinstance(ident, str) else ""
        ip = self._src()
        now = time.time()

        tries = FORGOT_TRIES.get(ip)
        if tries and now - tries[1] > FORGOT_WINDOW:
            FORGOT_TRIES.pop(ip, None)
            tries = None
        if tries and tries[0] >= FORGOT_MAX:
            wait = int(FORGOT_WINDOW - (now - tries[1])) + 1
            print("[reset] throttled {} ({} asks)".format(ip, tries[0]), flush=True)
            return self._json({
                "status": "error",
                "message": "Too many reset requests from here. Wait {}s."
                           .format(max(wait, 1)),
            }, 429)

        # Honest rather than reassuring: with no mailbox nothing can be sent, and
        # a cheerful "code sent" would leave the person waiting for ever.
        if not MAIL_READY and not OTP_CONSOLE:
            return self._json({
                "status": "error",
                "message": "This server has no email set up, so a code cannot be "
                           "sent. Ask whoever runs it to set PS_SMTP_HOST, "
                           "PS_SMTP_FROM and PS_SMTP_PASS.",
            }, 503)

        def noted():
            FORGOT_TRIES[ip] = [(tries[0] + 1) if tries else 1,
                                tries[1] if tries else now]

        key = account_by_identifier(ident)
        # The same answer either way: saying "no such account" would turn this
        # box into a way to find out who has an account here.
        generic = ("If that account exists, a code is on its way. It works once "
                   "and lasts {} minutes.".format(max(OTP_TTL // 60, 1)))
        if not key:
            noted()
            print("[reset] nothing matches that ({})".format(ip), flush=True)
            return self._json({"status": "ok", "message": generic})

        with ACCOUNT_LOCK:
            row = dict(ACCOUNTS.get(key) or {})
        addr = normalise_email(row.get("email"))
        if not addr:
            noted()
            print("[reset] '{}' has no email on file, nothing sent".format(key),
                  flush=True)
            return self._json({"status": "ok", "message": generic})

        pending = RESET_CODES.get(key)
        if pending and now - float(pending.get("sent") or 0) < OTP_RESEND:
            wait = int(OTP_RESEND - (now - float(pending.get("sent") or 0))) + 1
            return self._json({
                "status": "ok",
                "message": "A code was just sent. Wait {}s before asking again."
                           .format(max(wait, 1)),
            })

        code = issue_reset_code(key)
        sent, why = send_mail(addr, "PhantomShell password reset",
                              reset_mail_body(key, code))
        if OTP_CONSOLE:
            print("[reset] code for '{}' is {} (PS_OTP_CONSOLE)".format(key, code),
                  flush=True)
        if not sent:
            if OTP_CONSOLE:
                # PS_OTP_CONSOLE is the delivery channel on this machine (a
                # lab box with no mailbox). The code was printed above, so it
                # stays valid and the person is not told to wait for mail.
                print("[reset] no mail sent for '{}' ({}); using the console"
                      .format(key, why), flush=True)
            else:
                RESET_CODES.pop(key, None)
                print("[reset] mail for '{}' failed: {}".format(key, why), flush=True)
                return self._json({
                    "status": "error",
                    "message": "The code could not be emailed ({}). Ask whoever "
                               "runs this server to check the mail settings."
                               .format(why),
                }, 502)

        FORGOT_TRIES.pop(ip, None)
        print("[reset] code sent to the address on file for '{}' ({})".format(
            key, ip), flush=True)
        return self._json({"status": "ok", "message": generic})

    def _handle_reset_password(self, body):
        """POST /api/reset-password - swap in a new password using the code."""
        ident = body.get("identifier")
        ident = ident.strip() if isinstance(ident, str) else ""
        code = body.get("code")
        code = code.strip() if isinstance(code, str) else ""
        pw = body.get("password")
        again = body.get("password2")
        pw = pw if isinstance(pw, str) else ""
        again = again if isinstance(again, str) else ""

        key = account_by_identifier(ident)
        if not key:
            return self._json({"status": "error",
                               "message": "That code is not right."}, 400)
        if again and pw != again:
            return self._json({"status": "error",
                               "message": "The two passwords do not match."}, 400)
        if len(pw) < MIN_PASSWORD:
            return self._json({"status": "error",
                               "message": "Password must be at least {} "
                                          "characters.".format(MIN_PASSWORD)}, 400)

        ok, why = check_reset_code(key, code)
        if not ok:
            print("[reset] wrong code for '{}' ({})".format(key, self._src()),
                  flush=True)
            return self._json({"status": "error", "message": why}, 400)
        if not set_account_password(key, pw):
            return self._json({"status": "error",
                               "message": "That account is gone."}, 404)
        closed = drop_sessions_for(key)
        print("[reset] password changed for '{}' ({} session(s) closed)".format(
            key, closed), flush=True)
        return self._json({
            "status": "ok",
            "user": key,
            "message": "Password changed. Sign in with the new one.",
        })

    def _handle_register(self, body):
        """POST /api/register - make an account and sign it straight in."""
        user = clamp(str(body.get("username") or ""), 64).strip()
        pw = body.get("password")
        again = body.get("password2")
        if not isinstance(pw, str):
            pw = ""
        if not isinstance(again, str):
            again = ""
        ip = self._src()
        now = time.time()

        tries = SIGNUP_TRIES.get(ip)
        if tries and now - tries[1] > SIGNUP_WINDOW:
            SIGNUP_TRIES.pop(ip, None)
            tries = None
        if tries and tries[0] >= SIGNUP_MAX:
            wait = int(SIGNUP_WINDOW - (now - tries[1])) + 1
            print("[register] throttled {} ({} attempts)".format(ip, tries[0]), flush=True)
            return self._json({
                "status": "error",
                "message": "Too many sign-ups from here. Wait {}s.".format(max(wait, 1)),
            }, 429)

        if SIGNUP_CODE:
            code = body.get("code")
            if not isinstance(code, str):
                code = ""
            if not hmac.compare_digest(code.encode("utf-8"),
                                      SIGNUP_CODE.encode("utf-8")):
                SIGNUP_TRIES[ip] = [(tries[0] + 1) if tries else 1,
                                    tries[1] if tries else now]
                print("[register] wrong invite code from {}".format(ip), flush=True)
                return self._json({"status": "error",
                                   "message": "That invite code is not correct."}, 403)

        if again and pw != again:
            return self._json({"status": "error",
                               "message": "The two passwords do not match."}, 400)

        mail = body.get("email")
        mail = mail.strip() if isinstance(mail, str) else ""
        if not mail:
            return self._json({
                "status": "error",
                "message": "An email address is needed, so a forgotten password "
                           "can be reset.",
            }, 400)

        ok, message = create_account(user, mail, pw)
        if not ok:
            return self._json({"status": "error", "message": message}, 400)

        stored = verify_account(user, pw)
        if not stored:
            return self._json({"status": "error",
                               "message": "Account created, but sign-in failed. "
                                          "Try signing in."}, 500)
        SIGNUP_TRIES.pop(ip, None)
        token = self._begin_session(stored)
        start_local_session()
        # A brand-new account is now the dashboard a waiting phone belongs to.
        remember_dashboard_owner(stored)
        adopt_unowned_devices(stored)
        print("[register] {} created an account from {}".format(stored, ip), flush=True)
        payload = json.dumps({"status": "ok", "user": stored,
                              "saving": True}).encode("utf-8")
        self.send_response(200)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(payload)))
        self.send_header("Cache-Control", "no-store")
        self.send_header("Set-Cookie", self._cookie_header(token))
        self.end_headers()
        self._write(payload)

    def _handle_delete_account(self, body):
        """POST /api/account/delete - close this account permanently.

        The password is required again on purpose: a stolen or left-open
        browser should not be enough to erase somebody's way in, and there is
        no recovery once the row is gone.
        """
        if not self._session_ok():
            return self._ask_login()
        current = self._session_user()
        pw = body.get("password")
        if not isinstance(pw, str):
            pw = ""
        if not verify_account(current, pw):
            print("[account] delete refused for '{}' (bad password)".format(
                current or "-"), flush=True)
            return self._json({"status": "error",
                               "message": "Password is incorrect."}, 401)
        if not delete_account(current):
            return self._json({"status": "error",
                               "message": "That account is already gone."}, 404)
        # Deleting the account takes its phones and log rows with it: leaving
        # them behind would keep them in state.json forever with no owner.
        wiped = reset_all(current)
        clear_dashboard_owner(current)
        closed = drop_sessions_for(current)
        print("[account] {} deleted their account ({} session(s) closed, "
              "{} phone(s) removed)".format(current, closed, wiped), flush=True)
        payload = json.dumps({
            "status": "ok",
            "message": "Account deleted.",
            "accounts_left": account_count(),
        }).encode("utf-8")
        self.send_response(200)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(payload)))
        self.send_header("Cache-Control", "no-store")
        self.send_header("Set-Cookie",
                         "{}=; Path=/; HttpOnly; SameSite=Lax; Max-Age=0".format(COOKIE))
        self.end_headers()
        self._write(payload)

    def _logout_and_redirect(self):
        """GET /logout - clear the session, then send the browser to /login.

        This must send exactly one response. The earlier version wrote a JSON
        body first and then tried to redirect on the same request, so the
        browser rendered {"status": "ok"} and never left the page. A redirect
        now goes out on its own, with the cookie expired so the dead token
        stops being sent.
        """
        self._end_session()
        self.send_response(302)
        self.send_header("Location", "/login")
        self.send_header("Content-Length", "0")
        self.send_header("Cache-Control", "no-store")
        self.send_header("Set-Cookie",
                         "{}=; Path=/; HttpOnly; SameSite=Lax; Max-Age=0".format(COOKIE))
        self.end_headers()

    # ------------------------------------------------------------------- GET
    def do_GET(self):
        parsed = urlparse(self.path)
        path = parsed.path.rstrip("/") or "/"
        query = parse_qs(parsed.query)

        # Per-account phone address: /u/<token>/... . A phone pointed here has
        # everything it sends filed under one account, so two people on the same
        # server never see each other's handsets.
        deep = USER_PATH_RE.match(path)
        if deep:
            token, rest = deep.group(1), (deep.group(2) or "")
            if not account_for_token(token):
                return self._text("unknown phone address\n", 404)
            if rest in ("", "/", "/agent"):
                return self._serve_agent_page(query, token)
            if rest in ("/agent.apk", "/phantomshell-agent.apk"):
                return self._serve_apk()
            if rest in ("/install.ps1", "/i.ps1"):
                return self._serve_install_ps1(query)
            return self._text("not found\n", 404)

        if path == "/health":
            return self._text("alive")

        # Public: the sign-in card, the crest and the browser tab icon.
        if path in ("/login", "/register", "/signup"):
            if self._session_ok():
                return self._redirect("/dashboard")
            return self._serve_login()
        if path in ("/logo.jpg", "/logo.jpeg", "/favicon.ico"):
            return self._serve_logo()
        # Background media is public: the sign-in page needs it before any login.
        if path in ("/phantomshell.mp4", "/background.mp4"):
            return self._serve_media(VIDEO_PATH, "video/mp4")
        if path in ("/phantomshell-poster.jpg", "/background-poster.jpg"):
            return self._serve_media(POSTER_PATH, "image/jpeg")
        # Bundled fonts. The name is checked against a fixed list, so this cannot
        # be used to read anything else out of the folder.
        if path.startswith("/fonts/"):
            wanted = path[len("/fonts/"):]
            if wanted in FONT_TYPES:
                return self._serve_media(os.path.join(FONT_DIR, wanted), FONT_TYPES[wanted])
            return self._text("no such font\n", 404)
        if path.startswith("/team/"):
            wanted = path[len("/team/"):]
            if wanted in TEAM_TYPES:
                return self._serve_media(os.path.join(TEAM_DIR, wanted), TEAM_TYPES[wanted])
            return self._text("no such image\n", 404)
        if path == "/logout":
            return self._logout_and_redirect()

        # Agent-facing routes never need a login.
        if path in ("/agent.apk", "/phantomshell-agent.apk", "/apk/agent"):
            return self._serve_apk()
        if path == "/agent":
            return self._serve_agent_page(query)
        if path in ("/install.ps1", "/i.ps1"):
            return self._serve_install_ps1(query)
        # Public on purpose, and deliberately small: the phone side needs the
        # address and the APK link, never the phones, the apps or the log.
        if path in ("/api/agent/state", "/api/agent/devices"):
            return self._json(public_state())

        # Live push: the dashboard keeps one of these open and gets a new
        # snapshot the instant something changes.
        if path in ("/api/stream", "/api/live"):
            if not self._need_login():
                return self._ask_login()
            return self._serve_stream()

        # The activity log as a PDF (no third-party libraries needed).
        if path in ("/api/log.pdf", "/log.pdf", "/api/report.pdf"):
            if not self._need_login():
                return self._ask_login()
            return self._serve_pdf()

        # Payload files, so you can download them straight from the dashboard.
        if path.startswith("/payload/"):
            if not self._need_login():
                return self._ask_login()
            return self._serve_payload(path[len("/payload/"):])
        if path in ("/payloads.zip", "/api/payloads.zip"):
            if not self._need_login():
                return self._ask_login()
            return self._serve_payload_zip()

        # Third-party installers: only ever the file this operator placed here.
        if path in ("/download", "/downloads", "/api/downloads"):
            if not self._need_login():
                return self._ask_login()
            return self._json({"downloads": download_list()})
        if path.startswith("/download/"):
            if not self._need_login():
                return self._ask_login()
            return self._serve_download(path[len("/download/"):])

        # Where this dashboard can be reached from.
        if path in ("/api/net", "/api/address"):
            return self._json(net_info())

        # Console routes: the sign-in page guards all of them.
        if path == "/":
            return self._redirect("/dashboard")
        if path in ("/dashboard", "/index.html"):
            if not self._need_login():
                return self._ask_login()
            return self._serve_index()
        if path == "/api/state":
            if not self._need_login():
                return self._ask_login()
            return self._json(build_state(self._session_user()))

        return self._text("not found\n", 404)

    # ------------------------------------------------------------------ POST
    def do_POST(self):
        path = urlparse(self.path).path.rstrip("/") or "/"
        body = self._read_json()

        # The same private address carries the two ingest routes.
        deep = USER_PATH_RE.match(path)
        if deep:
            token, rest = deep.group(1), (deep.group(2) or "/")
            owner_key = account_for_token(token)
            if not owner_key:
                return self._json({"status": "error",
                                   "message": "unknown phone address"}, 404)
            if rest in ("/api/agent/report", "/agent/report",
                        "/report", "/api/report"):
                return self._handle_report(body, owner_key)
            if rest in ("/api/agent/grade", "/agent/grade"):
                return self._handle_grade(body, owner_key)
            return self._json({"status": "error", "message": "not found"}, 404)

        # Sign in / sign out. These are the only POSTs open to the public.
        if path in ("/api/login", "/login"):
            return self._handle_login(body)
        if path in ("/api/logout", "/logout"):
            return self._handle_logout(body)

        # Making an account needs no session; closing one proves itself with the
        # password, so it needs a session but not an administrator.
        if path in ("/api/register", "/register", "/signup"):
            return self._handle_register(body)
        if path in ("/api/account/delete", "/account/delete"):
            if not self._need_login():
                return self._ask_login()
            return self._handle_delete_account(body)
        # A forgotten password needs no session, for the obvious reason.
        if path in ("/api/forgot", "/forgot"):
            return self._handle_forgot(body)
        if path in ("/api/reset-password", "/reset-password"):
            return self._handle_reset_password(body)

        if path in ("/api/agent/grade", "/agent/grade"):
            return self._handle_grade(body)
        if path in ("/api/agent/report", "/agent/report", "/report", "/api/report"):
            return self._handle_report(body)

        # Dashboard controls: forget one phone, or start over completely.
        if path in ("/api/device/delete", "/api/devices/delete"):
            if not self._need_login():
                return self._ask_login()
            return self._handle_delete_device(body)
        if path in ("/api/reset", "/api/devices/reset"):
            if not self._need_login():
                return self._ask_login()
            return self._handle_reset(body)
        # Pair a phone that reported to the shared address with this account.
        if path in ("/api/device/claim", "/api/devices/claim"):
            if not self._need_login():
                return self._ask_login()
            return self._handle_claim(body)
        # Reading a payload file is a dashboard action, so it needs a session.
        if path in ("/api/payload/check", "/api/payload/scan"):
            if not self._need_login():
                return self._ask_login()
            return self._handle_payload_check(body)

        return self._json({"status": "error", "message": "not found"}, 404)

    # -------------------------------------------------------------- handlers
    def _serve_apk(self):
        try:
            with open(APK_PATH, "rb") as f:
                blob = f.read()
        except OSError:
            return self._text(
                "agent APK is not built yet\n"
                "expected at: {}\n"
                "run ./build_apk.sh on the Kali box, or copy the APK there.\n".format(
                    APK_PATH), 404)
        print("[agent] serving agent.apk ({} bytes) to {}".format(
            len(blob), self._src()), flush=True)
        self.send_response(200)
        self.send_header("Content-Type", "application/vnd.android.package-archive")
        self.send_header("Content-Disposition",
                         'attachment; filename="phantomshell-agent.apk"')
        self.send_header("Content-Length", str(len(blob)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self._write(blob)

    def _serve_download(self, key):
        """Hand out an installer the operator put in server/downloads."""
        path = download_path(key)
        if not path:
            return self._text(
                "that installer is not on this machine.\n"
                "put the real file in server/downloads/ and reload the dashboard.\n", 404)
        name = os.path.basename(path)
        try:
            total = os.path.getsize(path)
            fh = open(path, "rb")
        except OSError:
            return self._text("that file cannot be read\n", 404)
        print("[download] {} -> {} ({} bytes)".format(name, self._src(), total),
              flush=True)
        self.send_response(200)
        self.send_header("Content-Type", "application/octet-stream")
        self.send_header("Content-Disposition",
                         'attachment; filename="{}"'.format(name.replace('"', "")))
        self.send_header("Content-Length", str(total))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        try:
            with fh:
                while True:
                    chunk = fh.read(256 * 1024)
                    if not chunk:
                        break
                    self.wfile.write(chunk)
        except (BrokenPipeError, ConnectionResetError, OSError):
            pass

    def _serve_index(self):
        try:
            with open(INDEX_PATH, "r") as f:
                return self._html(f.read())
        except OSError:
            return self._text("index.html is missing next to the server\n", 404)

    def _serve_login(self):
        """The sign-in card.

        Nothing here prints a username or a password: this server ships with no
        account at all. Until somebody makes one, the card says that plainly
        instead of showing a login that would not work.
        """
        try:
            with open(LOGIN_HTML_PATH, "r") as f:
                page = f.read()
        except OSError:
            page = FALLBACK_LOGIN
        if account_count() == 0:
            box = ("<p class=\"creds-note\">No account on this server yet "
                   "&mdash; create the first one above.</p>")
        else:
            box = ""
        page = page.replace("<!--CREDS-->", box)
        # With an invite code set, the card asks for it before anything is sent.
        if SIGNUP_CODE:
            page = page.replace("class=\"sheet\"", "class=\"sheet needcode\"")
        return self._html(page)

    def _serve_logo(self):
        try:
            with open(LOGO_PATH, "rb") as f:
                blob = f.read()
        except OSError:
            return self._text("logo.jpg is missing next to the server\n", 404)
        self.send_response(200)
        self.send_header("Content-Type", "image/jpeg")
        self.send_header("Content-Length", str(len(blob)))
        self.send_header("Cache-Control", "public, max-age=86400")
        self.end_headers()
        self._write(blob)

    def _serve_media(self, path, ctype):
        """Send a media file, honouring HTTP Range.

        Video needs this. Without an Accept-Ranges header and 206 replies the
        browser must fetch the whole file before playback can start, and some
        engines (Safari in particular) will refuse to play at all. Looping and
        seeking also rely on byte ranges, so a loop that only ever receives 200
        responses can stall after the first pass.
        """
        try:
            total = os.path.getsize(path)
            fh = open(path, "rb")
        except OSError:
            return self._text(os.path.basename(path) + " is missing from the server folder\n", 404)

        start, end, partial = 0, total - 1, False
        header = (self.headers.get("Range") or "").strip()
        match = re.match(r"^bytes=(\d*)-(\d*)$", header)
        if match and total > 0:
            first, last = match.group(1), match.group(2)
            if first:
                start = int(first)
                if last:
                    end = min(int(last), total - 1)
            elif last:
                start = max(0, total - int(last))      # suffix range: last N bytes
            if start > end or start >= total:
                fh.close()
                self.send_response(416)
                self.send_header("Content-Range", "bytes */{}".format(total))
                self.send_header("Content-Length", "0")
                self.end_headers()
                return
            partial = True

        length = end - start + 1
        self.send_response(206 if partial else 200)
        self.send_header("Content-Type", ctype)
        self.send_header("Accept-Ranges", "bytes")
        self.send_header("Content-Length", str(length))
        if partial:
            self.send_header("Content-Range", "bytes {}-{}/{}".format(start, end, total))
        self.send_header("Cache-Control", "public, max-age=86400")
        self.end_headers()

        try:
            fh.seek(start)
            left = length
            while left > 0:
                chunk = fh.read(min(65536, left))
                if not chunk:
                    break
                self.wfile.write(chunk)
                left -= len(chunk)
        except (BrokenPipeError, ConnectionResetError):
            pass            # the browser seeked or navigated away; that is not an error
        finally:
            fh.close()

    def _serve_agent_page(self, query, token=""):
        """The page the phone's browser opens: download link + setup steps.

        With a token the page points the phone at /u/<token>, so the handset
        reports into that one account and nowhere else.
        """
        origin = self._base_url()
        base = origin + ("/u/" + token if token else "")
        tag = re.sub(r"[^A-Za-z0-9._-]", "_",
                     (query.get("tag", ["phone"])[0] or "phone"))[:40] or "phone"
        try:
            apk_size = os.path.getsize(APK_PATH)
        except OSError:
            apk_size = 0
        deep = "psagent://set?server={}&tag={}&start=1".format(base, tag)
        print("[agent] install page opened from {} (base={})".format(self._src(), base),
              flush=True)
        page = read_agent_page()
        page = (page.replace("__BASE__", base)
                    .replace("__TAG__", tag)
                    .replace("__APK__", origin + "/agent.apk")
                    .replace("__DEEP__", deep)
                    .replace("__SIZE__", "{:.0f} KB".format(apk_size / 1024.0)
                             if apk_size else "not built yet"))
        return self._html(page)

    def _serve_install_ps1(self, query):
        """One-shot Windows installer, run by the BadUSB payload.

        It downloads the APK, installs it over USB with adb when adb is present
        (and then opens the agent already pointed at this server), and falls back
        to opening the normal install page in the browser when it is not.
        """
        base = self._base_url()
        tag = re.sub(r"[^A-Za-z0-9._-]", "_",
                     (query.get("tag", ["phone"])[0] or "phone"))[:40] or "phone"
        script = INSTALL_PS1.replace("__BASE__", base).replace("__TAG__", tag)
        body = script.encode("utf-8")
        self.send_response(200)
        self.send_header("Content-Type", "text/plain; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self._write(body)

    def _handle_grade(self, body, owner=""):
        """One hostname from the phone -> one verdict."""
        host = clamp(body.get("host") or "", 253)
        if not host:
            return self._json({"status": "error", "message": "host required"}, 400)
        risk, reason = grade(host)
        did = clamp(body.get("device_id") or "", 80)
        tag = clamp(body.get("tag") or "phone", 40)
        verdict = {
            "status": "ok",
            "host": clean_host(host),
            "risk": risk,
            "reason": reason,
            "advice": ADVICE[risk],
            "block": blocks(risk),
        }
        # Risky names are logged immediately so the dashboard shows them even if
        # the phone's batch never arrives.
        if risk != "Safe":
            dev = touch_device(did, tag, self._src(),
                               _account_key(owner) or dashboard_owner())
            add_site(dev, verdict["host"], risk, reason,
                     "blocked" if verdict["block"] else "seen")
            save_state()
            bump()
        return self._json(verdict)

    def _handle_report(self, body, owner=""):
        """A batch of everything the phone knows: fingerprint, apps, sites.

        `owner` is the account whose private address the report arrived on. A
        report on the bare address belongs to the account that used the
        dashboard last, so a scan that finishes while the console is closed
        still lands on the right dashboard. A row that already has an account
        keeps it, which is what stops another sign-in on the same network from
        seeing this phone.
        """
        tag = clamp(body.get("tag") or "phone", 40)
        did = clamp(body.get("device_id") or "unknown", 80)
        owner_key = _account_key(owner) or dashboard_owner()
        fingerprint = body.get("fingerprint") if isinstance(body.get("fingerprint"), dict) else {}
        packages = body.get("packages") if isinstance(body.get("packages"), dict) else {}
        events = body.get("events") if isinstance(body.get("events"), list) else []

        dev = touch_device(did, tag, self._src(), owner_key)
        if fingerprint:
            dev["fingerprint"] = fingerprint
        if packages:
            dev["packages"] = packages

        with LOCK:
            STATE["totals"]["reports"] += 1
            STATE["totals"]["last_report"] = now_str()
            # Per-phone counters: each dashboard number is summed from the
            # phones one account owns, never from a shared total.
            dev["reports"] = int(dev.get("reports") or 0) + 1
            dev["events"] = int(dev.get("events") or 0) + len(events)

        # A scan summary means the phone just enumerated every app it has, so
        # this batch is the full picture for that device and anything it does
        # not list is gone.
        full_scan = any(isinstance(e, dict) and
                        str(e.get("type") or "").lower() == "scan"
                        for e in events)
        reported = set()
        for e in events:
            if isinstance(e, dict) and str(e.get("type") or "").lower() == "apk":
                name = clamp(e.get("package") or "", 200)
                if name:
                    reported.add(name)

        for ev in events:
            if not isinstance(ev, dict):
                continue
            etype = clamp(ev.get("type") or "event", 20).lower()
            risk = ev.get("risk") or "Safe"
            if risk not in ADVICE:
                risk = "Safe"
            if etype == "site":
                host = clean_host(ev.get("host"))
                if host:
                    add_site(dev, host, risk, clamp(ev.get("reason"), 200),
                             clamp(ev.get("action") or "seen", 20))
            elif etype == "scan":
                add_scan(dev, ev)
            elif etype == "apk":
                add_apk(dev, ev)
            elif etype == "apk_removed":
                remove_apk(dev, ev)
            else:
                add_text_event(dev, etype, risk, clamp(ev.get("details"), 200))
        if full_scan:
            purge_device_apps(dev.get("device_id") or "unknown", reported)
            refresh_scan_note(dev)

        with LOCK:
            STATE["totals"]["events"] += len(events)

        # The reply says plainly whether this batch reached the file. It now
        # does so regardless of who is signed in, because the row already
        # belongs to an account.
        stored = save_state()
        bump()
        print("[agent] report from {} tag={} events={} stored={}".format(
            self._src(), tag, len(events), stored), flush=True)
        paired = bool(owner_of(dev))
        if not stored:
            note = "the batch could not be written to state.json"
        elif paired:
            note = "saved to state.json"
        else:
            note = ("saved, but no account has signed in yet - sign in once "
                    "and this phone will appear on that dashboard")
        return self._json({
            "status": "ok",
            "device_id": did,
            "received": len(events),
            "stored": stored,
            "paired": paired,
            "message": note,
            "totals": dashboard_totals(owner_key),
        })

    # -------------------------------------------------- live stream (SSE)
    def _serve_stream(self):
        """Server-Sent Events: push a fresh snapshot the moment data changes."""
        self.send_response(200)
        self.send_header("Content-Type", "text/event-stream; charset=utf-8")
        self.send_header("Cache-Control", "no-cache, no-store")
        self.send_header("Connection", "keep-alive")
        self.send_header("X-Accel-Buffering", "no")
        self.send_header("Access-Control-Allow-Origin", "*")
        self.end_headers()
        seen = -1
        idle = 0
        try:
            while True:
                v = VERSION
                if v != seen:
                    seen = v
                    idle = 0
                    line = "data: " + json.dumps(build_state(self._session_user())) + "\n\n"
                    self.wfile.write(line.encode("utf-8"))
                else:
                    idle += 1
                    if idle % 15 == 0:
                        self.wfile.write(b": keepalive\n\n")
                self.wfile.flush()
                if idle >= 1800:      # 30 min of silence -> let the client reconnect
                    break
                time.sleep(1)
        except (BrokenPipeError, ConnectionResetError, OSError):
            pass

    # ------------------------------------------------------ log as PDF
    def _serve_pdf(self):
        blob = build_pdf_report(self._session_user())
        self.send_response(200)
        self.send_header("Content-Type", "application/pdf")
        self.send_header("Content-Disposition",
                         'attachment; filename="phantomshell-log.pdf"')
        self.send_header("Content-Length", str(len(blob)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self._write(blob)

    # ------------------------------------------- forget one phone / reset
    def _serve_payload(self, name):
        """One payload .txt file, served as a download."""
        name = os.path.basename(name or "")
        if name not in PAYLOAD_FILES:
            return self._text("no such payload\n", 404)
        path = os.path.join(PAYLOAD_DIR, name)
        try:
            with open(path, "rb") as f:
                blob = f.read()
        except OSError:
            return self._text(
                "the payload files have not been written yet\n"
                "run ./start.sh once - it creates them in {}\n".format(PAYLOAD_DIR), 404)
        self.send_response(200)
        self.send_header("Content-Type", "text/plain; charset=utf-8")
        self.send_header("Content-Disposition",
                         'attachment; filename="{}"'.format(name))
        self.send_header("Content-Length", str(len(blob)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self._write(blob)

    def _serve_payload_zip(self):
        """All the payload files in one zip."""
        buf = io.BytesIO()
        added = 0
        with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as z:
            for name in PAYLOAD_FILES:
                path = os.path.join(PAYLOAD_DIR, name)
                if os.path.isfile(path):
                    z.write(path, arcname=name)
                    added += 1
        if not added:
            return self._text("no payload files yet - run ./start.sh\n", 404)
        blob = buf.getvalue()
        self.send_response(200)
        self.send_header("Content-Type", "application/zip")
        self.send_header("Content-Disposition",
                         'attachment; filename="phantomshell-payloads.zip"')
        self.send_header("Content-Length", str(len(blob)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self._write(blob)

    def _handle_delete_device(self, body):
        did = clamp(body.get("device_id") or "", 100)
        ok = delete_device(did, self._session_user())
        return self._json({
            "status": "ok" if ok else "error",
            "removed": did if ok else None,
            "message": "phone removed" if ok else "phone not found",
            "state": build_state(self._session_user()),
        })

    def _handle_reset(self, body):
        gone = reset_all(self._session_user())
        return self._json({
            "status": "ok",
            "message": "your phones and your log were cleared",
            "removed": gone,
            "state": build_state(self._session_user()),
        })

    def _handle_claim(self, body):
        """POST /api/device/claim - pair one waiting phone with this account."""
        if not self._session_ok():
            return self._ask_login()
        did = clamp(body.get("device_id") or "", 100)
        ok, note = claim_device(did, self._session_user())
        return self._json({
            "status": "ok" if ok else "error",
            "message": note,
            "state": build_state(self._session_user()),
        }, 200 if ok else 400)

    def _handle_payload_check(self, body):
        """POST /api/payload/check - grade a BadUSB payload and explain it."""
        text = body.get("text") if isinstance(body, dict) else ""
        if not isinstance(text, str):
            text = ""
        if not text.strip():
            return self._json(
                {"status": "error",
                 "message": "paste a payload or load a .txt first"}, 400)
        if len(text) > 200000:
            return self._json(
                {"status": "error",
                 "message": "that file is too big to check (200 KB limit)"}, 413)
        result = check_badusb_payload(text)
        result["status"] = "ok"
        return self._json(result)


# --------------------------------------------------------------------------
# Dashboard controls: delete one phone, or wipe everything and start over
# --------------------------------------------------------------------------
def delete_device(did, owner=""):
    """Forget one phone and every log row that belongs to it.

    Only the account that owns the phone may remove it. Anybody else gets the
    same answer as for a phone that does not exist, so the reply never confirms
    what another account has.
    """
    key = _account_key(owner)
    with LOCK:
        dev = STATE["devices"].get(did or "")
        if not did or dev is None or owner_of(dev) != key:
            return False
        STATE["devices"].pop(did, None)
        for k in [k for k in STATE["apks"] if k.startswith(str(did) + "|")]:
            STATE["apks"].pop(k, None)
        keep = [r for r in STATE["recent"] if r.get("device_id") != did]
        STATE["recent"].clear()
        for row in keep:
            STATE["recent"].append(row)
        _recount_locked()
    save_state()
    bump()
    print("[dashboard] {} removed phone {}".format(key or "?", did), flush=True)
    return True


def reset_all(owner=""):
    """Erase one account's phones and log rows, and nothing else.

    This used to empty the whole file, which on a shared server meant one person
    could delete another person's phones. It now touches only the caller's rows
    and returns how many phones went away.
    """
    key = _account_key(owner)
    if not key:
        return 0
    with LOCK:
        mine = [did for did, d in STATE["devices"].items() if owner_of(d) == key]
        for did in mine:
            STATE["devices"].pop(did, None)
            for k in [k for k in STATE["apks"] if k.startswith(str(did) + "|")]:
                STATE["apks"].pop(k, None)
        if mine:
            gone = set(mine)
            keep = [r for r in STATE["recent"]
                    if str(r.get("device_id") or "") not in gone]
            STATE["recent"].clear()
            for row in keep:
                STATE["recent"].append(row)
        _recount_locked()
        left = len(STATE["devices"])
    save_state()
    bump()
    print("[dashboard] {} erased their own data ({} phone(s) removed, "
          "{} phone(s) still on the server)".format(key, len(mine), left),
          flush=True)
    return len(mine)


# --------------------------------------------------------------------------
# Minimal PDF writer (built by hand, so no extra pip packages are needed)
# --------------------------------------------------------------------------
PDF_W = 595          # A4 in points
PDF_H = 842
PDF_MARGIN = 40
# Who signs off the exported report. Change these two lines to put a different
# name on it; nothing else in the file reads them. Kept as plain ASCII because
# the PDF writer encodes text as WinAnsi.
APPROVER_NAME = "Uwais Azzaidani Bin Mohd Norazhar"
APPROVER_TITLE = "Leader, PhantomShell Project"

# Ink and rule colours. The dashboard is dark; a report is read on paper, so it
# carries a navy masthead and dark text on white instead of the dark theme.
# The masthead sits behind the logo, whose own background is pure black, so the
# band is a near-black navy: it reads as a deep header and the logo's square
# edges fall away into it instead of showing as a lighter grey box.
PDF_NAVY = (0.013, 0.039, 0.070)
PDF_WHITE = (1.000, 1.000, 1.000)
PDF_SOFT = (0.600, 0.730, 0.880)
PDF_ACCENT = (0.180, 0.420, 0.800)
PDF_INK = (0.100, 0.120, 0.160)
PDF_MUTED = (0.420, 0.460, 0.520)
PDF_FAINT = (0.630, 0.670, 0.720)
PDF_RULE = (0.840, 0.870, 0.910)
PDF_TINT = (0.958, 0.972, 0.984)
PDF_WARN = (0.700, 0.440, 0.030)
RISK_INK = {"High": (0.760, 0.360, 0.020), "Safe": (0.110, 0.460, 0.250)}

# A report is a summary, not a second copy of the database. It stops at these
# counts so a phone with a thousand apps or a month of events still prints as a
# short document; the dashboard keeps the full list.
PDF_MAX_APPS = 60
PDF_MAX_LOG = 60


def _pdf_escape(text):
    """WinAnsi-safe string with the three characters a PDF string cares about."""
    safe = str(text if text is not None else "").encode("latin-1", "replace")
    safe = safe.decode("latin-1")
    return safe.replace("\\", r"\\").replace("(", r"\(").replace(")", r"\)")


def _pdf_width(text, size, bold=False):
    """Approximate Helvetica advance in points, for alignment and truncation."""
    return len(str(text if text is not None else "")) * size * (0.52 if bold else 0.50)


def _pdf_fit(text, size, width, bold=False):
    """Shorten text with an ellipsis until it fits inside width points."""
    text = str(text if text is not None else "")
    if _pdf_width(text, size, bold) <= width:
        return text
    lo, hi = 0, len(text)
    while lo < hi:
        mid = (lo + hi + 1) // 2
        if _pdf_width(text[:mid] + "...", size, bold) <= width:
            lo = mid
        else:
            hi = mid - 1
    return text[:lo] + "..." if lo else "..."


def _pdf_wrap_at(text, size, width):
    """Greedy word wrap measured in points rather than characters."""
    text = str(text if text is not None else "").strip()
    if not text:
        return [""]
    per_line = max(6, int(width / (size * 0.50)))
    lines, line = [], ""
    for word in text.split():
        while len(word) > per_line:
            if line:
                lines.append(line)
                line = ""
            lines.append(word[:per_line])
            word = word[per_line:]
        trial = (line + " " + word).strip() if line else word
        if len(trial) > per_line:
            lines.append(line)
            line = word
        else:
            line = trial
    if line or not lines:
        lines.append(line)
    return lines


def _short_stamp(value):
    """Drop the seconds from a stored timestamp so a summary line stays short."""
    text = str(value or "").strip()
    return text[:16] if len(text) >= 16 else (text or "-")


def _jpeg_size(data):
    """(width, height) from a JPEG's SOF marker, or None if it is not one.

    Reading two numbers out of the header is all it takes to place the image:
    a JPEG goes into a PDF as-is under /DCTDecode, so the server never has to
    decode, resample or re-encode it, and no imaging library is involved.
    """
    if not data or len(data) < 4 or data[0] != 0xFF or data[1] != 0xD8:
        return None
    i, n = 2, len(data)
    while i < n - 9:
        if data[i] != 0xFF:
            i += 1
            continue
        marker = data[i + 1]
        if marker in (0xD8, 0xD9) or 0xD0 <= marker <= 0xD7:
            i += 2
            continue
        seg_len = (data[i + 2] << 8) | data[i + 3]
        if marker in (0xC0, 0xC1, 0xC2, 0xC3, 0xC5, 0xC6, 0xC7,
                      0xC9, 0xCA, 0xCB, 0xCD, 0xCE, 0xCF):
            height = (data[i + 5] << 8) | data[i + 6]
            width = (data[i + 7] << 8) | data[i + 8]
            if width > 0 and height > 0:
                return width, height
            return None
        i += 2 + seg_len
    return None


def _logo_stream():
    """The logo file as (bytes, width, height), or None when it is not there.

    Missing artwork must not break the report: without it the masthead simply
    prints its text, which is what every page did before the logo shipped.
    """
    try:
        with open(LOGO_PATH, "rb") as f:
            data = f.read()
    except OSError:
        return None
    size = _jpeg_size(data)
    return (data, size[0], size[1]) if size else None


def _pdf_masthead(ops, stamp, account):
    """The band that opens page one: the mark, the title, the stamp."""
    _chart_rect(ops, 0, PDF_H - 104, PDF_W, 104, PDF_NAVY)
    _chart_rect(ops, 0, PDF_H - 104, 5, 104, PDF_ACCENT)
    _chart_rect(ops, PDF_MARGIN - 4, PDF_H - 104, PDF_W - 2 * PDF_MARGIN + 8,
                0.7, (0.100, 0.220, 0.380))

    # The artwork carries the name, so it replaces the old text wordmark rather
    # than sitting next to a duplicate of itself.
    logo = _logo_stream()
    tx = PDF_MARGIN
    if logo:
        _data, lw, lh = logo
        draw_h = 78.0
        draw_w = draw_h * (float(lw) / float(lh))
        _chart_image(ops, PDF_MARGIN, PDF_H - 97, draw_w, draw_h)
        tx = PDF_MARGIN + draw_w + 20.0

    _chart_text(ops, tx, PDF_H - 61, "Mobile threat assessment", 18, True,
                PDF_WHITE)
    _chart_text(ops, tx, PDF_H - 77, "PhantomShell - installed app report", 9,
                False, PDF_SOFT)

    label = "generated " + stamp
    _chart_text(ops, PDF_W - PDF_MARGIN - _pdf_width(label, 8), PDF_H - 33,
                label, 8, False, PDF_SOFT)
    if account:
        who = "account " + account
        _chart_text(ops, PDF_W - PDF_MARGIN - _pdf_width(who, 8), PDF_H - 51,
                    who, 8, False, PDF_SOFT)


def _pdf_slim_header(section):
    """The small running head that every page after the first carries."""
    ops = []
    _chart_text(ops, PDF_MARGIN, PDF_H - 40, "PHANTOMSHELL", 8, True, PDF_ACCENT)
    _chart_text(ops, PDF_MARGIN + 63, PDF_H - 40, "|   " + section, 8, False,
                PDF_MUTED)
    _chart_line(ops, PDF_MARGIN, PDF_H - 50, PDF_W - PDF_MARGIN, PDF_H - 50,
                PDF_RULE, 0.6)
    return "\n".join(ops)


def _pdf_footer(page_no, page_total):
    """Page number and a quiet line of provenance at the foot of every page."""
    ops = []
    _chart_line(ops, PDF_MARGIN, PDF_MARGIN - 14, PDF_W - PDF_MARGIN,
                PDF_MARGIN - 14, PDF_RULE, 0.6)
    _chart_text(ops, PDF_MARGIN, PDF_MARGIN - 26,
                "PhantomShell - mobile threat assessment", 7, False, PDF_FAINT)
    label = "page {} of {}".format(page_no, page_total)
    _chart_text(ops, PDF_W - PDF_MARGIN - _pdf_width(label, 7),
                PDF_MARGIN - 26, label, 7, False, PDF_FAINT)
    return "\n".join(ops)


class _PdfFlow:
    """A top-down cursor that starts a new page instead of running off the paper.

    Every block is measured before it is drawn: if it would cross the footer the
    page is closed, a fresh one opens with the running head for the current
    section, and the block is drawn there. That keeps tables from splitting a
    row in half and keeps the running head correct after a break.
    """

    def __init__(self):
        self.pages = []
        self.ops = []
        self.y = PDF_H - PDF_MARGIN
        self.rest_top = PDF_H - 72
        self.heading = "Summary"

    # -- pages -------------------------------------------------------------
    def new_page(self):
        if self.ops:
            self.pages.append("\n".join(self.ops))
        self.ops = []
        self.y = self.rest_top
        self.ops.append(_pdf_slim_header(self.heading))

    def finish(self):
        """Close the page still being drawn. Skipping this drops the log tail."""
        if self.ops:
            self.pages.append("\n".join(self.ops))
            self.ops = []

    def room(self, height):
        if self.y - height < PDF_MARGIN + 22:
            self.new_page()

    def down(self, height):
        self.y -= height

    # -- text --------------------------------------------------------------
    def text(self, value, size=9.0, bold=False, rgb=PDF_INK, x=PDF_MARGIN):
        if value:
            _chart_text(self.ops, x, self.y, value, size, bold, rgb)

    def right(self, value, x_right, size=8.0, bold=False, rgb=PDF_FAINT):
        if value:
            text = str(value)
            _chart_text(self.ops, x_right - _pdf_width(text, size, bold),
                        self.y, text, size, bold, rgb)

    def line(self, value, size=9.0, bold=False, rgb=PDF_INK, after=3.0,
             x=PDF_MARGIN):
        if not value:
            return
        self.room(size + after)
        self.down(size)
        self.text(value, size, bold, rgb, x)
        self.down(after)

    def paragraph(self, value, size=8.0, bold=False, rgb=PDF_INK,
                  after=2.0, x=PDF_MARGIN, width=None):
        """Prose wrapped to the text column, one measured line at a time.

        `line` draws a single string and lets a long sentence run straight off
        the right edge, where the page simply stops drawing it. Remediation
        sentences are long enough for that to happen, so every paragraph goes
        through here and ends inside the margin.
        """
        if not value:
            return
        if width is None:
            width = PDF_W - PDF_MARGIN - x
        for part in _pdf_wrap_at(value, size, width - 4):
            self.room(size + 3)
            self.down(size)
            self.text(part, size, bold, rgb, x)
            self.down(3)
        if after:
            self.down(after)

    def rule(self, before=5.0, after=8.0, rgb=PDF_RULE, weight=0.6,
             x0=PDF_MARGIN, x1=PDF_W - PDF_MARGIN):
        self.down(before)
        _chart_line(self.ops, x0, self.y, x1, self.y, rgb, weight)
        self.down(after)

    # -- blocks ------------------------------------------------------------
    def section(self, title):
        """Uppercase label with a hairline under it, and a new running head."""
        self.heading = title
        self.room(48)
        self.down(18)
        self.text(title.upper(), 8.5, True, PDF_ACCENT)
        self.down(5)
        self.rule(0, 9)

    def kpis(self, cells, height=54.0):
        """Between two and four numbers with their labels, in tinted tiles."""
        self.room(height + 12)
        self.down(4)
        gap = 8.0
        width = (PDF_W - 2 * PDF_MARGIN - gap * (len(cells) - 1)) / float(len(cells))
        top = self.y
        for i, (value, label) in enumerate(cells):
            x = PDF_MARGIN + i * (width + gap)
            _chart_rect(self.ops, x, top - height, width, height, PDF_TINT)
            _chart_rect(self.ops, x, top - height, 3.0, height, PDF_ACCENT)
            _chart_text(self.ops, x + 13, top - 30, str(value), 19, True, PDF_INK)
            _chart_text(self.ops, x + 13, top - height + 11, str(label).upper(),
                        7.5, False, PDF_MUTED)
        self.y = top - height - 9

    def phone(self, dev, apps):
        """One compact block per phone: name, platform, coverage, then the rest."""
        fp = dev.get("fingerprint") or {}
        sc = dev.get("scan") or {}
        pk = dev.get("packages") or {}
        tag = str(dev.get("tag") or "phone")
        model = " ".join(str(x) for x in (fp.get("manufacturer"), fp.get("model"))
                         if x) or "model unknown"
        self.room(58)
        self.down(3)
        self.down(11)
        _chart_rect(self.ops, PDF_MARGIN, self.y - 1.5, 3.0, 11.0, PDF_ACCENT)
        _chart_text(self.ops, PDF_MARGIN + 10, self.y,
                    _pdf_fit(tag, 10.5, 250, True), 10.5, True, PDF_INK)
        self.right("last seen " + str(dev.get("last_seen") or "never"),
                   PDF_W - PDF_MARGIN, 8, False, PDF_FAINT)
        self.down(13)

        self.line("{}   |   Android {}   |   patch {}".format(
            model, fp.get("android") or "?", fp.get("security_patch") or "?"),
            8.5, False, PDF_MUTED, after=1.5, x=PDF_MARGIN + 10)
        bits = ["{} {}".format(
            int(dev.get("reports") or 0),
            "report" if int(dev.get("reports") or 0) == 1 else "reports")]
        # The high and outside counts come from the rows below, not from the
        # phone's tally: the phone counts the agent and preloads too, so its
        # number can be larger than the list and the two would disagree.
        high_here = sum(1 for a in apps if a.get("risk") == "High")
        if sc:
            bits.append("last scan {} ({} apps checked, {} outside: {} high, "
                        "{} safe)".format(
                            _short_stamp(sc.get("at")), sc.get("checked", 0),
                            len(apps), high_here, len(apps) - high_here))
        else:
            bits.append("no app scan yet")
        if pk:
            bits.append("{} apps installed, {} user apps".format(
                pk.get("total", 0), pk.get("third_party", 0)))
        self.line("   |   ".join(bits), 8, False, PDF_MUTED, after=1.5,
                  x=PDF_MARGIN + 10)

        # Which apps may install unknown apps. This is the setting a downloaded
        # APK needs before Android will install it, so it explains where the
        # rows below came from - and its absence explains why there are none.
        allowed = pk.get("unknown_sources") or []
        if allowed:
            names = ", ".join(str(a.get("label") or a.get("package") or "?")
                              for a in allowed[:5])
            more = " and {} more".format(len(allowed) - 5) if len(allowed) > 5 else ""
            self.line(_pdf_fit("unknown apps allowed for " + names + more,
                               8, 495), 8, False, PDF_MUTED, after=1.5,
                      x=PDF_MARGIN + 10)
        elif pk:
            self.line("no app on this phone is allowed to install unknown apps",
                      8, False, PDF_MUTED, after=1.5, x=PDF_MARGIN + 10)

        warns = []
        if fp.get("adb_enabled"):
            warns.append("adb enabled")
        if fp.get("debuggable"):
            warns.append("debuggable build")
        if fp.get("root_signals"):
            warns.append("root signs: " + ", ".join(
                str(x) for x in fp["root_signals"][:4]))
        if warns:
            self.line(_pdf_fit("warning: " + ", ".join(warns), 8, 495), 8, False,
                      PDF_WARN, after=1.5, x=PDF_MARGIN + 10)
        self.rule(4, 8, PDF_RULE, 0.5, PDF_MARGIN + 10, PDF_W - PDF_MARGIN)

    APP_COLS = (("RISK", 40.0, 42.0), ("APP", 86.0, 126.0),
                ("PACKAGE", 216.0, 158.0), ("FROM", 378.0, 120.0),
                ("PHONE", 502.0, 53.0))

    def _app_head(self):
        self.room(26)
        self.down(8)
        for title, x, _w in self.APP_COLS:
            _chart_text(self.ops, x, self.y, title, 7, True, PDF_MUTED)
        self.down(5)
        _chart_line(self.ops, PDF_MARGIN, self.y, PDF_W - PDF_MARGIN, self.y,
                    PDF_RULE, 0.6)
        self.down(11)

    def app_table(self, rows):
        """One line per app that came from outside a store."""
        if not rows:
            self.line("No app from outside a store has been found.", 9, False,
                      PDF_MUTED)
            return
        self._app_head()
        shown = rows[:PDF_MAX_APPS]
        for i, app in enumerate(shown):
            risk = str(app.get("risk") or "Safe").capitalize()
            label = str(app.get("label") or app.get("package") or "?")
            version = str(app.get("version_name") or "").strip()
            if version:
                label = label + " " + version

            # The advice the dashboard shows in its Remediation column, on the
            # same row as the app it is about. It is wrapped rather than cut so
            # the instruction stays usable, and capped at two lines so one long
            # paragraph cannot push the rest of the table onto another page.
            advice = str(app.get("advice") or APP_ADVICE.get(risk, "")).strip()
            # Full measure from the APP column to the right margin, and three
            # lines: two was cutting the High advice mid-sentence, losing the
            # "uninstall it" half of the instruction, which is the part that
            # matters. Every sentence the phone writes fits in three.
            fix = _pdf_wrap_at("Remediation: " + advice, 7.2, 462) if advice else []
            if len(fix) > 3:
                fix = fix[:3]
                fix[-1] = _pdf_fit(fix[-1] + " ...", 7.2, 462)
            extra = 9.0 * len(fix)

            if self.y - 13 - extra < PDF_MARGIN + 22:
                self.new_page()
                self._app_head()
            if i % 2:
                _chart_rect(self.ops, PDF_MARGIN - 4, self.y - 3.5 - extra,
                            PDF_W - 2 * PDF_MARGIN + 8, 12.0 + extra, PDF_TINT)
            _chart_text(self.ops, 40, self.y, risk.upper(), 7.5, True,
                        RISK_INK.get(risk, PDF_MUTED))
            _chart_text(self.ops, 86, self.y, _pdf_fit(label, 8.5, 126), 8.5,
                        False, PDF_INK)
            _chart_text(self.ops, 216, self.y,
                        _pdf_fit(app.get("package") or "?", 8, 158), 8, False,
                        PDF_MUTED)
            # Plain words first: "Downloaded file" or "Opened by Chrome" tells the
            # owner more than the package name that performed the install.
            source = (app.get("origin") or app.get("installer") or "unknown")
            _chart_text(self.ops, 378, self.y,
                        _pdf_fit(source, 8, 120), 8, False, PDF_MUTED)
            _chart_text(self.ops, 502, self.y,
                        _pdf_fit(app.get("tag") or "", 7.5, 53), 7.5, False,
                        PDF_FAINT)
            self.down(13)
            for part in fix:
                _chart_text(self.ops, 86, self.y, part, 7.2, False, PDF_MUTED)
                self.down(9)
        extra = len(rows) - len(shown)
        if extra > 0:
            self.line("+{} more rows are listed in the dashboard.".format(extra),
                      8, False, PDF_MUTED)

    LOG_COLS = (("TIME", 40.0, 48.0), ("PHONE", 92.0, 92.0),
                ("RISK", 188.0, 54.0), ("HOST", 246.0, 130.0),
                ("REASON", 382.0, 173.0))

    def _log_head(self):
        self.room(26)
        self.down(8)
        for title, x, _w in self.LOG_COLS:
            _chart_text(self.ops, x, self.y, title, 7, True, PDF_MUTED)
        self.down(5)
        _chart_line(self.ops, PDF_MARGIN, self.y, PDF_W - PDF_MARGIN, self.y,
                    PDF_RULE, 0.6)
        self.down(11)

    def log_table(self, rows):
        """The event log, two lines per entry at most, with the head repeated."""
        if not rows:
            self.line("Nothing has been logged yet.", 9, False, PDF_MUTED)
            return
        self._log_head()
        for i, row in enumerate(rows):
            reason = _pdf_wrap_at(row.get("reason") or "", 8, 173)[:2]
            height = 11.0 + 9.0 * (len(reason) - 1)
            if self.y - height < PDF_MARGIN + 22:
                self.new_page()
                self._log_head()
            if i % 2:
                # Anchored to the top of the row: a two-line reason grows
                # downwards, so the band never reaches into the row above.
                _chart_rect(self.ops, PDF_MARGIN - 4, self.y + 6 - height,
                            PDF_W - 2 * PDF_MARGIN + 8, height, PDF_TINT)
            risk = str(row.get("risk") or "").capitalize()
            _chart_text(self.ops, 40, self.y, row.get("time") or "--:--:--", 7.5,
                        False, PDF_FAINT)
            _chart_text(self.ops, 92, self.y,
                        _pdf_fit(row.get("tag") or "phone", 8, 92), 8, False,
                        PDF_INK)
            _chart_text(self.ops, 188, self.y, risk.upper(), 7.5, True,
                        RISK_INK.get(risk, PDF_MUTED))
            _chart_text(self.ops, 246, self.y,
                        _pdf_fit(row.get("host") or "-", 8, 130), 8, False,
                        PDF_MUTED)
            for n, part in enumerate(reason):
                _chart_text(self.ops, 382, self.y - 9 * n, part, 8, False, PDF_INK)
            self.down(height + 2.5)


# --------------------------------------------------------------------------
# Charts
#
# Everything above draws text and rules. A bar chart needs two more things a PDF
# content stream can do easily: a filled rectangle and a stroked line. Adding
# just those keeps the report dependency-free. Every bar also carries its own
# number and the axis carries its scale, so the charts survive being printed in
# black and white.
# --------------------------------------------------------------------------
CHART_COLOURS = (
    ("Critical", (0.84, 0.24, 0.22)),
    ("High", (0.93, 0.62, 0.16)),
    ("Medium", (0.30, 0.53, 0.78)),
    ("Safe", (0.20, 0.66, 0.36)),
)

# Apps carry one of two answers, so their chart draws two bars.
APP_RISK_LEVELS = (("High", (0.93, 0.62, 0.16)),
                   ("Safe", (0.20, 0.66, 0.36)))


def _chart_rgb(ops, rgb):
    """Set the fill colour for whatever is drawn next."""
    ops.append("{:.3f} {:.3f} {:.3f} rg".format(rgb[0], rgb[1], rgb[2]))


def _chart_text(ops, x, y, text, size=9, bold=False, rgb=(0.12, 0.12, 0.12)):
    _chart_rgb(ops, rgb)
    ops.append("BT /F{} {} Tf {:.2f} {:.2f} Td ({}) Tj ET".format(
        2 if bold else 1, size, x, y, _pdf_escape(text)))


def _chart_line(ops, x1, y1, x2, y2, rgb=(0.55, 0.55, 0.55), width=0.9):
    ops.append("{:.3f} {:.3f} {:.3f} RG".format(rgb[0], rgb[1], rgb[2]))
    ops.append("{:.2f} w {:.2f} {:.2f} m {:.2f} {:.2f} l S".format(
        width, x1, y1, x2, y2))


def _chart_num(value):
    """A gridline label that does not round away from where the line sits."""
    return str(int(value)) if abs(value - round(value)) < 0.05 else "{:.1f}".format(value)


def _chart_rect(ops, x, y, w, h, rgb):
    _chart_rgb(ops, rgb)
    ops.append("{:.2f} {:.2f} {:.2f} {:.2f} re f".format(x, y, w, h))


def _chart_image(ops, x, y, w, h, name="Im1"):
    """Place the embedded image. The caller sets the colour space, not us."""
    ops.append("q {:.2f} 0 0 {:.2f} {:.2f} {:.2f} cm /{} Do Q".format(
        w, h, x, y, name))


def _pdf_bar_chart(x, y0, w, h, title, items, empty_note):
    """One titled bar chart drawn inside (x, y0) .. (x + w, y0 + h).

    items is a list of (label, value, colour) in the order they should appear.
    """
    ops = []
    _chart_text(ops, x, y0 + h - 12, title, 12, True)

    plot_x = x + 26.0                    # room for the scale numbers
    plot_w = max(60.0, w - 26.0)
    base_y = y0 + 22.0                   # room for the category names
    plot_h = max(40.0, h - 22.0 - 32.0)

    top = max([v for _, v, _ in items] or [0])
    if top <= 0:
        # Nothing to plot: a bare axis and a sentence beats four invisible bars.
        _chart_line(ops, plot_x, base_y, plot_x + plot_w, base_y)
        _chart_line(ops, plot_x, base_y, plot_x, base_y + plot_h)
        _chart_text(ops, plot_x + 6, base_y + plot_h / 2.0, empty_note, 9, False,
                    (0.45, 0.45, 0.45))
        return ops

    # Bars are scaled to 1.15x the largest count, so the tallest one stops
    # short of the top and its own number never lands on the gridline.
    scale = float(top) * 1.15

    # Gridlines at half and full scale, numbered on the left.
    for frac in (0.5, 1.0):
        gy = base_y + plot_h * (top * frac / scale)
        _chart_line(ops, plot_x, gy, plot_x + plot_w, gy, (0.82, 0.82, 0.82), 0.5)
        label = _chart_num(top * frac)
        _chart_text(ops, plot_x - 5 - len(label) * 3.2, gy - 3, label, 8, False,
                    (0.45, 0.45, 0.45))

    _chart_line(ops, plot_x, base_y, plot_x + plot_w, base_y)
    _chart_line(ops, plot_x, base_y, plot_x, base_y + plot_h)

    slot = plot_w / float(len(items))
    bar_w = min(46.0, slot * 0.52)
    for i, (label, value, colour) in enumerate(items):
        cx = plot_x + slot * (i + 0.5)
        bar_h = max(1.0, plot_h * (value / scale)) if value else 0.0
        if value:
            _chart_rect(ops, cx - bar_w / 2.0, base_y, bar_w, bar_h, colour)
        num = str(value)
        _chart_text(ops, cx - len(num) * 2.6, base_y + bar_h + 4, num, 9, True)
        _chart_text(ops, cx - len(label) * 2.5, base_y - 13, label, 9, False,
                    (0.30, 0.30, 0.30))
    return ops


def _pdf_risk_page(app_items):
    """The chart page: one chart, the apps the table lists, by risk.

    There used to be a second chart here counting logged events by risk. It was
    removed: the log already lists every event with its own risk label, so the
    chart repeated the page after it while pushing the report a page longer.
    The remaining chart is drawn once, larger, on a page of its own.
    """
    ops = []
    _chart_text(ops, PDF_MARGIN, PDF_H - 70,
                "Counts from the rows in this report, at the time it was generated.",
                8.5, False, PDF_MUTED)
    ops.extend(_pdf_bar_chart(PDF_MARGIN, 210, 515, 392,
                              "Apps from outside a store, by risk", app_items,
                              "no outside-store app has been found yet"))
    return "\n".join(ops)


def _pdf_document(pages):
    """Assemble the objects, xref table and trailer by hand.

    When the logo is present it becomes an /Image XObject under /DCTDecode: the
    JPEG bytes are copied into the file untouched, so the server never has to
    decode or re-encode a picture and still needs no imaging library.
    """
    logo = _logo_stream()
    nxt = 5
    image_id = 0
    if logo:
        image_id = nxt
        nxt += 1

    page_ids = []
    content_ids = []
    for _ in pages:
        page_ids.append(nxt)
        content_ids.append(nxt + 1)
        nxt += 2

    # Only pages that draw the image declare it, so a page that does not use it
    # stays exactly as small as it was before the logo shipped.
    xobject = " /XObject << /Im1 {} 0 R >>".format(image_id) if logo else ""

    bodies = []
    bodies.append(b"<< /Type /Catalog /Pages 2 0 R >>")
    kids = " ".join("{} 0 R".format(p) for p in page_ids)
    bodies.append("<< /Type /Pages /Count {} /Kids [{}] >>".format(
        len(pages), kids).encode("latin-1"))
    bodies.append(b"<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica "
                  b"/Encoding /WinAnsiEncoding >>")
    bodies.append(b"<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica-Bold "
                  b"/Encoding /WinAnsiEncoding >>")
    if logo:
        data, lw, lh = logo
        bodies.append((
            "<< /Type /XObject /Subtype /Image /Width {} /Height {} "
            "/ColorSpace /DeviceRGB /BitsPerComponent 8 /Filter /DCTDecode "
            "/Length {} >>\nstream\n".format(lw, lh, len(data))
        ).encode("latin-1") + data + b"\nendstream")

    for i, stream in enumerate(pages):
        bodies.append((
            "<< /Type /Page /Parent 2 0 R /MediaBox [0 0 {} {}] "
            "/Resources << /Font << /F1 3 0 R /F2 4 0 R >>{} >> "
            "/Contents {} 0 R >>".format(PDF_W, PDF_H, xobject, content_ids[i])
        ).encode("latin-1"))
        data = stream.encode("latin-1", "replace")
        bodies.append(("<< /Length {} >>\nstream\n".format(len(data))).encode("latin-1")
                     + data + b"\nendstream")

    # Document properties: the approver travels with the file, so a reader that
    # shows metadata (or an emailed copy) still names who signed it off.
    bodies.append((
        "<< /Title ({}) /Author ({}) /Subject ({}) /Creator ({}) >>".format(
            _pdf_escape("PhantomShell activity report"),
            _pdf_escape(APPROVER_NAME + " - " + APPROVER_TITLE),
            _pdf_escape("Mobile threat assessment log"),
            _pdf_escape("PhantomShell"))).encode("latin-1"))
    info_id = len(bodies)

    buf = bytearray()
    buf += b"%PDF-1.4\n%\xe2\xe3\xcf\xd3\n"
    offsets = []
    for idx, body in enumerate(bodies, start=1):
        offsets.append(len(buf))
        buf += "{} 0 obj\n".format(idx).encode("latin-1")
        buf += body
        buf += b"\nendobj\n"
    xref_at = len(buf)
    total = len(bodies) + 1
    buf += "xref\n0 {}\n".format(total).encode("latin-1")
    buf += b"0000000000 65535 f \n"
    for off in offsets:
        buf += "{:010d} 00000 n \n".format(off).encode("latin-1")
    buf += ("trailer\n<< /Size {} /Root 1 0 R /Info {} 0 R >>\nstartxref\n{}\n%%EOF\n".format(
        total, info_id, xref_at)).encode("latin-1")
    return bytes(buf)


def _chart_levels():
    """The risk levels this server actually uses, with their bar colours.

    ADVICE is the authority: a risk it does not recognise is rewritten to Safe
    when the report arrives, so charting a level outside it would only ever draw
    an empty bar and imply a category that cannot occur.
    """
    return [(name, colour) for name, colour in CHART_COLOURS if name in ADVICE]


def _risk_counts(rows, key="risk", levels=None):
    """Buckets of (label, count, colour) in chart order, for one field."""
    if levels is None:
        levels = _chart_levels()
    counts = dict((name, 0) for name, _ in levels)
    for r in rows:
        label = str(r.get(key) or "").strip().capitalize()
        if label in counts:
            counts[label] += 1
    return [(name, counts[name], colour) for name, colour in levels]


def _verdict_sentence(high, safe):
    """One plain sentence for the summary: the only opinion this report states."""
    total = high + safe
    if not total:
        return "No app from outside a store has been found on these phones."
    if high and safe:
        return "{} apps are installed from outside a store: {} high risk and {} safe.".format(
            total, high, safe)
    if high:
        if total == 1:
            return "The one app installed from outside a store is high risk."
        return "All {} apps installed from outside a store are high risk.".format(total)
    if total == 1:
        return "The one app installed from outside a store is safe."
    return "{} apps are installed from outside a store; none is high risk.".format(total)


def build_pdf_report(user=""):
    """This account's report: a summary page, the charts, then the recent log.

    The page is laid out rather than dumped: a masthead, four numbers, one
    sentence, one compact block per phone and a table of the apps that came from
    outside a store. Long logs are capped and paginated with a repeated header.
    """
    devices, recent, apps = owned_snapshot(user)
    apps = visible_apps(apps)
    totals = totals_for(devices, apps)
    devices.sort(key=lambda d: str(d.get("tag") or "").lower())
    apps.sort(key=lambda a: (a.get("risk") != "High",
                             str(a.get("label") or "").lower()))
    high_apps = sum(1 for a in apps if a.get("risk") == "High")
    log_rows = recent[:PDF_MAX_LOG]

    flow = _PdfFlow()
    _pdf_masthead(flow.ops, now_str(), str(user) if _account_key(user) else "")
    flow.y = PDF_H - 118
    flow.line("Approved by {} - {}".format(APPROVER_NAME, APPROVER_TITLE),
              8, False, PDF_FAINT, after=6)

    flow.section("Summary")
    flow.kpis([(len(devices), "phones"),
               (totals.get("reports", 0), "reports"),
               (high_apps, "high-risk apps"),
               (len(apps), "outside a store")])
    flow.line(_verdict_sentence(high_apps, len(apps) - high_apps), 10, True,
              PDF_INK, after=2)
    flow.line("{} {}   |   {} {}   |   last report {}".format(
        len(devices), "phone" if len(devices) == 1 else "phones",
        totals.get("reports", 0),
        "report" if int(totals.get("reports") or 0) == 1 else "reports",
        totals.get("last_report") or "never"), 8.5, False, PDF_MUTED, after=2)

    flow.section("Phones")
    if not devices:
        flow.line("No phone has reported to this account yet.", 9, False, PDF_MUTED)
    for dev in devices:
        flow.phone(dev, [a for a in apps
                         if a.get("device_id") == dev.get("device_id")])

    flow.section("Apps from outside a store")
    flow.app_table(apps)

    # Remediation is a section of its own and it always prints. It used to be a
    # single line that only appeared when a High app existed, so a clean report
    # said nothing at all about what to do - which reads the same as the page
    # having been cut off. What it says depends on what was found, not on whether
    # the writer remembered to draw it.
    flow.section("Remediation")
    if high_apps:
        flow.paragraph("{} {} outside a store graded High. Update or uninstall {} "
                       "above, then run Scan installed apps again. Install only "
                       "from the Play Store or the vendor store.".format(
                           high_apps, "app" if high_apps == 1 else "apps",
                           "it" if high_apps == 1 else "them"),
                       8, False, PDF_INK, after=3)
        flow.paragraph("Each row in the table above carries its own advice. The safe "
                       "rows need no action today; keep Play Protect on and scan "
                       "again after the next install.", 8, False, PDF_MUTED, after=0)
    elif apps:
        flow.paragraph("No app outside a store is graded High, so nothing has to be "
                       "removed or updated today. Keep Play Protect on and run "
                       "Scan installed apps again after the next install.",
                       8, False, PDF_INK, after=0)
    else:
        flow.paragraph("No app from outside a store was found on these phones, so "
                       "there is nothing to remove or update. Keep Play Protect on "
                       "and run Scan installed apps again after the next install.",
                       8, False, PDF_INK, after=0)

    # The log starts on a fresh page and repeats its own head, so the charts can
    # sit on one page of their own instead of landing in the middle of the log.
    flow.heading = "Activity log"
    flow.new_page()
    flow.section("Activity log")
    flow.line("Newest first, last {} entries.".format(len(log_rows))
              if log_rows else "Nothing has been logged yet.",
              8, False, PDF_MUTED, after=2)
    flow.log_table(log_rows)
    flow.finish()

    pages = flow.pages
    chart = _pdf_risk_page(_risk_counts(apps, levels=APP_RISK_LEVELS))
    pages.insert(1, _pdf_slim_header("At a glance") + "\n" + chart)
    total = len(pages)
    pages = [page + "\n" + _pdf_footer(n + 1, total)
             for n, page in enumerate(pages)]
    return _pdf_document(pages)


def build_state(user=""):
    """Everything the dashboard needs, limited to the account asking.

    A signed-in account gets its own phones, its own app rows and its own log.
    Signed out it gets none of them, so the page never falls back to a shared
    table that everybody on the network can read.
    """
    key = _account_key(user)
    devices, rows, apps = owned_snapshot(key)
    try:
        apk_size = os.path.getsize(APK_PATH)
    except OSError:
        apk_size = 0
    return {
        "status": "ok",
        "net": net_info(),
        "payloads": payload_list(),
        "apps": apk_list(apps),
        "app_totals": apk_totals(apps),
        "totals": totals_for(devices, apps),
        "device_count": len(devices),
        "devices": devices,
        "recent": rows[:150],
        "apk": {"present": apk_size > 0, "size": apk_size, "url": "/agent.apk"},
        "downloads": download_list(),
        # Which sign-in is open, and whether it is saving. The dashboard says so
        # in plain words instead of letting the operator assume.
        "auth": auth_state(user),
        "now": now_str(),
    }


def public_state():
    """The little bit of state an unauthenticated phone may see."""
    try:
        apk_size = os.path.getsize(APK_PATH)
    except OSError:
        apk_size = 0
    return {
        "status": "ok",
        "net": net_info(),
        "apk": {"present": apk_size > 0, "size": apk_size, "url": "/agent.apk"},
        "now": now_str(),
    }


def read_agent_page():
    try:
        with open(AGENT_PAGE_PATH, "r") as f:
            return f.read()
    except OSError:
        return ("<html><body><h3>PhantomShell agent</h3>"
                "<p>Download: <a href='__APK__'>agent.apk</a></p>"
                "<p>Then open: __DEEP__</p></body></html>")


# --------------------------------------------------------------------------
# Main
# --------------------------------------------------------------------------
def main():
    load_state()
    load_accounts()
    # Every account gets its own phone address, and phones saved before this
    # existed are handed to the only account when there is just one.
    ensure_ingest_tokens()
    adopted = adopt_unowned_devices()
    httpd = ThreadingHTTPServer((BIND, PORT), Handler)
    proto = "http"
    print("=" * 64)
    print(" PhantomShell dashboard server")
    print(" listening on {}:{}  (HTTP)".format(BIND, PORT))
    print(" local dashboard  -> {}://127.0.0.1:{}/".format(proto, PORT))
    print(" agent download   -> {}://127.0.0.1:{}/agent".format(proto, PORT))
    print(" console login    -> {}://127.0.0.1:{}/login".format(proto, PORT))
    print(" saving data      -> per account, kept across sign-out and restarts")
    if account_count() == 0:
        print(" accounts on file -> 0 (none yet)")
        print(" first step       -> open the login page and use Create account")
    else:
        print(" accounts on file -> {}".format(account_count()))
        print(" add an account   -> sign out, then use Create account on the login page")
    if adopted:
        print(" paired phones    -> {} saved phone(s) given to the only account"
              .format(adopted))
    print(" phone address    -> /agent follows the last sign-in, /u/<address> pins one")
    if SIGNUP_CODE:
        print(" sign-up needs    -> the invite code from PS_SIGNUP_CODE")
    else:
        print(" sign-up          -> open to anyone who can load the login page")
        print("                    set PS_SIGNUP_CODE to require an invite code")
    if MAIL_READY:
        print(" password reset   -> code emailed through {}".format(SMTP_HOST))
    else:
        print(" password reset   -> OFF (set PS_SMTP_HOST / PS_SMTP_FROM to enable)")
        if OTP_CONSOLE:
            print("                    codes are printed here (PS_OTP_CONSOLE)")
    print("=" * 64, flush=True)
    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        print("\nstopping", flush=True)
    finally:
        # A signed-in session owns the file, so stopping keeps its log.
        save_state()
        httpd.server_close()


if __name__ == "__main__":
    main()
