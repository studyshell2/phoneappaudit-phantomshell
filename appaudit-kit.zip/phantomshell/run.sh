#!/usr/bin/env bash
# One command: set up the first time, start the server every time.
#
#   bash run.sh
#
# Anything you would pass to start.sh still works, because this hands over to it:
#
#   PS_TUNNEL=0 bash run.sh          # local network only
#   PS_PORT=8099 bash run.sh         # different port

set -u

HERE="$(cd "$(dirname "$0")" && pwd)"
cd "$HERE" || exit 1

MARKER=".ps_setup_ok"

if [ ! -f "$MARKER" ]; then
  echo "First run here - setting up. This only happens once."
  echo
  if ! bash ./install.sh; then
    echo
    echo "Setup did not finish. Nothing was changed permanently."
    echo "Fix what the [FAIL] lines above say, then run: bash run.sh"
    exit 1
  fi
  # Only written after install.sh exits 0, so a half-finished setup is retried
  # rather than silently treated as done.
  : > "$MARKER"
  echo
fi

exec bash ./start.sh "$@"
