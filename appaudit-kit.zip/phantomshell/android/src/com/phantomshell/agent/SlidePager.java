package com.phantomshell.agent;

import android.content.Context;
import android.view.MotionEvent;
import android.view.VelocityTracker;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.ViewGroup;
import android.widget.Scroller;

/**
 * Two full-screen pages that slide sideways.
 *
 * Written by hand because this kit has no AndroidX: a ViewPager2 would mean
 * shipping a dependency the rest of the build does not need. The pages are laid
 * out side by side and the container is scrolled, which is what the original
 * ViewPager did and costs nothing on top of the views themselves.
 *
 * Only a clearly horizontal drag is taken from the children. A vertical drag
 * belongs to the ScrollView inside the page, and stealing it would make the
 * settings list impossible to scroll.
 */
final class SlidePager extends ViewGroup {

    interface OnPage { void onPage(int index); }

    private final int slop;
    private final int minFling;
    private final Scroller scroller;

    private int page;
    private boolean dragging;
    private float downX, downY;
    private float dragAnchorX;
    private int dragAnchorScroll;
    private VelocityTracker vt;
    private OnPage listener;

    SlidePager(Context c) {
        super(c);
        ViewConfiguration vc = ViewConfiguration.get(c);
        slop = vc.getScaledTouchSlop();
        minFling = vc.getScaledMinimumFlingVelocity() * 4;
        scroller = new Scroller(c);
        setWillNotDraw(true);
    }

    void setOnPage(OnPage l) {
        listener = l;
    }

    int page() {
        return page;
    }

    /** Move to a page, from a tab tap or from code. */
    void setPage(int index, boolean animated) {
        int max = Math.max(0, getChildCount() - 1);
        if (index < 0) index = 0;
        if (index > max) index = max;
        page = index;
        int target = index * getWidth();
        if (animated && getWidth() > 0) {
            scroller.startScroll(getScrollX(), 0, target - getScrollX(), 0, 280);
            invalidate();
        } else {
            scrollTo(target, 0);
        }
        if (listener != null) listener.onPage(page);
    }

    @Override
    public void computeScroll() {
        if (scroller.computeScrollOffset()) {
            scrollTo(scroller.getCurrX(), 0);
            postInvalidateOnAnimation();
        }
    }

    @Override
    protected void onMeasure(int wSpec, int hSpec) {
        int w = MeasureSpec.getSize(wSpec);
        int h = MeasureSpec.getSize(hSpec);
        setMeasuredDimension(w, h);
        int cw = MeasureSpec.makeMeasureSpec(w, MeasureSpec.EXACTLY);
        int ch = MeasureSpec.makeMeasureSpec(h, MeasureSpec.EXACTLY);
        for (int i = 0; i < getChildCount(); i++) {
            getChildAt(i).measure(cw, ch);
        }
    }

    @Override
    protected void onLayout(boolean changed, int l, int t, int r, int b) {
        int w = getWidth();
        for (int i = 0; i < getChildCount(); i++) {
            View child = getChildAt(i);
            child.layout(i * w, 0, (i + 1) * w, getHeight());
        }
        // Keep the current page aligned after a rotation or a resize, without
        // animating: this is a layout pass, not a gesture.
        scrollTo(page * w, 0);
    }

    @Override
    public boolean onInterceptTouchEvent(MotionEvent e) {
        switch (e.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                downX = e.getX();
                downY = e.getY();
                dragging = false;
                if (!scroller.isFinished()) scroller.abortAnimation();
                track(e);
                return false;
            case MotionEvent.ACTION_MOVE: {
                track(e);
                float dx = e.getX() - downX;
                float dy = e.getY() - downY;
                if (!dragging && Math.abs(dx) > slop
                        && Math.abs(dx) > Math.abs(dy) * 1.3f) {
                    dragging = true;
                    dragAnchorX = e.getX();
                    dragAnchorScroll = getScrollX();
                    if (getParent() != null) {
                        getParent().requestDisallowInterceptTouchEvent(true);
                    }
                    return true;
                }
                return false;
            }
            case MotionEvent.ACTION_CANCEL:
            case MotionEvent.ACTION_UP:
                dragging = false;
                release();
                return false;
        }
        return false;
    }

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        track(e);
        switch (e.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                downX = e.getX();
                downY = e.getY();
                dragAnchorX = e.getX();
                dragAnchorScroll = getScrollX();
                return true;

            case MotionEvent.ACTION_MOVE: {
                if (!dragging) {
                    float dx = e.getX() - downX;
                    float dy = e.getY() - downY;
                    if (Math.abs(dx) > slop && Math.abs(dx) > Math.abs(dy) * 1.3f) {
                        dragging = true;
                        dragAnchorX = e.getX();
                        dragAnchorScroll = getScrollX();
                    } else {
                        return true;
                    }
                }
                int max = Math.max(0, getChildCount() - 1) * getWidth();
                int want = (int) (dragAnchorScroll - (e.getX() - dragAnchorX));
                if (want < 0) want = 0;
                if (want > max) want = max;
                scrollTo(want, 0);
                return true;
            }

            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL: {
                int width = Math.max(1, getWidth());
                int dx = getScrollX() - page * width;
                int velocity = 0;
                if (vt != null) {
                    vt.computeCurrentVelocity(1000, ViewConfiguration.get(
                            getContext()).getScaledMaximumFlingVelocity());
                    velocity = (int) vt.getXVelocity();
                }
                int next = page;
                if (Math.abs(velocity) > minFling) {
                    next = velocity < 0 ? page + 1 : page - 1;
                } else if (Math.abs(dx) > width / 3) {
                    next = dx > 0 ? page + 1 : page - 1;
                }
                dragging = false;
                release();
                setPage(next, true);
                return true;
            }
        }
        return super.onTouchEvent(e);
    }

    private void track(MotionEvent e) {
        if (vt == null) vt = VelocityTracker.obtain();
        vt.addMovement(e);
    }

    private void release() {
        if (vt != null) {
            vt.recycle();
            vt = null;
        }
    }
}
