package com.phantomshell.agent;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.ApplicationInfo;
import android.content.pm.InstallSourceInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.app.ActivityManager;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.os.StatFs;
import android.provider.Settings;
import android.telephony.TelephonyManager;
import android.util.DisplayMetrics;
import android.util.Log;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.File;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.TimeZone;
import java.util.concurrent.LinkedBlockingQueue;

/**
 * Shared state and the dashboard link.
 *
 * Everything the agent learns is POSTed to the PhantomShell dashboard, which
 * owns the grading rules. The agent keeps only a coarse offline fallback so
 * that protection does not stop working when the dashboard is unreachable.
 */
final class Agent {

    static final String TAG = "PSAgent";
    static final String PREFS = "phantomshell";

    private Agent() {}

    // ------------------------------------------------------------------ config

    static SharedPreferences prefs(Context c) {
        return c.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    /**
     * One-time cleanup when upgrading from a build that had the DNS filter.
     *
     * Older versions could leave "enabled" / "vpn_consent" set, which is what
     * built the VpnService at boot. Those keys mean nothing now, so they are
     * cleared rather than left to rot in the preferences file. Nothing else is
     * touched: the dashboard address, the tag and the protection switch carry
     * over unchanged.
     */
    static void migrate(Context c) {
        SharedPreferences p = prefs(c);
        int seen = p.getInt("seen_version", 0);
        if (seen >= 5) return;
        p.edit()
                .remove("enabled")
                .remove("consent")
                .remove("vpn_consent")
                .putInt("seen_version", 5)
                .apply();
        Log.i(TAG, "migration " + seen + " -> 5: legacy VPN flags cleared");
    }

    /** Dashboard base, e.g. http://10.100.135.249:8085 . No trailing slash. */
    static String server(Context c) {
        String s = prefs(c).getString("server", "");
        if (s == null) s = "";
        s = s.trim();
        while (s.endsWith("/")) s = s.substring(0, s.length() - 1);
        return s;
    }

    static void setServer(Context c, String s) {
        if (s == null) s = "";
        s = s.trim();
        while (s.endsWith("/")) s = s.substring(0, s.length() - 1);
        prefs(c).edit().putString("server", s).apply();
    }

    static String tag(Context c) {
        String t = prefs(c).getString("tag", "");
        if (t == null || t.length() == 0) t = "phone";
        return t;
    }

    static void setTag(Context c, String t) {
        if (t == null || t.trim().length() == 0) t = "phone";
        prefs(c).edit().putString("tag", t.trim()).apply();
    }

    /**
     * PROTECTION (the app scanner + background monitoring).
     *
     * This is deliberately separate from the VPN flag below. Protection is what
     * the user turns on with "Start protection", and it does NOT establish a
     * VPN, so it cannot affect the phone's internet at all.
     */
    static boolean protectionOn(Context c) {
        return prefs(c).getBoolean("protection", false);
    }

    static void setProtectionOn(Context c, boolean b) {
        prefs(c).edit().putBoolean("protection", b).apply();
    }

    /** Stop Critical names (default) and, when asked, High ones as well. */
    static boolean blockHigh(Context c) {
        return prefs(c).getBoolean("block_high", false);
    }

    static void setBlockHigh(Context c, boolean b) {
        prefs(c).edit().putBoolean("block_high", b).apply();
    }

    /** Stable per-install id so the dashboard keeps one row per phone. */
    static String deviceId(Context c) {
        String d = prefs(c).getString("did", null);
        if (d == null || d.length() == 0) {
            d = "app-" + Long.toHexString(System.currentTimeMillis())
                    + "-" + Integer.toHexString((int) (Math.random() * 0xFFFF));
            prefs(c).edit().putString("did", d).apply();
        }
        return d;
    }

    // ------------------------------------------------------ device fingerprint

    /**
     * Read-only facts about this handset, sent with every report so the
     * dashboard can name the real phone instead of showing a bare id.
     *
     * Everything below is readable WITHOUT a runtime permission: build props,
     * screen, memory, storage, locale, ANDROID_ID and the adb switch. Anything
     * that would need one - the IMEI, the serial, the phone number - is
     * deliberately not read, so installing this app still grants Android
     * nothing new.
     *
     * Each group is guarded on its own. One lookup that an OEM has blocked
     * leaves the rest of the fingerprint intact instead of emptying all of it.
     */
    static JSONObject fingerprint(Context c) {
        JSONObject o = new JSONObject();

        // what the phone calls itself
        put(o, "manufacturer", safe(Build.MANUFACTURER));
        put(o, "brand", safe(Build.BRAND));
        put(o, "model", safe(Build.MODEL));
        put(o, "device", safe(Build.DEVICE));
        put(o, "product", safe(Build.PRODUCT));
        put(o, "board", safe(Build.BOARD));
        put(o, "hardware", safe(Build.HARDWARE));
        put(o, "fingerprint", safe(Build.FINGERPRINT));
        put(o, "build_id", safe(Build.ID));
        put(o, "display", safe(Build.DISPLAY));
        put(o, "bootloader", safe(Build.BOOTLOADER));

        // what it is running
        put(o, "android", safe(Build.VERSION.RELEASE));
        put(o, "sdk", Build.VERSION.SDK_INT);
        put(o, "security_patch", safe(Build.VERSION.SECURITY_PATCH));
        put(o, "build_tags", safe(Build.TAGS));
        put(o, "build_type", safe(Build.TYPE));
        put(o, "java_vm", safe(System.getProperty("java.vm.version")));
        put(o, "kernel", safe(System.getProperty("os.version")));
        try {
            JSONArray abis = new JSONArray();
            for (String a : Build.SUPPORTED_ABIS) abis.put(a);
            o.put("abis", abis);
            o.put("abi", Build.SUPPORTED_ABIS.length > 0 ? Build.SUPPORTED_ABIS[0] : "");
        } catch (Exception ignored) { }

        // the screen as this app sees it
        try {
            DisplayMetrics dm = c.getResources().getDisplayMetrics();
            o.put("screen", dm.widthPixels + "x" + dm.heightPixels);
            o.put("dpi", dm.densityDpi);
        } catch (Exception ignored) { }

        // cpu, ram, storage
        put(o, "cores", Runtime.getRuntime().availableProcessors());
        try {
            ActivityManager am =
                    (ActivityManager) c.getSystemService(Context.ACTIVITY_SERVICE);
            if (am != null) {
                ActivityManager.MemoryInfo mi = new ActivityManager.MemoryInfo();
                am.getMemoryInfo(mi);
                o.put("ram_mb", mi.totalMem / (1024L * 1024L));
                o.put("ram_free_mb", mi.availMem / (1024L * 1024L));
            }
        } catch (Exception ignored) { }
        try {
            StatFs fs = new StatFs(Environment.getDataDirectory().getPath());
            o.put("storage_mb",
                    (fs.getBlockCountLong() * fs.getBlockSizeLong()) / (1024L * 1024L));
            o.put("storage_free_mb",
                    (fs.getAvailableBlocksLong() * fs.getBlockSizeLong()) / (1024L * 1024L));
        } catch (Exception ignored) { }

        // where it is, and how it is set up
        try {
            o.put("locale", Locale.getDefault().toString());
            o.put("timezone", TimeZone.getDefault().getID());
        } catch (Exception ignored) { }
        try {
            o.put("android_id", safe(Settings.Secure.getString(
                    c.getContentResolver(), Settings.Secure.ANDROID_ID)));
        } catch (Exception ignored) { }
        try {
            o.put("adb_enabled", Settings.Global.getInt(c.getContentResolver(),
                    Settings.Global.ADB_ENABLED, 0) == 1);
        } catch (Exception ignored) { }
        try {
            TelephonyManager tm =
                    (TelephonyManager) c.getSystemService(Context.TELEPHONY_SERVICE);
            if (tm != null) {
                o.put("operator", safe(tm.getNetworkOperatorName()));
                o.put("sim_operator", safe(tm.getSimOperatorName()));
            }
        } catch (Exception ignored) { }

        // is this build tampered with, and is the app itself debuggable
        try {
            JSONArray root = new JSONArray();
            String[] marks = {
                    "/system/app/Superuser.apk", "/sbin/su", "/system/bin/su",
                    "/system/xbin/su", "/data/local/xbin/su", "/data/local/bin/su",
                    "/system/sd/xbin/su", "/system/bin/failsafe/su", "/data/local/su",
                    "/su/bin/su", "/data/adb/magisk", "/sbin/.magisk"
            };
            for (String p : marks) {
                try {
                    if (new File(p).exists()) root.put(p);
                } catch (Exception ignored) { }
            }
            if (safe(Build.TAGS).contains("test-keys")) {
                root.put("build tagged test-keys");
            }
            o.put("root_signals", root);
        } catch (Exception ignored) { }
        try {
            o.put("debuggable", (c.getApplicationInfo().flags
                    & ApplicationInfo.FLAG_DEBUGGABLE) != 0);
        } catch (Exception ignored) { }
        put(o, "emulator", looksLikeEmulator());
        put(o, "collected_at", System.currentTimeMillis());
        return o;
    }

    /** Set one key; a bad value must never cost the whole fingerprint. */
    private static void put(JSONObject o, String k, Object v) {
        try {
            o.put(k, v == null ? "" : v);
        } catch (Exception ignored) { }
    }

    private static boolean looksLikeEmulator() {
        String fp = safe(Build.FINGERPRINT);
        String model = safe(Build.MODEL);
        String product = safe(Build.PRODUCT);
        return fp.startsWith("generic") || fp.contains("emulator")
                || model.contains("google_sdk") || model.contains("Emulator")
                || model.contains("Android SDK built for")
                || product.contains("sdk") || product.contains("vbox86p")
                || safe(Build.MANUFACTURER).contains("Genymotion")
                || (safe(Build.BRAND).startsWith("generic")
                    && safe(Build.DEVICE).startsWith("generic"));
    }

    /**
     * Apps that may install unknown apps on this phone, right now.
     *
     * Holding REQUEST_INSTALL_PACKAGES is only the wish; the app-op says
     * whether the switch is actually on for that app. This is the setting a
     * user turns on for Chrome before a browser download will install at all,
     * so listing it explains how an outside-store app got there.
     */
    static JSONArray unknownSourcesAllowed(Context c) {
        JSONArray out = new JSONArray();
        try {
            PackageManager pm = c.getPackageManager();
            android.app.AppOpsManager ops =
                    (android.app.AppOpsManager) c.getSystemService(Context.APP_OPS_SERVICE);
            List<PackageInfo> list = pm.getInstalledPackages(PackageManager.GET_PERMISSIONS);
            for (PackageInfo pi : list) {
                if (pi == null || pi.applicationInfo == null
                        || pi.requestedPermissions == null) {
                    continue;
                }
                boolean asks = false;
                for (String p : pi.requestedPermissions) {
                    if ("android.permission.REQUEST_INSTALL_PACKAGES".equals(p)) {
                        asks = true;
                        break;
                    }
                }
                if (!asks) continue;
                boolean allowed = false;
                try {
                    if (ops != null && Build.VERSION.SDK_INT >= 29) {
                        allowed = ops.unsafeCheckOpNoThrow(
                                "android:request_install_packages",
                                pi.applicationInfo.uid, pi.packageName)
                                == android.app.AppOpsManager.MODE_ALLOWED;
                    } else if (ops != null) {
                        allowed = ops.checkOpNoThrow("android:request_install_packages",
                                pi.applicationInfo.uid, pi.packageName)
                                == android.app.AppOpsManager.MODE_ALLOWED;
                    }
                } catch (Throwable ignored) { }
                if (!allowed) continue;
                JSONObject row = new JSONObject();
                row.put("package", pi.packageName);
                row.put("label", String.valueOf(pm.getApplicationLabel(pi.applicationInfo)));
                out.put(row);
            }
        } catch (Throwable t) {
            Log.w(TAG, "unknownSources: " + t);
        }
        return out;
    }

    private static String safe(String s) {
        return s == null ? "" : s;
    }

    // ------------------------------------------------------------ installed apps

    /**
     * Installed apps, with sideloaded ones separated out.
     *
     * QUERY_ALL_PACKAGES is what makes this possible; without it Android only
     * reveals the agent's own package. That is why the agent is installed
     * directly rather than from a store.
     */
    static JSONObject packages(Context c) {
        JSONObject out = new JSONObject();
        JSONArray sideloaded = new JSONArray();
        int total = 0, system = 0, thirdParty = 0, storeApps = 0;
        try {
            PackageManager pm = c.getPackageManager();
            List<PackageInfo> list = pm.getInstalledPackages(0);
            for (PackageInfo pi : list) {
                if (pi == null || pi.applicationInfo == null) continue;
                total++;
                boolean sys = (pi.applicationInfo.flags & ApplicationInfo.FLAG_SYSTEM) != 0;
                if (sys) { system++; continue; }
                thirdParty++;
                // The same rule the scanner grades with, read the same way.
                // A single installer package cannot tell a Play Store app from
                // a downloaded .apk on vivo or Samsung, so both sides ask
                // Android for the whole install chain.
                AppScanner.Origin org = AppScanner.originOf(pm, pi.packageName);
                if (org.store) { storeApps++; continue; }
                JSONObject row = new JSONObject();
                row.put("package", pi.packageName);
                row.put("label", String.valueOf(pm.getApplicationLabel(pi.applicationInfo)));
                row.put("version", safe(pi.versionName));
                row.put("installer", org.installer);
                row.put("origin", org.label(pm));
                sideloaded.put(row);
            }
            out.put("total", total);
            out.put("system", system);
            out.put("third_party", thirdParty);
            out.put("sideloaded", sideloaded);
            out.put("sideloaded_count", sideloaded.length());
            // How many user apps a store delivered. Counted, never listed: the
            // dashboard only reports what did not come from a store, and this
            // number is what makes that omission checkable rather than silent.
            out.put("store", storeApps);
            // Which apps on this phone are allowed to install unknown apps.
            // That permission is what lets a browser or file manager put an
            // .apk on the device, so it explains where the rows came from.
            out.put("unknown_sources", unknownSourcesAllowed(c));
        } catch (Exception e) {
            Log.w(TAG, "packages: " + e);
        }
        return out;
    }

    private static String installerOf(PackageManager pm, String pkg) {
        try {
            if (Build.VERSION.SDK_INT >= 30) {
                InstallSourceInfo i = pm.getInstallSourceInfo(pkg);
                String s = i.getInstallingPackageName();
                return s == null ? "" : s;
            }
            String s = pm.getInstallerPackageName(pkg);
            return s == null ? "" : s;
        } catch (Exception e) {
            return "";
        }
    }

    // -------------------------------------------------------------- HTTP helper

    static String post(String base, String path, JSONObject body, int timeoutMs) {
        HttpURLConnection conn = null;
        try {
            URL u = new URL(base + path);
            conn = (HttpURLConnection) u.openConnection();
            conn.setRequestMethod("POST");
            conn.setConnectTimeout(timeoutMs);
            conn.setReadTimeout(timeoutMs);
            conn.setDoOutput(true);
            conn.setRequestProperty("Content-Type", "application/json");
            byte[] payload = body == null ? new byte[0]
                    : body.toString().getBytes("UTF-8");
            conn.setFixedLengthStreamingMode(payload.length);
            OutputStream os = conn.getOutputStream();
            os.write(payload);
            os.flush();
            os.close();
            int code = conn.getResponseCode();
            InputStream in = code >= 400 ? conn.getErrorStream() : conn.getInputStream();
            if (in == null) return "";
            BufferedReader r = new BufferedReader(new InputStreamReader(in, "UTF-8"));
            StringBuilder sb = new StringBuilder();
            String line;
            while ((line = r.readLine()) != null) sb.append(line);
            r.close();
            return sb.toString();
        } catch (Exception e) {
            Log.w(TAG, "post " + path + ": " + e);
            return "";
        } finally {
            if (conn != null) conn.disconnect();
        }
    }

    // ------------------------------------------------------------- verdict type

    static final class Verdict {
        String risk = "Safe";
        String reason = "";
        String advice = "";
        boolean block = false;
    }

    /**
     * Grade one hostname.
     *
     * The dashboard is the authority: ask it first, because that keeps one set
     * of rules for the browser guard, the network guard and this agent. The
     * local table is only used when the dashboard cannot be reached, so the
     * phone keeps some protection offline.
     */
    static Verdict grade(Context c, String host) {
        String base = server(c);
        if (base.length() > 0) {
            try {
                JSONObject body = new JSONObject();
                body.put("host", host);
                body.put("tag", tag(c));
                body.put("device_id", deviceId(c));
                body.put("source", "agent_vpn");
                String resp = post(base, "/api/agent/grade", body, 2500);
                if (resp != null && resp.trim().length() > 0) {
                    JSONObject j = new JSONObject(resp);
                    Verdict v = new Verdict();
                    v.risk = j.optString("risk", "Safe");
                    v.reason = j.optString("reason", "");
                    v.advice = j.optString("advice", "");
                    v.block = j.optBoolean("block", false);
                    if (!"Safe".equals(v.risk)) return v;
                    return v;
                }
            } catch (Exception e) {
                Log.w(TAG, "grade via server: " + e);
            }
        }
        return localGrade(host);
    }

    private static final String[] BAD_TLD = {
            ".top", ".xyz", ".tk", ".ml", ".ga", ".cf", ".gq", ".work", ".click",
            ".link", ".buzz", ".rest", ".fit", ".cam", ".surf", ".monster",
            ".quest", ".cfd", ".sbs", ".icu", ".loan", ".download", ".zip",
            ".mov", ".country", ".stream", ".gdn", ".review"
    };

    private static final String[] BAD_WORD = {
            "login", "verify", "verify-account", "secure", "account", "update",
            "signin", "sign-in", "wallet", "password", "passwd", "otp", "kyc",
            "refund", "invoice", "bonus", "prize", "gift", "lucky", "winner",
            "bank", "payment", "pay-", "paypal", "netbanking", "upi", "free",
            "unlock", "recover", "confirm", "support", "helpdesk", "offer",
            "reward", "claim", "urgent", "suspended", "blocked"
    };

    /** Coarse offline fallback. The dashboard's rules are finer. */
    static Verdict localGrade(String host) {
        Verdict v = new Verdict();
        String h = host == null ? "" : host.toLowerCase();
        if (h.length() == 0) return v;

        boolean badTld = false;
        for (String t : BAD_TLD) {
            if (h.endsWith(t) || h.contains(t + "/")) { badTld = true; break; }
        }
        boolean badWord = false;
        String flat = h.replace("-", "").replace(".", "");
        for (String w : BAD_WORD) {
            if (flat.contains(w.replace("-", ""))) { badWord = true; break; }
        }
        boolean puny = h.contains("xn--");
        boolean ipLiteral = h.matches("^\\d{1,3}(\\.\\d{1,3}){3}$");

        if ((badTld && badWord) || (puny && badWord)) {
            v.risk = "Critical";
            v.reason = (badTld ? "domain in a heavily abused extension" : "lookalike domain")
                    + " combined with account/payment wording";
        } else if (badTld || badWord || puny || ipLiteral) {
            v.risk = "High";
            v.reason = badTld ? "domain in a heavily abused extension"
                    : badWord ? "address contains account or payment wording"
                    : puny ? "lookalike (punycode) address"
                    : "bare IP address instead of a domain name";
        } else {
            v.risk = "Safe";
            v.reason = "nothing unusual in the address";
        }
        v.advice = adviceFor(v.risk);
        v.block = "Critical".equals(v.risk);
        return v;
    }

    static String adviceFor(String risk) {
        if ("Critical".equals(risk)) {
            return "Stop here. Do not type a password, card number or one-time code "
                    + "on this page. Close it. If you already typed something, change "
                    + "that password from a different app or tab.";
        }
        if ("High".equals(risk)) {
            return "Careful. Do not enter personal details, do not allow downloads or "
                    + "'install' prompts, and do not continue past a warning page. If a "
                    + "page asked you to sign in, open the site from its own address "
                    + "instead of the link that brought you here.";
        }
        return "Nothing unusual was measured. Normal browsing is fine; keep checking "
                + "the address bar matches the site name.";
    }

    // --------------------------------------------- on-phone detection record
    //
    // The dashboard is the long-term log, but the phone keeps its own short
    // history so the user can see ON THE HANDSET what was detected, why it was
    // flagged and what to do about it. That is the proof side of the feature:
    // it works even when the dashboard is unreachable.

    static final int DETECTIONS_MAX = 40;

    /** Record one suspicious name. Safe names are never stored. */
    static synchronized void addDetection(Context c, String host, Verdict v, String action) {
        if (v == null || "Safe".equals(v.risk)) return;
        try {
            JSONArray prev = detections(c);
            JSONArray out = new JSONArray();
            JSONObject o = new JSONObject();
            o.put("host", host == null ? "" : host);
            o.put("risk", v.risk);
            o.put("reason", v.reason == null ? "" : v.reason);
            o.put("advice", v.advice == null ? "" : v.advice);
            o.put("action", action == null ? "seen" : action);
            o.put("at", System.currentTimeMillis());
            out.put(o);
            for (int i = 0; i < prev.length() && out.length() < DETECTIONS_MAX; i++) {
                out.put(prev.get(i));
            }
            prefs(c).edit().putString("detections", out.toString()).apply();
        } catch (Exception e) {
            Log.w(TAG, "addDetection: " + e);
        }
    }

    // ------------------------------------------------ app-scanner bookkeeping

    static void setLastScan(Context c, String json) {
        prefs(c).edit().putString("last_scan", json == null ? "" : json).apply();
    }

    static String getLastScan(Context c) {
        String s = prefs(c).getString("last_scan", "");
        return s == null ? "" : s;
    }

    static void setScanRequested(Context c, boolean b) {
        prefs(c).edit().putBoolean("scan_requested", b).apply();
    }

    /** True when a pre-install scan should happen the next time we get control. */
    static boolean scanRequested(Context c) {
        return prefs(c).getBoolean("scan_requested", true);
    }

    /**
     * Tell the dashboard an app is gone, so a removed threat disappears from the
     * app list instead of sitting there looking active.
     */
    static void reportApkRemoved(Context c, String pkg) {
        String base = server(c);
        if (base.length() == 0 || pkg == null || pkg.length() == 0) return;
        try {
            JSONObject o = new JSONObject();
            o.put("type", "apk_removed");
            o.put("package", pkg);
            o.put("risk", "Safe");
            o.put("at", System.currentTimeMillis());
            JSONArray arr = new JSONArray();
            arr.put(o);
            JSONObject body = new JSONObject();
            body.put("tag", tag(c));
            body.put("device_id", deviceId(c));
            body.put("events", arr);
            post(base, "/api/agent/report", body, 6000);
        } catch (Exception e) {
            Log.w(TAG, "reportApkRemoved: " + e);
        }
    }

    /** Newest first. */
    static synchronized JSONArray detections(Context c) {
        try {
            String raw = prefs(c).getString("detections", "[]");
            if (raw == null || raw.length() == 0) return new JSONArray();
            return new JSONArray(raw);
        } catch (Exception e) {
            return new JSONArray();
        }
    }

    static synchronized void clearDetections(Context c) {
        prefs(c).edit().remove("detections").apply();
    }

    /**
     * The Clear button: forget what this handset remembers about its own scans.
     *
     * Only local keys go. The dashboard address, the device tag and the device
     * id stay, and nothing is sent to the server, so the phone keeps the same
     * row on the dashboard with its history. There is no call anywhere in this
     * agent that deletes a device - clearing the phone must never remove it
     * from somebody's dashboard.
     */
    static void clearLocalResults(Context c) {
        SharedPreferences p = prefs(c);
        SharedPreferences.Editor e = p.edit();
        e.remove("last_scan").remove("detections");
        // The signer cache is only used to spot a changed signature; with the
        // results gone it has nothing left to compare against, so it goes too.
        for (String key : p.getAll().keySet()) {
            if (key != null && key.startsWith("sig:")) e.remove(key);
        }
        e.apply();
        Log.i(TAG, "local scan results cleared (device id and dashboard kept)");
    }

    /** "14:03:21" for the on-phone list. */
    static String clock(long ms) {
        try {
            return new java.text.SimpleDateFormat("HH:mm:ss", java.util.Locale.US)
                    .format(new java.util.Date(ms));
        } catch (Exception e) {
            return "--:--:--";
        }
    }

    // ------------------------------------------------------- asynchronous report

    /**
     * Every site, package and fingerprint report goes through this queue, so the
     * DNS loop never blocks on the network.
     */
    static final class Reporter {
        private final Context ctx;
        /** Built once: a phone's own facts do not change while it runs. */
        private final JSONObject fp;
        private final LinkedBlockingQueue<JSONObject> q =
                new LinkedBlockingQueue<JSONObject>();
        private volatile boolean running = true;
        private Thread worker;

        Reporter(Context c) {
            this.ctx = c.getApplicationContext();
            this.fp = fingerprint(this.ctx);
        }

        void start() {
            worker = new Thread(new Runnable() {
                @Override public void run() { loop(); }
            }, "ps-reporter");
            worker.setDaemon(true);
            worker.start();
        }

        void stop() {
            running = false;
            if (worker != null) worker.interrupt();
        }

        void submit(JSONObject o) {
            if (running) q.offer(o);
        }

        private void loop() {
            while (running) {
                JSONObject first;
                try {
                    first = q.take();
                } catch (InterruptedException e) {
                    return;
                }
                List<JSONObject> batch = new ArrayList<JSONObject>();
                batch.add(first);
                q.drainTo(batch, 49);

                String base = server(ctx);
                if (base.length() == 0) continue;
                try {
                    JSONObject body = new JSONObject();
                    body.put("tag", tag(ctx));
                    body.put("device_id", deviceId(ctx));
                    body.put("fingerprint", fp);
                    JSONArray arr = new JSONArray();
                    for (JSONObject o : batch) arr.put(o);
                    body.put("events", arr);
                    post(base, "/api/agent/report", body, 4000);
                } catch (Exception e) {
                    Log.w(TAG, "report batch: " + e);
                }
            }
        }
    }

    /** One detected hostname, ready to send. */
    static JSONObject siteEvent(String host, Verdict v, String action) {
        JSONObject o = new JSONObject();
        try {
            o.put("type", "site");
            o.put("host", host);
            o.put("risk", v.risk);
            o.put("reason", v.reason);
            o.put("advice", v.advice);
            o.put("action", action);
            o.put("at", System.currentTimeMillis());
        } catch (Exception ignored) { }
        return o;
    }

    static JSONObject textEvent(String type, String risk, String details) {
        JSONObject o = new JSONObject();
        try {
            o.put("type", type);
            o.put("risk", risk);
            o.put("details", details);
            o.put("at", System.currentTimeMillis());
        } catch (Exception ignored) { }
        return o;
    }

    static String enc(String s) {
        try {
            return URLEncoder.encode(s == null ? "" : s, "UTF-8");
        } catch (Exception e) {
            return "";
        }
    }

    static String qs(Uri u, String key) {
        try {
            String v = u.getQueryParameter(key);
            return v == null ? "" : v;
        } catch (Exception e) {
            return "";
        }
    }

    static Set<String> uniq(List<String> in) {
        return new LinkedHashSet<String>(in);
    }

    static Map<String, String> emptyMap() {
        return Collections.emptyMap();
    }
}
