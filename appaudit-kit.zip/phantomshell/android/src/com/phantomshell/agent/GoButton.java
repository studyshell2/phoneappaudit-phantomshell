package com.phantomshell.agent;

import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RadialGradient;
import android.graphics.Shader;
import android.view.MotionEvent;
import android.view.View;
import android.view.animation.LinearInterpolator;

/**
 * The round GO control.
 *
 * Idle it breathes: two rings drift outward from the rim. While scanning the
 * ring becomes a head that runs around the circle and the pulse speeds up, so
 * the button itself says the work is happening - no spinner bolted on top.
 *
 * The press animation scales the whole disc down slightly; the click is only
 * fired on release inside the circle, so a scroll that starts on the button does
 * not count as a tap.
 */
final class GoButton extends View {

    interface OnGo { void onGo(); }

    private final Paint ringP  = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint discP  = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint textP  = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint pulseP = new Paint(Paint.ANTI_ALIAS_FLAG);

    private static final long LOOP_MS = 2600;

    private float phase;        // 0..1 breathing clock
    private float spin;         // degrees, only advances while scanning
    private boolean scanning;
    private boolean pressed;
    private OnGo listener;
    private ValueAnimator loop;

    GoButton(Context c) {
        super(c);
        ringP.setStyle(Paint.Style.STROKE);
        ringP.setStrokeCap(Paint.Cap.ROUND);
        ringP.setStrokeWidth(Ui.fdp(c, 3f));

        discP.setStyle(Paint.Style.FILL);
        discP.setAntiAlias(true);

        textP.setTextAlign(Paint.Align.CENTER);
        textP.setTypeface(Ui.MONO);
        textP.setLetterSpacing(0.18f);

        pulseP.setStyle(Paint.Style.STROKE);

        setClickable(true);
        setFocusable(true);
    }

    void setOnGo(OnGo l) {
        this.listener = l;
    }

    void setScanning(boolean s) {
        if (scanning == s) return;
        scanning = s;
        spin = 0f;
        invalidate();
    }

    @Override
    protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        if (loop != null) return;
        loop = ValueAnimator.ofFloat(0f, 1f);
        loop.setDuration(LOOP_MS);
        loop.setRepeatCount(ValueAnimator.INFINITE);
        loop.setInterpolator(new LinearInterpolator());
        loop.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
            @Override public void onAnimationUpdate(ValueAnimator a) {
                phase = (Float) a.getAnimatedValue();
                if (scanning) spin = (spin + 9f) % 360f;
                invalidate();
            }
        });
        loop.start();
    }

    @Override
    protected void onDetachedFromWindow() {
        if (loop != null) {
            loop.cancel();
            loop = null;
        }
        super.onDetachedFromWindow();
    }

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        switch (e.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                pressed = true;
                animate().scaleX(0.95f).scaleY(0.95f).setDuration(90).start();
                invalidate();
                return true;
            case MotionEvent.ACTION_CANCEL:
                pressed = false;
                animate().scaleX(1f).scaleY(1f).setDuration(140).start();
                invalidate();
                return true;
            case MotionEvent.ACTION_UP:
                pressed = false;
                animate().scaleX(1f).scaleY(1f).setDuration(140).start();
                invalidate();
                float cx = getWidth() / 2f, cy = getHeight() / 2f;
                float dx = e.getX() - cx, dy = e.getY() - cy;
                float r = Math.min(getWidth(), getHeight()) / 2f;
                if (dx * dx + dy * dy <= r * r && listener != null) {
                    listener.onGo();
                }
                return true;
        }
        return super.onTouchEvent(e);
    }

    @Override
    protected void onDraw(Canvas canvas) {
        float w = getWidth(), h = getHeight();
        if (w <= 0 || h <= 0) return;

        float cx = w / 2f, cy = h / 2f;
        float r = Math.min(w, h) / 2f - Ui.fdp(getContext(), 12f);

        // Breathing rings, only while idle - during a scan the ring below is
        // already moving and a second animation would just add noise.
        if (!scanning) {
            for (int i = 0; i < 2; i++) {
                float p = (phase + i * 0.5f) % 1f;
                float pr = r * (1f + 0.30f * p);
                pulseP.setStrokeWidth(Ui.fdp(getContext(), 1.2f));
                pulseP.setColor(Ui.ACCENT);
                pulseP.setAlpha((int) (46 * (1f - p)));
                canvas.drawCircle(cx, cy, pr, pulseP);
            }
        }

        // Track.
        ringP.setStrokeWidth(Ui.fdp(getContext(), 2f));
        ringP.setColor(Ui.LINE);
        ringP.setAlpha(200);
        canvas.drawCircle(cx, cy, r, ringP);

        // Head, or the running arc while scanning.
        if (scanning) {
            ringP.setStrokeWidth(Ui.fdp(getContext(), 3.4f));
            ringP.setColor(Ui.ACCENT);
            ringP.setAlpha(255);
            android.graphics.RectF box = new android.graphics.RectF(
                    cx - r, cy - r, cx + r, cy + r);
            canvas.drawArc(box, spin, 96f, false, ringP);
            canvas.drawArc(box, spin + 180f, 34f, false, ringP);
        }

        // The disc, lit from the top-left like the sign-in card's fields.
        float dr = r - Ui.fdp(getContext(), 14f);
        discP.setShader(new RadialGradient(cx - dr * 0.35f, cy - dr * 0.45f, dr * 1.7f,
                new int[] {pressed ? 0xFF2A6FB8 : 0xFF1B4A78, 0xFF0A1C30},
                new float[] {0f, 1f}, Shader.TileMode.CLAMP));
        canvas.drawCircle(cx, cy, dr, discP);
        discP.setShader(null);

        // Inner hairline, so the disc has an edge against the video behind it.
        ringP.setStrokeWidth(Math.max(1f, Ui.fdp(getContext(), 0.9f)));
        ringP.setColor(0x66A8CBF5);
        canvas.drawCircle(cx, cy, dr, ringP);

        textP.setTextSize(Ui.fdp(getContext(), scanning ? 15f : 26f));
        textP.setColor(scanning ? 0xFFBBD4F2 : Ui.STRONG);
        canvas.drawText(scanning ? "SCAN" : "GO", cx,
                cy + (scanning ? Ui.fdp(getContext(), 5f) : Ui.fdp(getContext(), 9f)),
                textP);

        if (scanning) {
            textP.setTextSize(Ui.fdp(getContext(), 8f));
            textP.setTypeface(Ui.MONO_R);
            textP.setLetterSpacing(0.24f);
            textP.setColor(Ui.MUTED);
            canvas.drawText("RUNNING", cx, cy + Ui.fdp(getContext(), 22f), textP);
        }
    }
}
