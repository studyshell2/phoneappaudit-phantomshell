package com.phantomshell.agent;

import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.RadialGradient;
import android.graphics.Shader;
import android.view.View;
import android.view.animation.LinearInterpolator;

/**
 * The page underneath everything: navy gradient, a faint grid, two slow glows.
 *
 * This is the floor the UI stands on. The video sits above it at reduced alpha,
 * so if a phone refuses to decode the mp4 the screen still looks deliberate
 * instead of showing a black rectangle.
 *
 * The shaders are built once per size and the glows are drawn by translating
 * the canvas to the origin, so a 30fps redraw allocates nothing. Building a
 * RadialGradient inside onDraw - the obvious version - allocates three shader
 * objects per frame and makes the whole screen stutter on a cheap phone.
 */
final class Backdrop extends View {

    private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint grid = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint glowA = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint glowB = new Paint(Paint.ANTI_ALIAS_FLAG);
    private float phase = 0f;
    private ValueAnimator anim;

    private LinearGradient gBase;
    private RadialGradient g1, g2;
    private float g1r = -1, g2r = -1;
    private float builtW = -1, builtH = -1;

    Backdrop(Context c) {
        super(c);
        grid.setStyle(Paint.Style.STROKE);
        grid.setStrokeWidth(Math.max(1f, Ui.fdp(c, 0.6f)));
        grid.setColor(0x14FFFFFF);
    }

    @Override
    protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        if (anim != null) return;
        anim = ValueAnimator.ofFloat(0f, 1f);
        anim.setDuration(14000);
        anim.setRepeatCount(ValueAnimator.INFINITE);
        anim.setInterpolator(new LinearInterpolator());
        anim.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
            @Override public void onAnimationUpdate(ValueAnimator a) {
                phase = (Float) a.getAnimatedValue();
                invalidate();
            }
        });
        anim.start();
    }

    @Override
    protected void onDetachedFromWindow() {
        if (anim != null) {
            anim.cancel();
            anim = null;
        }
        super.onDetachedFromWindow();
    }

    /** Rebuild the shaders only when the surface actually changes size. */
    private void build(float w, float h) {
        if (w == builtW && h == builtH && gBase != null) return;
        builtW = w;
        builtH = h;

        gBase = new LinearGradient(0, 0, 0, h,
                new int[] {Ui.BG_TOP, Ui.BG_MID, Ui.BG},
                new float[] {0f, 0.55f, 1f}, Shader.TileMode.CLAMP);
        fill.setShader(gBase);

        g1r = Math.max(1f, w * 0.62f);
        g2r = Math.max(1f, w * 0.55f);
        g1 = new RadialGradient(0, 0, g1r,
                new int[] {0x2A4C9AFF, 0x00000000},
                new float[] {0f, 1f}, Shader.TileMode.CLAMP);
        g2 = new RadialGradient(0, 0, g2r,
                new int[] {0x1E38D6C8, 0x00000000},
                new float[] {0f, 1f}, Shader.TileMode.CLAMP);
        glowA.setShader(g1);
        glowB.setShader(g2);
    }

    @Override
    protected void onDraw(Canvas canvas) {
        float w = getWidth(), h = getHeight();
        if (w <= 0 || h <= 0) return;
        build(w, h);

        // Base gradient, top-lit like the sign-in card.
        canvas.drawRect(0, 0, w, h, fill);

        // Grid, spaced to the same rhythm as the card's hairlines.
        float step = Ui.fdp(getContext(), 44f);
        for (float x = 0; x < w; x += step) canvas.drawLine(x, 0, x, h, grid);
        for (float y = 0; y < h; y += step) canvas.drawLine(0, y, w, y, grid);

        // Two glows drifting on slow sine paths. Translate to the centre and
        // draw the cached gradient at the origin: no allocation per frame.
        float a = (float) (phase * Math.PI * 2);
        drawGlow(canvas, glowA, w * (0.22f + 0.06f * (float) Math.sin(a)),
                h * (0.18f + 0.04f * (float) Math.cos(a)), g1r);
        drawGlow(canvas, glowB, w * (0.82f + 0.05f * (float) Math.cos(a * 0.8)),
                h * (0.72f + 0.05f * (float) Math.sin(a * 0.9)), g2r);
    }

    private void drawGlow(Canvas c, Paint p, float cx, float cy, float r) {
        int save = c.save();
        c.translate(cx, cy);
        c.drawCircle(0, 0, r, p);
        c.restoreToCount(save);
    }
}
