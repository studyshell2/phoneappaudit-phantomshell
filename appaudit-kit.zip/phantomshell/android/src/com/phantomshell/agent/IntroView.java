package com.phantomshell.agent;

import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.view.View;
import android.view.animation.LinearInterpolator;

/**
 * The opening animation: the crest draws itself, then the name.
 *
 * One animator drives a single 0..1 clock and every element reads its own window
 * off that clock. Doing it this way means the sequence can be retimed by moving
 * one number, and the phases cannot drift apart the way chained animators do.
 *
 * The overlay is added on top of the live screen, so the video behind it is
 * already playing when it fades out. There is no second screen to load.
 */
final class IntroView extends View {

    interface Done { void onDone(); }

    private static final long TOTAL_MS = 2450;

    private final Bitmap crest;
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint ring = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint line = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF box = new RectF();
    private final Path clip = new Path();

    private float t = 0f;
    private boolean finished;

    IntroView(Context c, Bitmap crest) {
        super(c);
        this.crest = crest;
        ring.setStyle(Paint.Style.STROKE);
        ring.setStrokeCap(Paint.Cap.ROUND);
        line.setStyle(Paint.Style.STROKE);
        setClickable(true);
    }

    /** 0..1 across a window, eased so nothing starts or stops abruptly. */
    private static float win(float t, float from, float to) {
        if (t <= from) return 0f;
        if (t >= to) return 1f;
        float x = (t - from) / (to - from);
        return x * x * (3f - 2f * x);
    }

    void play(final Done done) {
        ValueAnimator a = ValueAnimator.ofFloat(0f, 1f);
        a.setDuration(TOTAL_MS);
        a.setInterpolator(new LinearInterpolator());
        a.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
            @Override public void onAnimationUpdate(ValueAnimator v) {
                t = (Float) v.getAnimatedValue();
                invalidate();
            }
        });
        a.addListener(new android.animation.AnimatorListenerAdapter() {
            @Override public void onAnimationEnd(android.animation.Animator v) {
                if (finished) return;
                finished = true;
                animate().alpha(0f).setDuration(200)
                        .withEndAction(new Runnable() {
                            @Override public void run() {
                                if (done != null) done.onDone();
                            }
                        }).start();
            }
        });
        a.start();
    }

    @Override
    protected void onDraw(Canvas canvas) {
        float w = getWidth(), h = getHeight();
        if (w <= 0 || h <= 0) return;

        // Exit fade, applied to everything at once.
        float out = 1f - win(t, 0.90f, 1f);
        if (out <= 0f) return;

        // 1. The room goes dark.
        p.setColor(Ui.BG);
        p.setAlpha((int) (255 * win(t, 0f, 0.12f) * out));
        canvas.drawRect(0, 0, w, h, p);

        float cx = w / 2f;
        float cy = h * 0.43f;
        float size = Math.min(w * 0.44f, Ui.fdp(getContext(), 156f));
        float lw = size;
        float lh = size * (crest == null ? 1f
                : crest.getHeight() / (float) crest.getWidth());

        // 2. A ring sweeps once around where the crest will sit.
        float sweep = win(t, 0.06f, 0.52f);
        if (sweep > 0f) {
            float r = size * 0.86f;
            ring.setStrokeWidth(Ui.fdp(getContext(), 2.2f));
            ring.setColor(Ui.LINE);
            ring.setAlpha((int) (110 * out));
            canvas.drawCircle(cx, cy, r, ring);
            ring.setColor(Ui.ACCENT);
            ring.setAlpha((int) (235 * out));
            box.set(cx - r, cy - r, cx + r, cy + r);
            canvas.drawArc(box, -90f, 360f * sweep, false, ring);
        }

        // 3. The crest arrives: fades up while settling from 0.86 to 1.0, with a
        //    small overshoot so it lands rather than just appearing.
        float in = win(t, 0.16f, 0.46f);
        if (in > 0f && crest != null) {
            float pop = 0.86f + 0.14f * in;
            float over = (float) Math.sin(Math.PI * Math.min(1f, in * 1.0f));
            pop += 0.035f * over;
            float dw = lw * pop, dh = lh * pop;
            float left = cx - dw / 2f, top = cy - dh / 2f;
            float radius = Ui.fdp(getContext(), 20f);

            clip.reset();
            clip.addRoundRect(new RectF(left, top, left + dw, top + dh),
                    radius, radius, Path.Direction.CW);
            canvas.save();
            canvas.clipPath(clip);
            p.setAlpha((int) (255 * in * out));
            canvas.drawBitmap(crest, null,
                    new RectF(left, top, left + dw, top + dh), p);
            canvas.restore();

            // Hairline edge so the crest reads as a plate on the navy, not as a
            // black rectangle pasted onto it.
            line.setStrokeWidth(Math.max(1f, Ui.fdp(getContext(), 0.9f)));
            line.setColor(Ui.LINE);
            line.setAlpha((int) (170 * in * out));
            canvas.drawRoundRect(new RectF(left, top, left + dw, top + dh),
                    radius, radius, line);
        }

        // The text sits below whichever is lower: the crest plate or the ring
        // that swept around it. With the crest's own 370:340 aspect the ring is
        // the wider of the two, and using lh/2 alone would print the wordmark
        // straight through the bottom of the arc.
        float below = cy + Math.max(lh / 2f, size * 0.86f);

        // 4. The name, tracking in from slightly below.
        float nameIn = win(t, 0.36f, 0.58f);
        if (nameIn > 0f) {
            p.setTypeface(Ui.MONO);
            p.setTextAlign(Paint.Align.CENTER);
            p.setLetterSpacing(0.18f);
            p.setTextSize(Ui.fdp(getContext(), 21f));
            p.setColor(Ui.STRONG);
            p.setAlpha((int) (255 * nameIn * out));
            canvas.drawText("PHANTOMSHELL", cx,
                    below + Ui.fdp(getContext(), 34f)
                            + (1f - nameIn) * Ui.fdp(getContext(), 10f), p);

            // A rule that grows outward from the centre under the name.
            float grow = win(t, 0.42f, 0.66f);
            line.setColor(Ui.ACCENT);
            line.setAlpha((int) (200 * grow * out));
            line.setStrokeWidth(Math.max(1f, Ui.fdp(getContext(), 1.4f)));
            float half = Ui.fdp(getContext(), 64f) * grow;
            float y = below + Ui.fdp(getContext(), 52f);
            canvas.drawLine(cx - half, y, cx + half, y, line);
        }

        // 5. What it is, in one quiet line.
        float subIn = win(t, 0.50f, 0.70f);
        if (subIn > 0f) {
            p.setTypeface(Ui.MONO_R);
            p.setLetterSpacing(0.34f);
            p.setTextSize(Ui.fdp(getContext(), 8.4f));
            p.setColor(Ui.MUTED);
            p.setAlpha((int) (255 * subIn * out));
            canvas.drawText("PHONE SAFETY - ON DEVICE", cx,
                    below + Ui.fdp(getContext(), 70f), p);
        }
    }
}
