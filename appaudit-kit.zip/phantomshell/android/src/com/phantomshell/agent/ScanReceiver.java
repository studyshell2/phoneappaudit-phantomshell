package com.phantomshell.agent;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.util.Log;

/**
 * Fires the moment an app is installed, updated or removed - before the user has
 * even opened it.
 *
 * This is the real-time half of the scanner. It is a manifest-registered
 * receiver, so it works with the app closed and without any background service
 * running.
 *
 * Android will not let a receiver start a foreground service, so the work is
 * done inline with goAsync() on a short-lived thread. Scanning one package is
 * fast; this never runs a full scan.
 */
public class ScanReceiver extends BroadcastReceiver {

    private static final String TAG = "PSReceiver";

    @Override
    public void onReceive(final Context context, Intent intent) {
        if (context == null || intent == null || intent.getAction() == null) return;
        // Protection off means nothing is scanned or reported in the background.
        // The in-app "Scan installed apps now" button still works, because that
        // is a direct action by the owner rather than background monitoring.
        if (!Agent.protectionOn(context)) return;
        final String action = intent.getAction();
        final String pkg = packageFrom(intent);
        final PendingResult pending = goAsync();
        final Context app = context.getApplicationContext();

        new Thread(new Runnable() {
            @Override public void run() {
                try {
                    if (Intent.ACTION_PACKAGE_REMOVED.equals(action)) {
                        // EXTRA_REPLACING means an update in progress, not a real removal.
                        boolean replacing = intent.getBooleanExtra(Intent.EXTRA_REPLACING, false);
                        if (!replacing && pkg.length() > 0) {
                            Agent.reportApkRemoved(app, pkg);
                        }
                        return;
                    }
                    if (pkg.length() == 0) {
                        // Some ROMs omit the data URI; fall back to the uid path.
                        return;
                    }
                    Log.i(TAG, "package event " + action + " -> " + pkg);
                    // announce = false: on install we only shout when it is risky.
                    ScanRunner.scanPackage(app, pkg, false);
                } catch (Throwable t) {
                    Log.w(TAG, "onReceive: " + t);
                } finally {
                    try { pending.finish(); } catch (Throwable ignored) { }
                }
            }
        }, "ps-scan-recv").start();
    }

    /** The package name the system put in the intent. */
    private static String packageFrom(Intent intent) {
        try {
            if (intent.getData() != null && intent.getData().getSchemeSpecificPart() != null) {
                return intent.getData().getSchemeSpecificPart();
            }
        } catch (Throwable ignored) { }
        return "";
    }
}
