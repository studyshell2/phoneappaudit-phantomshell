package com.phantomshell.agent;

import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.util.Log;

import java.io.File;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.List;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;

/**
 * Reads the APK file itself and reports what is inside it.
 *
 * Everything else in the scanner asks Android for metadata ABOUT an app. This
 * class opens the package and looks at the bytes, which is what turns "declared
 * permissions" into an actual opinion about whether the thing is dangerous.
 *
 * WHAT IT CAN SEE
 *   - archive layout: how many dex files, how big, what else is carried inside
 *     (nested .apk / .jar / .dex under assets is how droppers ship a payload)
 *   - whether the code is packed by a known commercial protector, which means
 *     the dex cannot be read and the app is hiding its behaviour
 *   - string constants inside the dex: dynamic code loading, root shell paths,
 *     SMS-sending APIs, accessibility abuse, hardcoded command-and-control
 *     hosts, and obfuscation blobs
 *   - cleartext traffic, backup allowed, exported components with no permission
 *   - whether the app has no launcher icon at all (hidden from the app drawer)
 *
 * WHAT IT CANNOT SEE
 *   It is not sandbox detonation and it has no threat-intelligence feed. A
 *   tidy-looking malicious package can still look clean. Every result therefore
 *   carries a confidence value describing how much of the file was readable,
 *   so a low-confidence "clean" is never presented as a guarantee.
 *
 * COST
 *   The dex scan reads at most {@link #DEX_READ_CAP} bytes per app and stops
 *   entirely once the whole scan has spent {@link #SCAN_BUDGET} bytes, so a
 *   phone with 300 apps does not melt. Archives are only ever read through the
 *   zip central directory, which is cheap.
 */
final class ApkInspector {

    private static final String TAG = "PSInspect";

    /** Per-app ceiling on dex bytes read. Enough for the real classes.dex. */
    static final int DEX_READ_CAP = 6 * 1024 * 1024;

    /** Whole-scan ceiling on dex bytes read, so one scan stays bounded. */
    static final long SCAN_BUDGET = 120L * 1024L * 1024L;

    /** Assets larger than this, or this many entries, is worth noting. */
    static final long FAT_ASSETS = 12L * 1024L * 1024L;

    private ApkInspector() {}

    /** What the file itself revealed. All of it is evidence, none of it is a guess. */
    static final class Findings {
        boolean inspected = false;      // any file-level evidence at all
        boolean dexRead = false;        // string scan actually ran
        boolean packed = false;
        boolean nestedArchive = false;
        boolean dynamicCode = false;
        boolean rootTools = false;
        boolean smsSend = false;
        boolean c2Strings = false;
        boolean obfuscated = false;
        boolean cleartext = false;
        boolean allowBackup = false;
        boolean hidden = false;         // no launcher entry, not a system app
        boolean disabled = false;
        boolean multiSigner = false;
        boolean signerChanged = false;
        int exportedUnprotected = 0;
        int httpUrls = 0;
        int dexCount = 0;
        long dexBytes = 0L;
        long spentBytes = 0L;    // dex bytes actually read, for the scan budget
        long assetsBytes = 0L;
        int assetsCount = 0;
        String packerName = "";
        String level = "none";          // deep | zip | none
        final List<String> evidence = new ArrayList<String>();

        void add(String s) {
            for (int i = 0; i < evidence.size(); i++) {
                if (evidence.get(i).equals(s)) return;
            }
            if (evidence.size() < 24) evidence.add(s);
        }
    }

    // ------------------------------------------------------------------ entry

    /**
     * Inspect one installed package. Never throws.
     *
     * @param deep true for a full string scan (user apps); false reads the
     *             archive layout only (system apps - there are hundreds and
     *             they are not where user malware lives)
     */
    static Findings inspect(Context c, PackageManager pm, PackageInfo pi,
                            long budgetLeft, boolean deep) {
        Findings f = new Findings();
        if (pi == null || pi.applicationInfo == null) return f;

        ApplicationInfo ai = pi.applicationInfo;
        String path = ai.publicSourceDir;
        if (path == null || path.length() == 0) return f;
        File apk = new File(path);
        if (!apk.isFile() || apk.length() <= 0) return f;

        // ---- manifest facts that cost nothing ---------------------------
        f.cleartext = (ai.flags & ApplicationInfo.FLAG_USES_CLEARTEXT_TRAFFIC) != 0;
        f.allowBackup = (ai.flags & ApplicationInfo.FLAG_ALLOW_BACKUP) != 0;
        f.disabled = !ai.enabled;
        boolean isSystem = (ai.flags & ApplicationInfo.FLAG_SYSTEM) != 0;
        try {
            // No launcher entry and not a system app: it cannot be seen in the
            // app drawer, which is the ordinary way something "hides" on Android.
            f.hidden = !isSystem && pm.getLaunchIntentForPackage(pi.packageName) == null;
        } catch (Throwable ignored) { }

        // ---- signature shape -------------------------------------------
        try {
            if (android.os.Build.VERSION.SDK_INT >= 28 && pi.signingInfo != null) {
                f.multiSigner = pi.signingInfo.hasMultipleSigners();
            }
        } catch (Throwable ignored) { }

        // ---- exported components with no permission ---------------------
        f.exportedUnprotected = exportedWithoutPermission(pm, pi.packageName);

        // ---- the archive ------------------------------------------------
        ZipFile zip = null;
        try {
            zip = new ZipFile(apk);
            f.inspected = true;
            f.level = "zip";
            Enumeration<? extends ZipEntry> en = zip.entries();
            List<String> dexNames = new ArrayList<String>();
            while (en.hasMoreElements()) {
                ZipEntry e = en.nextElement();
                if (e == null) continue;
                String name = e.getName() == null ? "" : e.getName();
                String lower = name.toLowerCase();
                long size = e.getSize() > 0 ? e.getSize() : 0L;

                if (lower.endsWith(".dex") && lower.indexOf('/') < 0) {
                    dexNames.add(name);
                    f.dexBytes += size;
                    continue;
                }
                if (lower.startsWith("lib/") && lower.endsWith(".so")) {
                    String base = lower.substring(lower.lastIndexOf('/') + 1);
                    String packer = packerFor(base);
                    if (packer.length() > 0) {
                        f.packed = true;
                        if (f.packerName.length() == 0) f.packerName = packer;
                        f.add("code is protected by a packer (" + packer
                                + "), so its real behaviour cannot be read");
                    }
                }
                if (lower.startsWith("assets/")) {
                    f.assetsCount++;
                    f.assetsBytes += size;
                    // A second app hidden inside the first, ready to be
                    // dropped and installed later.
                    if (lower.endsWith(".apk") || lower.endsWith(".jar")
                            || lower.endsWith(".dex")) {
                        f.nestedArchive = true;
                        f.add("carries another app inside it: " + name);
                    }
                }
                if (lower.endsWith(".apk") && lower.indexOf('/') >= 0
                        && !lower.startsWith("assets/")) {
                    f.nestedArchive = true;
                    f.add("carries another app inside it: " + name);
                }
            }
            f.dexCount = dexNames.size();
            if (f.dexCount == 0) {
                f.add("contains no compiled code at all");
            }

            // ---- the dex strings ----------------------------------------
            if (deep && budgetLeft > 0 && !f.packed) {
                long spent = 0L;
                for (String dn : dexNames) {
                    if (spent >= DEX_READ_CAP || spent >= budgetLeft) break;
                    int want = (int) Math.min(DEX_READ_CAP - spent, budgetLeft - spent);
                    byte[] head = readEntry(zip, dn, want);
                    if (head == null || head.length == 0) continue;
                    spent += head.length;
                    scanDexStrings(head, f);
                }
                if (spent > 0) {
                    f.dexRead = true;
                    f.level = "deep";
                }
                f.spentBytes = spent;
            }

            if (f.assetsBytes > FAT_ASSETS) {
                f.add("carries " + mb(f.assetsBytes) + " MB of extra assets");
            }
        } catch (Throwable t) {
            // Unreadable is normal for some third-party APKs on modern
            // Android. It means no file evidence, not that the app is clean.
            Log.w(TAG, "zip " + pi.packageName + ": " + t);
        } finally {
            if (zip != null) { try { zip.close(); } catch (Throwable ignored) { } }
        }
        return f;
    }

    /** A string table entry found in the dex, matched against real API names. */
    private static final String[][] TOKENS = {
            // dynamic code loading: the shipped dex is not the whole story
            { "Ldalvik/system/DexClassLoader;", "loads extra code at runtime" },
            { "Ldalvik/system/InMemoryDexClassLoader;", "loads extra code at runtime" },
            { "Ldalvik/system/PathClassLoader;", "loads extra code at runtime" },
            // root
            { "/system/bin/su", "looks for root shell binaries" },
            { "/system/xbin/su", "looks for root shell binaries" },
            { "Superuser.apk", "looks for root shell binaries" },
            { "/sbin/magisk", "looks for Magisk" },
            // sms
            { "Landroid/telephony/SmsManager;", "uses the SMS API" },
            { "sendTextMessage", "sends text messages" },
            { "sendMultipartTextMessage", "sends text messages" },
            // accessibility abuse
            { "Landroid/accessibilityservice/AccessibilityService;", "implements an accessibility service" },
            { "dispatchGesture", "can tap the screen for the user" },
            { "performGlobalAction", "can drive the screen for the user" },
            // silent install
            { "Landroid/content/pm/PackageInstaller;", "can install other apps silently" },
            { "createInstallSession", "can install other apps silently" },
            // c2 / exfil destinations
            { "api.telegram.org", "talks to a Telegram bot (common exfiltration channel)" },
            { ".onion", "contains a Tor hidden-service address" },
            { "ngrok.io", "contains a throwaway tunnel address" },
            { "trycloudflare.com", "contains a throwaway tunnel address" },
            // hiding
            { "setComponentEnabledSetting", "can hide or unhide its own icon" },
            { "getInstalledPackages", "enumerates other installed apps" },
    };

    private static void scanDexStrings(byte[] raw, Findings f) {
        String s;
        try {
            // ISO-8859-1 maps one byte to one char, so offsets stay meaningful
            // and no decoding work is wasted on binary noise.
            s = new String(raw, "ISO-8859-1");
        } catch (Throwable t) {
            return;
        }
        for (String[] pair : TOKENS) {
            if (s.indexOf(pair[0]) < 0) continue;
            String token = pair[0];
            String label = pair[1];
            if (token.indexOf("DexClassLoader") >= 0
                    || token.indexOf("PathClassLoader") >= 0
                    || token.indexOf("InMemoryDex") >= 0) {
                f.dynamicCode = true;
            } else if (token.indexOf("/su") >= 0 || token.indexOf("magisk") >= 0
                    || token.indexOf("Superuser") >= 0) {
                f.rootTools = true;
            } else if (token.indexOf("SmsManager") >= 0
                    || token.indexOf("sendTextMessage") >= 0
                    || token.indexOf("sendMultipart") >= 0) {
                f.smsSend = true;
            } else if (token.indexOf("telegram") >= 0 || token.indexOf("onion") >= 0
                    || token.indexOf("ngrok") >= 0 || token.indexOf("trycloudflare") >= 0) {
                f.c2Strings = true;
            } else if (token.indexOf("setComponentEnabledSetting") >= 0) {
                f.hidden = true;
            }
            f.add(label);
        }

        // Plaintext HTTP endpoints mean whatever it sends can be read on the
        // wire. Counted, not listed, because a single app can have dozens.
        int at = 0;
        while (true) {
            int i = s.indexOf("http://", at);
            if (i < 0 || f.httpUrls >= 50) break;
            f.httpUrls++;
            at = i + 7;
        }

        // Long base64 runs are the signature of a hidden payload or config.
        if (hasLongBase64(s)) {
            f.obfuscated = true;
            f.add("contains a large encoded blob (hidden payload or config)");
        }
    }

    /** True when the text contains a base64 run long enough to hide something. */
    private static boolean hasLongBase64(String s) {
        int run = 0;
        for (int i = 0; i < s.length(); i++) {
            char ch = s.charAt(i);
            boolean b64 = (ch >= 'A' && ch <= 'Z') || (ch >= 'a' && ch <= 'z')
                    || (ch >= '0' && ch <= '9') || ch == '+' || ch == '/';
            if (b64) {
                run++;
                if (run >= 400) return true;
            } else {
                run = 0;
            }
        }
        return false;
    }

    /** Commercial protectors, by native library name. */
    private static String packerFor(String soName) {
        String[] known = {
                "libjiagu", "libjgdtc", "libshell", "libsecexe", "libsecmain",
                "libmobisec", "libbaiduprotect", "libnesec", "libexec.so",
                "libddog", "libapktoolplus", "libchaosvmp", "libnativehelper_x",
                "libkwscmm", "libedog", "libapp-protect"
        };
        for (String k : known) {
            if (soName.startsWith(k)) return k.replace("lib", "").replace(".so", "");
        }
        return "";
    }

    /** Exported activities, services and receivers that no permission guards. */
    private static int exportedWithoutPermission(PackageManager pm, String pkg) {
        int count = 0;
        try {
            int flags = PackageManager.GET_ACTIVITIES
                    | PackageManager.GET_SERVICES
                    | PackageManager.GET_RECEIVERS;
            PackageInfo pi = pm.getPackageInfo(pkg, flags);
            if (pi == null) return 0;
            if (pi.activities != null) {
                for (android.content.pm.ActivityInfo a : pi.activities) {
                    if (a != null && a.exported && a.permission == null) count++;
                }
            }
            if (pi.services != null) {
                for (android.content.pm.ServiceInfo s : pi.services) {
                    if (s != null && s.exported && s.permission == null) count++;
                }
            }
            if (pi.receivers != null) {
                for (android.content.pm.ActivityInfo r : pi.receivers) {
                    if (r != null && r.exported && r.permission == null) count++;
                }
            }
        } catch (Throwable ignored) { }
        return count;
    }

    /** Read at most {@code cap} bytes from one archive entry. */
    private static byte[] readEntry(ZipFile zip, String name, int cap) {
        InputStream in = null;
        try {
            ZipEntry e = zip.getEntry(name);
            if (e == null || e.getSize() == 0) return null;
            in = zip.getInputStream(e);
            if (in == null) return null;
            byte[] buf = new byte[cap];
            int off = 0;
            while (off < cap) {
                int n = in.read(buf, off, cap - off);
                if (n <= 0) break;
                off += n;
            }
            if (off == cap) return buf;
            byte[] out = new byte[off];
            System.arraycopy(buf, 0, out, 0, off);
            return out;
        } catch (Throwable t) {
            return null;
        } finally {
            if (in != null) { try { in.close(); } catch (Throwable ignored) { } }
        }
    }

    private static String mb(long bytes) {
        return String.format(java.util.Locale.US, "%.1f", bytes / (1024.0 * 1024.0));
    }
}
