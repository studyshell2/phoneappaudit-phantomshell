# PhantomShell

Check the apps on an Android phone, and see the result on a dashboard you run
yourself.

You install a small app on the phone. It lists every app that is installed, keeps
the ones that did **not** come from an app store, and gives each one a simple
answer: **Safe** or **High**. The phone sends that list to a web page on your
computer, worst first.

- **Runs on your own machine.** One Python file and one HTML page. No cloud
  account, nothing to sign up for.
- **Works with no internet.** The phone can scan itself and show the result on
  its own screen.
- **One score per phone.** A single number from 0 to 100, with the maths printed
  under it so you can check it.

---

## What you need

| | |
|---|---|
| A computer | Kali, Debian or Ubuntu. Python 3 and curl come with them. |
| A phone | Android 7 or newer. |
| A cable | Optional. You can also download the app on the phone itself. |
| Internet on the computer | Only for the free Cloudflare tunnel in step 3. It works on a local network without it. |

---

## Step 1 — Get the files

```bash
git clone https://github.com/phantomshell2026/phantomshell-project-2026.git
cd phantomshell
```

Not using git? Download the ZIP from GitHub, unzip it, then `cd` into the folder.

---

## Step 2 — Install (once)

```bash
bash install.sh
```

It checks every file, installs `cloudflared` if it is missing, starts the server
and proves it answers. You want to see this at the end:

```
  SETUP COMPLETE
```

If you see `[FAIL]` instead, run `bash doctor.sh`. It tells you which part broke.

---

## Step 3 — Start it

```bash
bash run.sh
```

That is the only command you need from now on. It installs on the first run and
then starts the server every time.

You will get an address like this:

```
  tunnel verified: https://quiet-net-performed.trycloudflare.com/health answered
  READY
```

**Keep this terminal open.** The server runs in the foreground. `Ctrl+C` stops it.

Two other ways to start, if you prefer:

```bash
PS_TUNNEL=0 bash ./start.sh           # local network only, no tunnel
PS_PORT=8099 bash ./start.sh          # port 8085 is already taken
PS_REQUIRE_TUNNEL=1 bash ./start.sh   # stop if the tunnel cannot be made
```

---

## Step 4 — Make your login

Open the address from step 3 in a browser, then add `/login`:

```
https://quiet-net-performed.trycloudflare.com/login
```

Press **Create account** and choose a username, an email and a password of 8
characters or more.

There is **no built-in username or password**. The first account is the one you
make here, so nobody can log in before you do.

> Password reset sends a six-digit code by email. If you have not set
> `PS_SMTP_HOST`, `PS_SMTP_FROM` and `PS_SMTP_PASS`, the page says plainly that
> no code can be sent. Do not lock yourself out.

---

## Step 5 — Put the app on the phone

The dashboard serves the app itself, so you do not need a cable.

**On the phone:** open this in the phone's browser and it downloads:

```
https://quiet-net-performed.trycloudflare.com/agent.apk
```

Open the downloaded file. Android will warn that the file is from an unknown
source — allow it for your browser once. The app is signed, so updates install
over the old one without losing settings.

**Or with a cable**, from the computer:

```bash
adb install -r server/apks/phantomshell-agent.apk
```

---

## Step 6 — Connect the phone to the dashboard

Open **PhantomShell** on the phone and swipe to **SETTINGS**:

1. **Dashboard** — type the address from step 3, e.g.
   `https://quiet-net-performed.trycloudflare.com`
2. **Tag** — a name you will recognise, e.g. `vivo` or `alice-phone`
3. Press **SAVE**

Leave the tag empty if you like; the phone still works.

---

## Step 7 — Scan

Swipe back to **SCAN** and press the round **GO** button.

```
        ┌─────────────┐
        │     72      │     the score for this phone
        │ SCORE / 100 │
        │   WATCH     │
        └─────────────┘
             ( GO )
```

A full scan takes a few seconds. When it finishes you get four things:

- **A score**, 0 to 100. 100 means nothing outside a store was found.
- **The maths**, printed under it: `100 - 1 high x 25 - 1 safe x 3 = 72`. A High
  app costs 25 points, an outside-store app graded Safe costs 3.
- **One card per app**, worst first: where it came from, why it was flagged, and
  what to do about it.
- **A line saying whether it was sent** to the dashboard, or kept on the phone.

### The two buttons

| Button | What it does |
|---|---|
| **GO** | Scans, and sends the result to the dashboard **if** an address is saved in Settings. |
| **SCAN THIS PHONE ONLY** | Scans and shows the result on the phone. Never sends anything, even if an address is saved. Works on a phone that was never set up. |

Use the second one when you just want to check a phone, or there is no dashboard
running.

---

## Step 8 — Read the dashboard

Back in the browser, the phone appears within a few seconds. The table shows one
row per app that came from outside a store, worst first, with:

- the app name, package and version
- **where it came from** — `Downloaded file`, `Opened by Chrome`, `adb install`,
  `Local file`, or a store
- **why** it was flagged
- **what to do**, under *Remediation*

Every row that is flagged also appears in the **PDF report**. While you are signed
in, press **Download PDF report** at the top of the dashboard. The same file is at
`/api/log.pdf`, and that address needs your login like every other page.

The PDF is a three-page report you can print or send: a summary, a chart, and the
full log with the advice written next to each app.

---

## Optional — typing the address with a BadUSB

If you have a Kiisu (or any BadUSB that types text), the kit writes two payload
files for you on every start. They are in `payloads/`, and they contain this
run's address already filled in:

| File | What it types |
|---|---|
| `payload_tunnel_apk.txt` | The dashboard address, into the app's **Dashboard** field. You tap the field first. |
| `payload_android_ducky.txt` | The install link, into the phone's browser, on an unlocked phone. |

The steps, with a Kiisu v4b and qFlipper:

1. Start the kit (`bash run.sh`) and wait for `READY`.
2. Open qFlipper, connect the Kiisu by USB, and open the file manager.
3. Copy `payloads/payload_tunnel_apk.txt` into the Kiisu's `BadUSB` folder.
4. Unplug the Kiisu from the computer and plug it into the phone with an OTG
   cable. The phone's keyboard appears — that is the Kiisu behaving as a keyboard.
5. On the phone, open **PhantomShell → SETTINGS** and tap the **Dashboard** field,
   so the cursor is in it.
6. On the Kiisu, pick the payload and run it. It types the address.
7. Press **SAVE** on the phone.

The address changes every time you restart with a new tunnel, so copy the payload
again after a restart. If you would rather not think about that, start with
`PS_TUNNEL=0 bash ./start.sh` and use your computer's LAN address, which stays
the same.

---

## Troubleshooting

| What you see | What it means |
|---|---|
| `http=000 bytes=0` | Nothing is listening. The server is not running — start it. |
| `http=404` | The server is running, but that file is missing. |
| Login page says no account | Press **Create account**; there is no built-in login. |
| Phone says **Dashboard did not answer** | The address in Settings is wrong, or the phone is on mobile data and the computer is on Wi-Fi. The scan still ran and is on the phone. |
| Score shows `--` | No scan has run yet. Press **GO**. |

```bash
bash doctor.sh     # checks the server, the APK, the payloads and the tunnel
```

It exits `0` when everything is healthy, so you can use it in a script.

---

## What is in the folder

```
phantomshell/
├── run.sh                     one command to start it
├── install.sh                 one-time setup
├── start.sh                   server + tunnel, writes the payloads
├── doctor.sh                  tells you what is broken
├── build_apk.sh               rebuilds the phone app
├── push-clean.sh              replaces the GitHub branch with this folder
├── server/
│   ├── phantomshell_server.py the whole server: pages, API, PDF report
│   ├── index.html             the dashboard
│   ├── login.html             the sign-in card
│   ├── agent.html             the page the phone opens
│   ├── logo.jpg               the crest
│   ├── phantomshell.mp4       the background film
│   └── apks/                  the signed app that /agent.apk serves
├── android/                   the phone app's source
├── payloads/                  written on every start, with this run's address
└── docs/HISTORY.md            what changed in every version, and why
```

---

## Before you push this to GitHub

A few files in this folder are private. `.gitignore` already keeps them out — do
not add them with `git add -f`.

| Keep out | Why |
|---|---|
| `android/keystore/ps-agent.jks` | **Your app's signing key.** Anyone with this file can sign an app that Android accepts as an update to yours. Back it up somewhere private instead. |
| `server/state.json`, `server/accounts.json` | Real logins, real phone records, password hashes. |
| `server/payloads/`, `payloads/` | Contain your live tunnel address. |
| `server/downloads/*.exe` | Third-party installers you dropped in yourself. |

Two more things worth deciding before you publish:

- **The five photos in `server/team/` are real people.** Ask them, or remove the
  team panel, before the repo is public.
- **There is no `LICENSE` file.** Without one, nobody may legally reuse the code.
  Add MIT or Apache-2.0 if you want people to.

**Push the files, not the ZIP.** If the repository already holds
`phantomshell-kit.zip`, one command replaces it with the kit itself:

```bash
unzip phantomshell-kit.zip        # gives you ./phantomshell
cd phantomshell
bash push-clean.sh https://github.com/phantomshell2026/phantomshell-project-2026.git
```

It builds one fresh commit from the files in this folder, stops if the signing
key, the live server state or a ZIP would be published, and force-pushes that
over the branch. The same command works for a brand-new empty repository.

By hand, if you prefer:

```bash
git init
git add .
git status                        # the .jks and state.json must NOT be listed
git commit -m "PhantomShell 2.1.1"
git branch -M main
git remote add origin https://github.com/phantomshell2026/phantomshell-project-2026.git
git push -u origin main --force
```

The force push replaces the branch, but it does not erase the old commits from
GitHub's storage: they stay reachable by their old links until GitHub cleans them
up. On a private repository with no collaborators that is only your own account.
If you plan to make the repository public or add collaborators, treat the signing
key as known - delete `android/keystore/ps-agent.jks`, run `bash build_apk.sh` to
generate a new one, and expect to uninstall the app once on any phone that
already has it. Android will not upgrade across two different keys.

If you ever rebuild the app with a **new** key, phones that already have the old
one must uninstall it first. Android will not upgrade across two different keys.

---

## Limits — read this once

- It **grades** apps, it does not remove malware. The advice tells you what to
  uninstall.
- It does **not** read messages, photos, passwords or files. It reads the app
  list and, where Android allows it, the app files themselves.
- Some apps cannot be read on newer Android versions. Those are marked
  **Unverified**, not **Safe** — the difference matters.
- The score is a summary, not a verdict. Read the cards.
- The tunnel address is public while it runs. Anyone with the link reaches your
  login page, which is why the account you create in step 4 matters.

---

## Version

```
app     PhantomShell 2.1.1   (versionCode 13)
size    832084 bytes
sha256  df4f3cc7676d28988444cedb2ea89dda57f4386433db1b562c4ad2258b425719
```

The same hash is what `/agent.apk` serves, so you can confirm the file on the
phone is the one built here.
